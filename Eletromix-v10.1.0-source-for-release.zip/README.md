# Eletronic Store — Versão Definitiva

Sistema local de caixa/PDV para loja de eletrônicos.

## Recursos incluídos
- Login sem usuário/senha pré-preenchidos
- Mostrar/ocultar senha
- Administrador e vendedor
- Abertura e fechamento de caixa
- Cadastro e edição de produtos
- Ativação/inativação de produtos
- Controle de estoque com entrada, saída e ajuste
- Histórico de movimentações de estoque
- Cadastro e edição de clientes
- PDV com carrinho, desconto, cliente e forma de pagamento
- Baixa automática de estoque
- Histórico de vendas
- Cancelamento de venda com devolução automática ao estoque
- Comprovante de venda e impressão
- Dashboard com vendas, faturamento, ticket médio, estoque baixo, meios de pagamento e produtos mais vendidos
- Cadastro e gerenciamento de usuários
- Configurações da loja
- Backup em JSON
- Persistência local de dados em `data/database.json`
- Sem SQLite, Python ou node-gyp

## Primeiro acesso
Usuário: admin
Senha: admin123

## Como instalar e executar
No PowerShell, dentro da pasta:

```powershell
npm.cmd install
npm.cmd run dev
```

Abra:
http://localhost:3000

## Observações
- Os dados ficam salvos no arquivo `data/database.json`.
- O sistema é pensado para uso local em um computador.
- Sessões são mantidas em memória; ao reiniciar o servidor, basta entrar novamente.
- Para uso comercial real em rede/internet, seria recomendado migrar o armazenamento para PostgreSQL/MySQL e usar HTTPS.


## Alterações da v2
- Cadastro de cliente simplificado: apenas nome e status.
- CPF/CNPJ, telefone e e-mail agora podem ser informados na própria venda e aparecem no comprovante.
- Módulo fiscal em modo **rascunho** para NF-e/NFC-e.
- O rascunho fiscal fica vinculado à venda.

### Importante sobre NF-e/NFC-e
O projeto não transmite uma nota com validade jurídica por conta própria. A emissão oficial depende de configuração tributária, credenciamento do contribuinte, certificado digital ICP-Brasil e integração com os serviços da SEFAZ. O módulo atual foi preparado para receber essa integração depois sem misturar uma simulação com uma nota fiscal real.


## Serviços e assistência técnica

Esta versão acrescenta:

- cadastro de serviços;
- serviços com nome, descrição, categoria, preço e tempo estimado;
- venda de produtos e serviços no mesmo carrinho;
- serviços não alteram estoque;
- ordens de serviço para aparelhos;
- cliente, telefone, aparelho, marca, modelo e problema relatado;
- vínculo da ordem com um serviço cadastrado;
- status: Recebido, Em análise, Aguardando peça, Em reparo, Pronto e Entregue;
- edição de valor e observações da ordem;
- serviços iniciais de exemplo: troca de tela, troca de bateria e limpeza de software.

A área de “remoção de vírus” passa a ser tratada como um serviço de assistência técnica, evitando promessas de que o sistema consegue garantir sozinho que um aparelho está totalmente livre de malware.


## Atualização: código de barras e segurança do celular

- Serviços não possuem mais campo de tempo estimado.
- Produtos agora possuem `codigoBarras`, além do código interno/SKU.
- A busca do PDV encontra produtos pelo nome, código interno ou código de barras.
- Código de barras pode ser cadastrado e editado no produto.
- Nova aba **Segurança do Celular** com:
  - cadastro de diagnóstico;
  - sintomas relatados;
  - checklist de análise;
  - registro de resultado e observações;
  - histórico de diagnósticos.

O módulo de segurança é uma ferramenta de assistência técnica e registro. Ele não afirma remover automaticamente todos os vírus nem garante que um aparelho esteja totalmente livre de malware.


## Acesso sem login
Esta versão abre diretamente, sem solicitar usuário ou senha. Os recursos locais continuam com permissões administrativas para preservar as funções existentes.


## Correção da tela branca
Foi removida uma referência JavaScript à antiga tela de Usuários que causava erro na inicialização depois que o login foi retirado.


## Segurança do celular via USB

A aba "Segurança do Celular" agora usa ADB no computador para analisar um Android conectado via USB.

Ela:
- identifica fabricante, modelo e versão do Android;
- lista apps de terceiros;
- verifica sinais que merecem revisão, como Acessibilidade habilitada, administrador do dispositivo, acesso a notificações, VPN permanente e instaladores fora das lojas padrão;
- não remove apps automaticamente e não declara um app como malware apenas pelo nome.

### Requisitos para USB
1. Instalar o Android SDK Platform-Tools/ADB no Windows e deixar `adb` disponível no PATH.
2. No celular Android, ativar Opções do desenvolvedor e Depuração USB.
3. Conectar por cabo de dados.
4. Aceitar no celular a autorização de depuração para aquele computador.

## Cadastros e histórico

O sistema continua sem senha. Em vez disso, há "Cadastros de Operadores".
Selecione o operador no topo da tela. Toda requisição que altera dados (POST/PUT/PATCH/DELETE) é registrada em "Histórico de Alterações" com:
- data/hora;
- operador;
- tipo de ação;
- rota/área;
- status da operação.

Isso permite saber quem realizou alterações sem voltar ao login com senha.


## Multi-loja

Esta versão substitui o cadastro de operadores por cadastro de **Lojas / Unidades**.

- O seletor no topo escolhe a loja atual.
- Produtos, estoque, clientes, serviços, ordens de serviço, diagnósticos, caixa e vendas ficam vinculados à loja selecionada.
- Dados existentes de versões anteriores são migrados automaticamente para a "Loja Principal".
- Cada loja possui nome, CNPJ, telefone, endereço e rodapé de comprovante próprios.
- A aba **Todas as Lojas** mostra um resumo consolidado das unidades sem trocar de acesso.
- O endpoint `/api/lojas/resumo-geral` já deixa a estrutura preparada para o futuro aplicativo Android consultar todas as lojas.
- O backup continua contendo todas as unidades no mesmo arquivo, evitando perder dados ao alternar entre lojas.

A Segurança do Celular via USB/ADB continua disponível no sistema de computador.


## Correção de inicialização

Corrigido o erro `Unexpected "const"` no `server.ts` que impedia o servidor de iniciar.
Também foram corrigidos:
- rotas de movimentos, clientes, caixas e vendas;
- leitura da loja atual no `/api/me`;
- resumo de produtos/serviços mais vendidos;
- helpers do ADB para a aba de segurança via USB;
- retorno das configurações da loja atual.


## Relatórios
A nova aba **Relatórios** permite selecionar período e gerar:
- relatório da loja atual;
- relatório consolidado de todas as lojas;
- receita bruta;
- descontos;
- valor efetivamente arrecadado (receita líquida);
- custo dos produtos vendidos;
- lucro bruto estimado;
- margem bruta;
- ticket médio;
- valor do estoque pelo custo;
- valor potencial do estoque pelo preço de venda;
- resultados por produto, serviço, forma de pagamento e unidade.

## Personalização
A aba **Personalização do Sistema** permite alterar:
- nome exibido do sistema;
- ícone/emoji;
- cor principal;
- atalhos de cor como azul, vermelho, verde, roxo, laranja e preto.

A personalização é global e fica salva no arquivo de dados junto com o restante do sistema.


## Personalização avançada
Agora é possível personalizar separadamente:
- cor principal dos botões e destaques;
- barra superior;
- menu lateral;
- fundo da tela;
- cards;
- texto principal;
- texto secundário;
- bordas;
- alertas;
- nome do sistema;
- ícone;
- imagem/logo enviada do computador.

A logo é guardada junto aos dados do sistema em formato de imagem incorporada.

## Acréscimos
O caixa agora aceita:
- **acréscimo por produto ou serviço**, sem alterar o preço cadastrado;
- **acréscimo geral da venda**;
- desconto continua disponível normalmente.

O preço original do produto/serviço permanece intacto no cadastro. O acréscimo fica registrado somente naquela venda.


## Desinstalação de aplicativos via USB

A aba **Segurança do Celular** agora permite desinstalar um aplicativo selecionado do Android conectado.

Fluxo:
1. conectar e autorizar o celular via ADB;
2. clicar em **Escanear celular USB**;
3. escolher o aplicativo;
4. clicar em **Desinstalar**;
5. confirmar duas vezes;
6. o sistema executa a desinstalação padrão do ADB e faz uma nova varredura.

O programa não solicita nem armazena PIN/senha do aparelho. O desbloqueio e a autorização de depuração USB continuam sendo feitos no próprio celular.

Aplicativos de sistema protegidos podem recusar a desinstalação, e o sistema exibirá o erro em vez de tentar contornar as proteções do Android.


## Logo no comprovante

Quando uma imagem/logo é configurada em **Personalização do Sistema**, ela agora aparece automaticamente:
- no topo do sistema;
- na prévia de personalização;
- no comprovante de venda;
- na versão impressa do comprovante.

Se nenhuma imagem for enviada, o comprovante continua funcionando normalmente sem logo.


## Correção de navegação
As abas agora possuem uma camada independente de navegação por delegação de eventos.
Isso significa que mesmo se algum módulo específico tiver erro de carregamento, o clique no menu continua trocando de tela.
Também foi adicionado cache-busting no `app.js` para evitar que o Chrome use uma versão antiga do JavaScript.


## Correção do cadastro de produtos
O botão **Novo produto** passou a usar navegação/eventos delegados independentes.
Também foi removida a dependência do objeto de login para editar/cadastrar produtos no modo sem login.
O cadastro agora mostra erro de API/conexão em vez de falhar silenciosamente.


# Aplicativo para Windows

Esta versão é preparada para ser instalada como **aplicativo desktop Windows**.

## Abrir como aplicativo

```powershell
npm.cmd install
npm.cmd run desktop
```

## Gerar instalador .exe

```powershell
npm.cmd install
npm.cmd run desktop:build
```

O instalador ficará na pasta:

```text
release
```

O instalador cria atalho na Área de Trabalho e no Menu Iniciar.

## Relatórios por e-mail

Cada loja pode cadastrar:
- e-mail do proprietário;
- horário diário;
- ativar/desativar envio automático.

Há também um e-mail consolidado para receber o resumo de todas as lojas.

A aba **Relatórios por E-mail** permite configurar SMTP e enviar um teste.

Quando a janela do aplicativo é fechada, o Eletronic Store permanece na bandeja do Windows para continuar verificando o horário dos relatórios. Para encerrar completamente, use **Sair** no ícone da bandeja.


## Correção da abertura do aplicativo desktop

O Electron agora usa um ícone PNG válido para a janela e para a bandeja do Windows.
Se a bandeja falhar, o aplicativo continua aberto em vez de encerrar.

Teste nesta ordem:

```powershell
npm.cmd install
npm.cmd run desktop:check
npm.cmd run desktop
```

`desktop:check` deve mostrar "Electron iniciou corretamente.".

Ao executar `desktop`, não abra `localhost:3000` no Chrome. A janela do Eletronic Store deve abrir sozinha.


## Correção do instalador — erro `spawn ... Eletronic Store.exe ENOENT`

A versão instalada não tenta mais abrir o próprio `.exe` como um processo Node.
O servidor interno agora é iniciado pelo `utilityProcess` do Electron, próprio para executar o backend JavaScript dentro do aplicativo empacotado.

Também foi configurado `asarUnpack` para o backend compilado em `dist`.


## Correção do servidor interno no aplicativo instalado

O backend agora é carregado diretamente pelo processo principal do Electron.
Isso elimina os erros anteriores de:
- `spawn ... ENOENT`;
- `utilityProcess` não localizar o backend;
- servidor interno não iniciar depois da instalação.

Antes de gerar o instalador, você pode testar:

```powershell
npm.cmd install
npm.cmd run build
npm.cmd run desktop:backend-check
npm.cmd run desktop
```

Depois gere novamente:

```powershell
npm.cmd run desktop:build
```


## Envio de relatórios por API

O envio de e-mail não depende mais da senha do Gmail nem de SMTP.

A nova tela pede:
- chave da API;
- e-mail remetente;
- e-mail central;
- horário;
- envio consolidado automático.

Para usar Resend:
1. crie uma conta;
2. crie uma API key com permissão de envio;
3. adicione e verifique um domínio;
4. use no Eletronic Store um remetente desse domínio, por exemplo `relatorios@seudominio.com`;
5. salve e use **Enviar e-mail de teste**.

A chave nunca é mostrada novamente pelo aplicativo depois de salva.


## Correção do build Resend

Foi removida a configuração SMTP antiga que ainda existia no objeto inicial do banco.
O `EmailConfig` agora usa somente:
- `provedor`;
- `apiKey`;
- `remetente`;
- `emailConsolidado`;
- `horarioConsolidado`;
- `enviarConsolidado`.

Isso corrige o erro TypeScript: `host does not exist in type EmailConfig`.


## Impressão térmica direta e modo otimizado
- Impressão silenciosa diretamente para impressoras instaladas no Windows, sem abrir outro aplicativo.
- Seleção de impressora, papel 80 mm/58 mm, impressão de teste e opção de impressão automática após a venda.
- A impressora precisa aparecer em Impressoras do Windows; o driver do fabricante continua sendo necessário para o Windows reconhecer o equipamento.
- Layout compacto automático para telas menores e redução de sombras/animações.
- Listas do PDV são limitadas durante a renderização e buscas usam debounce para reduzir travamentos em PCs antigos.
- A aceleração de hardware do Electron foi desativada para maior estabilidade em PCs antigos com GPU integrada problemática.


## Versão portátil — sem Node/npm no computador da loja

Esta versão pode gerar um `.exe` portátil que já leva Electron/Node dentro do próprio aplicativo. **O computador da loja não precisa instalar Node, npm ou abrir navegador.**

Em um computador de desenvolvimento que já tenha Node, execute `GERAR-APP-PORTATIL.bat` ou:

```powershell
npm.cmd install
npm.cmd run desktop:release
```

Depois copie o `.exe` gerado em `release` para o computador antigo. O `.exe` portátil roda sozinho.

A impressão usa a impressora instalada/reconhecida pelo Windows e é enviada silenciosamente pelo aplicativo, sem Word, navegador ou leitor de PDF. Se nenhuma impressora for escolhida, o sistema tenta localizar automaticamente uma EPSON/TM/POS/Thermal e, em seguida, a impressora padrão.

## Desconto por porcentagem

No PDV, o campo **Desconto** agora permite alternar entre `R$` e `%`. Ao escolher `%`, o sistema calcula automaticamente o valor do desconto antes de concluir a venda.


## Relatório mensal por e-mail

Na aba **Relatórios por E-mail** agora existem duas opções:
- relatório consolidado de hoje;
- relatório consolidado mensal.

No relatório mensal, selecione qualquer mês no formato mês/ano (por exemplo, abril de 2026). O sistema calcula somente as vendas daquele mês, monta o resumo geral e o detalhamento de cada loja e abre o aplicativo de e-mail padrão.


## Leitor de código de barras — adição automática

No Caixa/PDV, quando o campo de busca recebe:
- um **código de barras exato**; ou
- um **código interno exato**,

o produto é adicionado imediatamente ao carrinho.

Leitores de código de barras que enviam **Enter** ao final da leitura também são suportados. Depois da leitura, o campo é limpo e recebe foco novamente para a próxima venda.


## Relatório por loja
Na aba **Relatórios por E-mail**, escolha:
- uma loja específica; ou
- **Todas as lojas**.

A escolha funciona tanto no relatório diário quanto no relatório mensal.

## ADB oficial sob demanda
A aba **Segurança do Celular** agora possui o botão **Baixar ADB oficial**.
O aplicativo não redistribui o Android SDK Platform-Tools dentro do ZIP. Ao clicar, ele baixa a versão oficial diretamente do Google para a pasta de dados do Eletronic Store e passa a usar essa cópia automaticamente.

O usuário precisa aceitar os termos do Android SDK antes do download.


## Solicitar autorização ADB

A aba **Segurança do Celular** agora possui o botão **Solicitar autorização ADB**.

O botão:
1. reinicia o servidor ADB;
2. detecta um aparelho em estado `unauthorized`;
3. solicita uma nova negociação de depuração USB;
4. aguarda até 45 segundos pela confirmação no celular;
5. informa quando o aparelho passa para o estado autorizado.

Importante: o Eletronic Store não solicita, lê nem armazena a senha/PIN do aparelho. O desbloqueio e a confirmação **Permitir depuração USB?** acontecem exclusivamente na tela do Android.


## Autorização corrigida — feita no celular

O botão anterior foi alterado. O sistema agora deixa claro que a autorização principal acontece no Android:
- desbloquear o aparelho;
- ativar Depuração USB;
- confirmar “Permitir depuração USB?” no próprio celular.

O botão **Autorizar no celular** apenas verifica o estado do aparelho e espera a confirmação feita no telefone. Ele não pede PIN/senha no computador e não tenta reiniciar o ADB para simular uma autorização.


## Detecção automática do celular

A aba **Segurança do Celular** agora monitora o ADB automaticamente enquanto o sistema está aberto.

Estados mostrados:
- **Autorizado**: o aparelho já autorizou este computador e a análise inicia automaticamente;
- **Aguardando autorização do Android**: o aparelho aparece como `unauthorized`;
- **Offline**: o ADB detectou o aparelho, mas não consegue estabelecer a sessão;
- **Não detectado**: nenhum Android está disponível no ADB.

O monitor não tenta contornar PIN, senha ou autorização do Android.


## Detecção USB em duas camadas

A tela de Segurança agora diferencia:
1. **conexão física reconhecida pelo Windows** (WPD/MTP/USB); e
2. **estado de acesso ADB**.

Assim, um telefone conectado não aparece mais como “não detectado” só porque ainda não está disponível no ADB.

Estados exibidos:
- conectado por USB, ADB ainda indisponível;
- detectado, aguardando autorização;
- detectado, ADB offline;
- conectado e autorizado;
- nenhum aparelho detectado.

Quando o estado muda para autorizado, a análise é iniciada automaticamente.


## PDV com vendedor e cliente fixos
Vendedor e cliente foram movidos para uma barra no topo do caixa. Cada um possui um cadeado independente. Ao travar, a seleção fica fixa entre vendas e o campo fica protegido contra alteração acidental. Ao destravar, a seleção é limpa depois de cada venda. As travas são salvas separadamente para cada loja.


## Visual Premium + Caixa rápido
- Ícones do menu foram substituídos por SVGs internos, sem dependência de internet.
- Cabeçalho, menu, cards, campos e estados receberam visual mais moderno.
- O status **Caixa aberto / Caixa fechado** no topo virou um botão.
- Com o caixa fechado, clique no status para informar o saldo inicial e abrir sem navegar para outra aba.
- Com o caixa aberto, o mesmo botão oferece acesso rápido à gestão ou fechamento do turno.


## Caixa compacto
O Caixa/PDV foi reorganizado para monitores menores:
- produtos e resumo da venda ficam lado a lado em desktop;
- listas internas têm rolagem própria, evitando rolar a página inteira;
- campos, cards e linhas de produto ficaram mais compactos;
- o botão **Finalizar venda** permanece visível na parte inferior do card;
- em telas baixas, o sistema reduz automaticamente espaçamentos e alturas;
- em telas estreitas, volta para uma coluna para manter legibilidade.


## V7 Online / Multi-loja
Esta versão inclui sincronização em nuvem com Supabase, cache local e indicador Online/Sincronizando/Offline no cabeçalho.

O arquivo `data/cloud.json` já aponta para o projeto Supabase selecionado. A estrutura do banco precisa existir uma vez; o SQL está em `SUPABASE-SETUP.sql`.

A sincronização usa controle de versão para evitar sobrescrever silenciosamente uma versão remota mais nova. Se a internet cair, o banco local continua disponível e o indicador muda para Offline.

## Importação Excel — Produtos e Serviços
Na aba Produtos e na aba Serviços há um botão **Importar Excel**. O sistema aceita `.xlsx`, `.xls` e `.csv`, usa a primeira aba da planilha e tenta reconhecer automaticamente nomes comuns de colunas. Produtos iguais por código/código de barras são atualizados em vez de duplicados. Serviços iguais por nome também são atualizados. Após a importação, `salvar()` dispara a sincronização online existente.

A leitura de Excel usa a dependência `xlsx`; rode `npm install` nesta versão antes do primeiro teste.


## V8.2 — duas barras de busca no Caixa
O PDV agora separa completamente as pesquisas:

- **Código interno / código de barras:** somente adiciona o produto ao carrinho quando o operador ou o leitor envia **Enter**. Digitar `2`, `27`, `271` etc. não adiciona nada antes do Enter.
- **Nome, marca ou especificação:** apenas filtra produtos e serviços na tela. Nunca adiciona automaticamente ao carrinho.

Se o código informado não existir, o sistema avisa e mantém o campo pronto para correção.

## V9 — Atualização automática
O aplicativo instalado agora tem indicador de atualização e suporte ao electron-updater.
Para funcionar em produção, publique os arquivos gerados pelo electron-builder (incluindo `latest.yml` e o instalador) em um endereço HTTPS estável e substitua a URL `https://updates.example.com/eletronic-store` em `package.json`.

## V9.1 — Pagamento misto
No Caixa, marque **Dividir pagamento** para usar 2 a 4 formas na mesma venda.
Exemplo: R$ 40 em Dinheiro + R$ 60 em PIX. Com duas formas, ao preencher um valor o sistema calcula automaticamente o restante na outra. A venda só finaliza quando a soma das formas for exatamente igual ao total, e o comprovante detalha cada pagamento.
