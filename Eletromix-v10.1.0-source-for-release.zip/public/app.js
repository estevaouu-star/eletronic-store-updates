let token="acesso-local",me={id:1,nome:"Acesso local",login:"local",cargo:"admin"},config={},aparencia={corPrincipal:"#1769e0",corTopo:"#101820",corMenu:"#ffffff",corFundo:"#f4f6f8",corCartao:"#ffffff",corTexto:"#17202a",corTextoSecundario:"#6b7680",corBorda:"#e1e6ea",corPerigo:"#c62828",icone:"⚡",logoDataUrl:"",nomeSistema:"Eletronic Store"},produtos=[],servicos=[],clientes=[],vendas=[],vendedores=[],ordensServico=[],diagnosticos=[],lojas=[],cart=[],cartServicos=[],caixaAtual=null;
let printerSettings={deviceName:"",paperWidth:80,autoPrint:false};
let lojaId=Number(localStorage.getItem("es_store_id")||1);
let usbDeviceSerial="";

const ES_ICONS={
  "zap":'<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  "chevron-down":'<path d="m6 9 6 6 6-6"/>',
  "store":'<path d="M3 9l1-5h16l1 5"/><path d="M5 13v8h14v-8"/><path d="M9 21v-6h6v6"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>',
  "shopping-cart":'<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M3 4h2l2.4 10.4A2 2 0 0 0 9.4 16H18a2 2 0 0 0 2-1.6L21 8H6"/>',
  "package":'<path d="m7.5 4.3 9 5.2"/><path d="M21 8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4a2 2 0 0 0 1-1.7Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
  "users":'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/>',
  "wrench":'<path d="M14.7 6.3a4 4 0 0 0-5-5L7 4l3 3 2.7-2.7a4 4 0 0 0 2 5L6 18l-2 2 2 2 2-2 8.7-8.7a4 4 0 0 0 5-5L19 9l-3-3z"/>',
  "smartphone":'<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
  "shield-check":'<path d="M20 13c0 5-3.5 7.5-8 9-4.5-1.5-8-4-8-9V5l8-3 8 3z"/><path d="m9 12 2 2 4-4"/>',
  "receipt":'<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1z"/><path d="M16 8h-6"/><path d="M16 12h-6"/><path d="M13 16h-3"/>',
  "award":'<circle cx="12" cy="8" r="6"/><path d="M15.5 13.5 17 22l-5-3-5 3 1.5-8.5"/>',
  "layout-dashboard":'<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  "wallet-cards":'<rect width="18" height="12" x="3" y="6" rx="2"/><path d="M3 10h18"/><path d="M16 14h.01"/><path d="M5 6V4a2 2 0 0 1 2-2h10"/>',
  "clipboard-list":'<rect width="16" height="18" x="4" y="4" rx="2"/><path d="M9 4V2h6v2"/><path d="M8 10h.01"/><path d="M12 10h4"/><path d="M8 14h.01"/><path d="M12 14h4"/><path d="M8 18h.01"/><path d="M12 18h4"/>',
  "building-2":'<path d="M6 22V2l12 4v16"/><path d="M6 12H4a2 2 0 0 0-2 2v8h20"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>',
  "chart-no-axes-combined":'<path d="M3 3v18h18"/><path d="m7 16 4-5 4 3 5-7"/>',
  "palette":'<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 22a10 10 0 1 1 10-10c0 2-1 3-3 3h-1a2 2 0 0 0-2 2v1c0 2-1 4-4 4z"/>',
  "mail":'<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-10 6L2 7"/>',
  "settings":'<path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/><path d="M19.4 15a1.8 1.8 0 0 0 .36 2l.06.06-2.83 2.83-.06-.06a1.8 1.8 0 0 0-2-.36 1.8 1.8 0 0 0-1.1 1.65V21h-4v-.08A1.8 1.8 0 0 0 8.7 19.3a1.8 1.8 0 0 0-2 .36l-.06.06-2.83-2.83.06-.06a1.8 1.8 0 0 0 .36-2A1.8 1.8 0 0 0 2.6 13.7H2.5v-4h.1A1.8 1.8 0 0 0 4.2 8.6a1.8 1.8 0 0 0-.36-2l-.06-.06 2.83-2.83.06.06a1.8 1.8 0 0 0 2 .36A1.8 1.8 0 0 0 9.8 2.5V2.4h4v.1a1.8 1.8 0 0 0 1.1 1.63 1.8 1.8 0 0 0 2-.36l.06-.06 2.83 2.83-.06.06a1.8 1.8 0 0 0-.36 2 1.8 1.8 0 0 0 1.63 1.1h.1v4h-.1A1.8 1.8 0 0 0 19.4 15z"/>',
  "lock":'<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  "unlock":'<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2"/>'
};
function esIcon(name,cls=""){
  const p=ES_ICONS[name]||ES_ICONS["settings"];
  return `<svg class="es-icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
}
function renderEsIcons(root=document){
  root.querySelectorAll("[data-icon]").forEach(el=>{
    const name=el.dataset.icon;if(!name)return;
    el.innerHTML=esIcon(name);
  });
}

const $=s=>document.querySelector(s), money=v=>Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"}), esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
async function api(url,opt={}){opt.headers={...(opt.headers||{}),...(token?{Authorization:"Bearer "+token}:{}),"X-Store-Id":String(lojaId)};const r=await fetch(url,opt);if(r.status===401){logout(false);throw new Error("Sessão expirada.")}return r}
function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function showLogin(){showApp()}
function showApp(){const app=$("#app");if(app)app.classList.remove("hidden");document.querySelectorAll(".admin-only").forEach(x=>x.style.display="block")}
function openModal(title,html){
  const titleEl=$("#modalTitle"),body=$("#modalBody"),modal=$("#modal");
  if(!titleEl||!body||!modal){alert("Não foi possível abrir a janela.");return}
  titleEl.textContent=title;body.innerHTML=html;modal.classList.remove("hidden");
}
function closeModal(){const modal=$("#modal"),body=$("#modalBody");if(modal)modal.classList.add("hidden");if(body)body.innerHTML=""}
async function start(){
  try{showApp()}catch{}
  try{
    const r=await api("/api/me");
    if(r.ok){me=await r.json();caixaAtual=me.caixa;}
  }catch(e){console.error("Falha em /api/me",e)}
  try{await boot()}catch(e){console.error("Falha no carregamento inicial",e)}
}
async function login(e){e.preventDefault();const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({login:$("#login").value,senha:$("#senha").value})});const d=await r.json();if(!r.ok){$("#loginError").textContent=d.erro;return}token=d.token;me=d.usuario;localStorage.setItem("es_token",token);$("#loginError").textContent="";showApp();await boot()}
function logout(){location.reload()}
async function boot(){renderEsIcons();await Promise.all([loadAparencia(),loadConfig(),loadProdutos(),loadServicos(),loadClientes(),loadVendedores(),loadCaixa(),loadLojas()]);renderCart();renderEsIcons();await loadDashboard()}
async function loadConfig(){config=await(await api("/api/config")).json()}
async function loadAparencia(){
  aparencia=await(await api("/api/aparencia")).json();
  applyAparencia();
}
function applyAparencia(){
  const vars={
    "--accent":aparencia.corPrincipal||"#1769e0",
    "--topbar":aparencia.corTopo||"#101820",
    "--sidebar":aparencia.corMenu||"#ffffff",
    "--page-bg":aparencia.corFundo||"#f4f6f8",
    "--card-bg":aparencia.corCartao||"#ffffff",
    "--text-main":aparencia.corTexto||"#17202a",
    "--text-muted":aparencia.corTextoSecundario||"#6b7680",
    "--border":aparencia.corBorda||"#e1e6ea",
    "--danger":aparencia.corPerigo||"#c62828"
  };
  for(const [k,v] of Object.entries(vars))document.documentElement.style.setProperty(k,v);
  if($("#systemIcon")){
    if(aparencia.logoDataUrl){
      $("#systemIcon").innerHTML=`<img src="${aparencia.logoDataUrl}" alt="Logo">`;
      $("#systemIcon").classList.add("has-image");
    }else{
      $("#systemIcon").textContent=aparencia.icone||"⚡";
      $("#systemIcon").classList.remove("has-image");
    }
  }
  if($("#storeName"))$("#storeName").textContent=aparencia.nomeSistema||"Eletronic Store";
  if($("#previewName"))$("#previewName").textContent=aparencia.nomeSistema||"Eletronic Store";
  if($("#previewLogoWrap")){
    $("#previewLogoWrap").innerHTML=aparencia.logoDataUrl?`<img src="${aparencia.logoDataUrl}" alt="Logo">`:`<span id="previewIcon">${esc(aparencia.icone||"⚡")}</span>`;
  }
  document.title=aparencia.nomeSistema||"Eletronic Store";
}
async function loadAppearanceForm(){
  await loadAparencia();
  const map={
    appearanceName:"nomeSistema",appearanceIcon:"icone",appearanceColor:"corPrincipal",
    appearanceTop:"corTopo",appearanceMenu:"corMenu",appearanceBackground:"corFundo",
    appearanceCard:"corCartao",appearanceText:"corTexto",appearanceMuted:"corTextoSecundario",
    appearanceBorder:"corBorda",appearanceDanger:"corPerigo"
  };
  for(const [id,key] of Object.entries(map))if($("#"+id))$("#"+id).value=aparencia[key]||"";
  if($("#appearanceLogoData"))$("#appearanceLogoData").value=aparencia.logoDataUrl||"";
  applyAparencia();
}
async function saveAppearance(e){
  e.preventDefault();
  const body=Object.fromEntries(new FormData(e.target));
  body.logoDataUrl=$("#appearanceLogoData")?.value||"";
  const r=await api("/api/aparencia",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json();
  if(!r.ok)return toast(d.erro||"Não foi possível salvar.");
  aparencia=d;applyAparencia();toast("Personalização salva.");
}
async function handleLogoFile(file){
  if(!file)return;
  if(file.size>650000)return toast("Use uma imagem menor que aproximadamente 650 KB.");
  const reader=new FileReader();
  reader.onload=()=>{aparencia.logoDataUrl=String(reader.result||"");if($("#appearanceLogoData"))$("#appearanceLogoData").value=aparencia.logoDataUrl;applyAparencia();};
  reader.readAsDataURL(file);
}
const themes={
  blue:{corPrincipal:"#1769e0",corTopo:"#101820",corMenu:"#ffffff",corFundo:"#f4f6f8",corCartao:"#ffffff",corTexto:"#17202a",corTextoSecundario:"#6b7680",corBorda:"#e1e6ea",corPerigo:"#c62828"},
  red:{corPrincipal:"#c62828",corTopo:"#2a1010",corMenu:"#fffafa",corFundo:"#f8f2f2",corCartao:"#ffffff",corTexto:"#261818",corTextoSecundario:"#7b6464",corBorda:"#ead7d7",corPerigo:"#9d1010"},
  green:{corPrincipal:"#198754",corTopo:"#10291f",corMenu:"#f9fffb",corFundo:"#f1f7f4",corCartao:"#ffffff",corTexto:"#173126",corTextoSecundario:"#63786d",corBorda:"#d7e6dd",corPerigo:"#c62828"},
  purple:{corPrincipal:"#7b2cbf",corTopo:"#24102f",corMenu:"#fcf9ff",corFundo:"#f6f1fa",corCartao:"#ffffff",corTexto:"#2b1b34",corTextoSecundario:"#75677d",corBorda:"#e4d8ec",corPerigo:"#c62828"},
  dark:{corPrincipal:"#4d8dff",corTopo:"#0f1115",corMenu:"#171a20",corFundo:"#101217",corCartao:"#1c2027",corTexto:"#edf1f7",corTextoSecundario:"#aab4c0",corBorda:"#343b46",corPerigo:"#ef5350"}
};
function applyTheme(name){
  const t=themes[name];if(!t)return;
  Object.assign(aparencia,t);
  const ids={corPrincipal:"appearanceColor",corTopo:"appearanceTop",corMenu:"appearanceMenu",corFundo:"appearanceBackground",corCartao:"appearanceCard",corTexto:"appearanceText",corTextoSecundario:"appearanceMuted",corBorda:"appearanceBorder",corPerigo:"appearanceDanger"};
  for(const [key,id] of Object.entries(ids))if($("#"+id))$("#"+id).value=aparencia[key];
  applyAparencia();
}

function debounce(fn,wait=100){let t;return (...args)=>{clearTimeout(t);t=setTimeout(()=>fn(...args),wait)}}
function loadPrinterSettings(){
  try{printerSettings={...printerSettings,...JSON.parse(localStorage.getItem("es_printer")||"{}")}}catch{}
  const width=$("#printerWidth"),auto=$("#printerAuto");
  if(width)width.value=String(printerSettings.paperWidth||80);
  if(auto)auto.value=String(Boolean(printerSettings.autoPrint));
}
function savePrinterSettings(){
  const select=$("#printerSelect"),width=$("#printerWidth"),auto=$("#printerAuto");
  if(select)printerSettings.deviceName=select.value||"";
  if(width)printerSettings.paperWidth=Number(width.value)===58?58:80;
  if(auto)printerSettings.autoPrint=auto.value==="true";
  localStorage.setItem("es_printer",JSON.stringify(printerSettings));
}
async function refreshPrinters(){
  loadPrinterSettings();
  const select=$("#printerSelect"),status=$("#printerStatus");
  if(!select)return;
  if(!window.desktopPrinter){select.innerHTML='<option value="">Disponível somente no aplicativo Windows</option>';if(status)status.textContent="Abra o Eletronic Store instalado para impressão direta.";return}
  try{
    const printers=await window.desktopPrinter.list();
    if(!printers.length){select.innerHTML='<option value="">Nenhuma impressora encontrada</option>';if(status)status.textContent="O Windows não encontrou nenhuma impressora instalada.";return}
    const defaultPrinter=printers.find(p=>p.isDefault);
    if(!printerSettings.deviceName||!printers.some(p=>p.name===printerSettings.deviceName))printerSettings.deviceName=defaultPrinter?.name||printers[0].name;
    select.innerHTML=printers.map(p=>`<option value="${esc(p.name)}">${esc(p.displayName||p.name)}${p.isDefault?" · padrão":""}</option>`).join("");
    select.value=printerSettings.deviceName;
    savePrinterSettings();
    if(status)status.textContent=`Pronta: ${printers.find(p=>p.name===select.value)?.displayName||select.value}`;
  }catch(err){console.error(err);if(status)status.textContent="Não foi possível listar as impressoras."}
}
function receiptPrintPayload(){
  const el=$("#receiptPrint");
  if(!el)return null;
  return {html:el.outerHTML,deviceName:printerSettings.deviceName,paperWidth:printerSettings.paperWidth,itemCount:el.querySelectorAll("tbody tr").length};
}
async function directPrintReceipt(){
  if(!window.desktopPrinter)return toast("Impressão direta disponível somente no aplicativo Windows.");
  if(!printerSettings.deviceName){await refreshPrinters();if(!printerSettings.deviceName)return toast("Selecione uma impressora em Configurações.")}
  const payload=receiptPrintPayload();if(!payload)return toast("Comprovante não encontrado.");
  const status=$("#printerStatus");if(status)status.textContent="Enviando para a impressora...";
  const r=await window.desktopPrinter.print(payload);
  if(r?.success){if(status)status.textContent="Comprovante enviado para a impressora.";toast("Comprovante impresso.")}else{if(status)status.textContent="Falha na impressão.";toast(`Falha ao imprimir: ${r?.failureReason||"erro desconhecido"}`)}
}
async function testPrinter(){
  if(!window.desktopPrinter)return toast("Abra pelo aplicativo Windows para testar a impressora.");
  savePrinterSettings();
  if(!printerSettings.deviceName){await refreshPrinters();if(!printerSettings.deviceName)return toast("Selecione uma impressora.")}
  const html=`<div class="receipt"><h2>Eletronic Store</h2><p>TESTE DE IMPRESSÃO</p><p>${new Date().toLocaleString("pt-BR")}</p><table><tbody><tr><td>Impressora térmica</td><td>1</td><td>OK</td></tr></tbody></table><div class="receipt-total"><span>STATUS</span><span>OK</span></div><p>Se você está lendo isto, a impressão direta está funcionando.</p></div>`;
  const r=await window.desktopPrinter.print({html,deviceName:printerSettings.deviceName,paperWidth:printerSettings.paperWidth,itemCount:1});
  toast(r?.success?"Teste impresso com sucesso.":`Falha no teste: ${r?.failureReason||"erro"}`);
}
async function loadProdutos(){produtos=await(await api("/api/produtos")).json();renderProdutos();renderBuscaProdutos()}
async function loadServicos(){servicos=await(await api("/api/servicos")).json();renderServicos();renderBuscaProdutos()}
async function loadClientes(){clientes=await(await api("/api/clientes")).json();renderClientes();renderClienteSelect()}

function pdvLockKey(tipo){return `es_pdv_lock_${tipo}_${lojaId}`}
function getPdvLock(tipo){try{return JSON.parse(localStorage.getItem(pdvLockKey(tipo))||"null")}catch{return null}}
function isPdvLocked(tipo){return Boolean(getPdvLock(tipo)?.locked)}
function updatePdvLockUi(tipo){
  const isVend=tipo==="vendedor",sel=$(isVend?"#vendedorVenda":"#clienteVenda"),btn=$(isVend?"#lockVendedorBtn":"#lockClienteBtn"),status=$(isVend?"#vendedorLockStatus":"#clienteLockStatus"),pref=getPdvLock(tipo);
  if(!sel||!btn)return;
  let locked=Boolean(pref?.locked);
  if(locked){const value=String(pref.value??"");const existe=[...sel.options].some(o=>o.value===value);if(existe)sel.value=value;else{localStorage.removeItem(pdvLockKey(tipo));locked=false}}
  sel.disabled=locked;btn.innerHTML=esIcon(locked?"lock":"unlock");btn.classList.toggle("locked",locked);btn.title=locked?`Destravar ${tipo}`:`Travar ${tipo}`;
  if(status){status.textContent=locked?"Travado":"Livre";status.classList.toggle("locked",locked)}
}
function applyPdvLocks(){updatePdvLockUi("vendedor");updatePdvLockUi("cliente")}
function togglePdvLock(tipo){
  const isVend=tipo==="vendedor",sel=$(isVend?"#vendedorVenda":"#clienteVenda"),current=getPdvLock(tipo);if(!sel)return;
  if(current?.locked){localStorage.removeItem(pdvLockKey(tipo));updatePdvLockUi(tipo);toast(`${isVend?"Vendedor":"Cliente"} destravado.`);return}
  if(isVend&&!sel.value)return toast("Selecione um vendedor antes de travar.");
  localStorage.setItem(pdvLockKey(tipo),JSON.stringify({locked:true,value:sel.value}));updatePdvLockUi(tipo);toast(`${isVend?"Vendedor":"Cliente"} travado para as próximas vendas.`)
}
function limparSelecoesPdvAposVenda(){if(!isPdvLocked("vendedor")&&$("#vendedorVenda"))$("#vendedorVenda").value="";if(!isPdvLocked("cliente")&&$("#clienteVenda"))$("#clienteVenda").value="";applyPdvLocks()}

async function loadVendedores(){const r=await api("/api/vendedores");vendedores=await r.json();const s=$("#vendedorVenda");if(s){const a=s.value;s.innerHTML=`<option value="">Selecione o vendedor...</option>${vendedores.filter(v=>v.ativo).map(v=>`<option value="${v.id}">${esc(v.nome)}${v.codigo?` · ${esc(v.codigo)}`:""}</option>`).join("")}`;if([...s.options].some(o=>o.value===a))s.value=a;updatePdvLockUi("vendedor")}renderListaVendedores()}
function renderListaVendedores(){const e=$("#listaVendedores");if(e)e.innerHTML=vendedores.map(v=>`<div class="seller-row"><div><b>${esc(v.nome)}</b><small>${esc(v.codigo||"Sem código")} · ${v.ativo?"Ativo":"Inativo"}</small></div><button class="secondary small" onclick="editarVendedor(${v.id})">Editar</button></div>`).join("")||"<p class='muted'>Nenhum vendedor cadastrado.</p>"}
function novoVendedor(){openModal("Novo vendedor",`<form id="vendForm" class="form-grid"><div><label>Nome</label><input name="nome" required></div><div><label>Código</label><input name="codigo"></div><button class="primary full">Cadastrar</button></form>`);$("#vendForm").onsubmit=async e=>{e.preventDefault();const r=await api("/api/vendedores",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadVendedores()}}
function editarVendedor(id){const v=vendedores.find(x=>x.id===id);openModal("Editar vendedor",`<form id="vendEdit" class="form-grid"><div><label>Nome</label><input name="nome" value="${esc(v.nome)}"></div><div><label>Código</label><input name="codigo" value="${esc(v.codigo||"")}"></div><div><label>Status</label><select name="ativo"><option value="true" ${v.ativo?"selected":""}>Ativo</option><option value="false" ${!v.ativo?"selected":""}>Inativo</option></select></div><button class="primary full">Salvar</button></form>`);$("#vendEdit").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.ativo=d.ativo==="true";const r=await api(`/api/vendedores/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)}),o=await r.json();if(!r.ok)return toast(o.erro);closeModal();await loadVendedores()}}
async function loadDesempenhoVendedores(){const n=new Date(),iso=d=>d.toISOString().slice(0,10);if(!$("#vendDe").value)$("#vendDe").value=iso(new Date(n.getFullYear(),n.getMonth(),1));if(!$("#vendAte").value)$("#vendAte").value=iso(n);const r=await api(`/api/vendedores/desempenho?de=${$("#vendDe").value}&ate=${$("#vendAte").value}&todas=${$("#vendTodasLojas").checked?1:0}`),d=await r.json();$("#vendTotalVendas").textContent=d.vendas;$("#vendTotalFat").textContent=money(d.faturamento);$("#vendMelhor").textContent=d.ranking[0]?.nome||"-";const it=[...d.ranking].sort((a,b)=>b.itens-a.itens);$("#vendMaisItens").textContent=it[0]?`${it[0].nome} · ${it[0].itens}`:"-";$("#vendRanking").innerHTML=d.ranking.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.nome)}</td><td>${x.vendas}</td><td>${x.itens}</td><td>${money(x.faturamento)}</td><td>${money(x.ticketMedio)}</td><td>${x.produtoDestaque?`${esc(x.produtoDestaque.nome)} · ${x.produtoDestaque.quantidade}`:"-"}</td></tr>`).join("")||"<tr><td colspan='7'>Sem vendas.</td></tr>";$("#vendProdutos").innerHTML=d.porProduto.map(x=>`<tr><td>${esc(x.nome)}</td><td>${x.quantidade}</td><td>${esc(x.vendedores[0]?.nome||"-")}</td><td>${x.vendedores[0]?.quantidade||0}</td></tr>`).join("")||"<tr><td colspan='4'>Sem produtos vendidos.</td></tr>"}
async function loadCaixa(){caixaAtual=await(await api("/api/caixa/status")).json();renderCaixa()}
function renderCaixa(){const badge=$("#cashBadge"),box=$("#cashStatusBox");if(caixaAtual){badge.textContent="Caixa aberto";badge.className="badge ok";$("#openCashBox").classList.add("hidden");$("#closeCashBox").classList.remove("hidden");box.innerHTML=`<p><b>Caixa #${caixaAtual.id}</b></p><p>Aberto em: ${new Date(caixaAtual.abertoEm).toLocaleString("pt-BR")}</p><p>Saldo inicial: ${money(caixaAtual.saldoInicial)}</p>`}else{badge.textContent="Caixa fechado";badge.className="badge warn";$("#openCashBox").classList.remove("hidden");$("#closeCashBox").classList.add("hidden");box.innerHTML='<div class="warning-box">Nenhum caixa aberto. Abra um caixa para registrar vendas.</div>'}}

function normalizarBusca(v){
  return String(v||"").trim().toLowerCase();
}

function adicionarProdutoPorCodigo(){
  const campo=$("#buscaCodigo");
  const termo=String(campo?.value||"").trim();
  if(!termo)return;

  const chave=normalizarBusca(termo);
  const produto=produtos.find(p=>
    p.ativo && (
      normalizarBusca(p.codigo)===chave ||
      normalizarBusca(p.codigoBarras)===chave
    )
  );

  if(!produto){
    toast(`Código "${termo}" não encontrado.`);
    campo?.select();
    return;
  }

  if(Number(produto.estoque||0)<=0){
    toast(`${produto.nome}: produto sem estoque.`);
    campo?.select();
    return;
  }

  add(produto.id);
  campo.value="";
  campo.focus();
  toast(`${produto.nome} adicionado ao carrinho.`);
}

function tratarBuscaCodigo(e){
  // Digitar números nunca adiciona sozinho. Leitor de barras normalmente envia Enter ao final.
  if(e.key!=="Enter")return;
  e.preventDefault();
  adicionarProdutoPorCodigo();
}

function renderBuscaProdutos(){
  const q=normalizarBusca($("#buscaTexto")?.value);

  const aAll=produtos.filter(p=>{
    if(!p.ativo)return false;
    if(!q)return true;
    const campos=[
      p.nome,
      p.marca,
      p.categoria,
      p.codigo,
      p.codigoBarras
    ].map(normalizarBusca);
    return campos.some(v=>v.includes(q));
  });
  const a=aAll.slice(0,60);

  $("#listaProdutos").innerHTML=
    (a.map(p=>`<div class="product"><div><b>${esc(p.nome)}</b><small>${esc(p.codigo)}${p.codigoBarras?` · Barras: ${esc(p.codigoBarras)}`:""}${p.marca?` · ${esc(p.marca)}`:""}${p.categoria?` · ${esc(p.categoria)}`:""} · Estoque: ${p.estoque} · ${money(p.precoVenda)}</small></div><button onclick="add(${p.id})">Adicionar</button></div>`).join("")||"<p>Nenhum produto encontrado.</p>")
    +(aAll.length>60?`<p class="muted list-limit">Mostrando 60 de ${aAll.length}. Refine a busca para encontrar os demais.</p>`:"");

  const ssAll=servicos.filter(s=>{
    if(!s.ativo)return false;
    if(!q)return true;
    return [s.nome,s.categoria,s.descricao].map(normalizarBusca).some(v=>v.includes(q));
  });
  const ss=ssAll.slice(0,30);

  $("#listaServicos").innerHTML=
    (ss.map(s=>`<div class="product"><div><b>${esc(s.nome)}</b><small>${esc(s.categoria)} · ${money(s.preco)}</small></div><button onclick="addServico(${s.id})">Adicionar</button></div>`).join("")||"<p>Nenhum serviço encontrado.</p>")
    +(ssAll.length>30?`<p class="muted list-limit">Mostrando 30 de ${ssAll.length} serviços.</p>`:"");
}
function add(id){
  const p=produtos.find(x=>x.id===id);if(!p||!p.ativo||p.estoque<=0)return toast("Produto sem estoque.");
  const i=cart.find(x=>x.produtoId===id);
  if(i){if(i.quantidade>=p.estoque)return toast("Quantidade maior que o estoque.");i.quantidade++}else cart.push({produtoId:id,quantidade:1,acrescimoUnitario:0});
  renderCart();
}
function addServico(id){
  const s=servicos.find(x=>x.id===id);if(!s||!s.ativo)return;
  const i=cartServicos.find(x=>x.servicoId===id);
  if(i)i.quantidade++;else cartServicos.push({servicoId:id,quantidade:1,acrescimoUnitario:0});
  renderCart();
}
function change(id,d){
  const i=cart.find(x=>x.produtoId===id),p=produtos.find(x=>x.id===id);if(!i||!p)return;
  i.quantidade+=d;if(i.quantidade>p.estoque)i.quantidade=p.estoque;if(i.quantidade<=0)cart=cart.filter(x=>x.produtoId!==id);renderCart();
}
function changeServico(id,d){
  const i=cartServicos.find(x=>x.servicoId===id);if(!i)return;
  i.quantidade+=d;if(i.quantidade<=0)cartServicos=cartServicos.filter(x=>x.servicoId!==id);renderCart();
}
function setItemSurcharge(tipo,id,value){
  const list=tipo==="produto"?cart:cartServicos;
  const key=tipo==="produto"?"produtoId":"servicoId";
  const item=list.find(x=>x[key]===id);if(!item)return;
  item.acrescimoUnitario=Math.max(0,Number(value)||0);renderCart();
}
function calcularDesconto(subtotalComAcrescimo){
  const valor=Math.max(0,Number($("#desc")?.value)||0);
  const tipo=$("#discountType")?.value||"value";
  if(tipo==="percent"){
    const pct=Math.min(100,valor);
    return {valor:subtotalComAcrescimo*(pct/100),percentual:pct};
  }
  const desconto=Math.min(valor,subtotalComAcrescimo);
  return {valor:desconto,percentual:subtotalComAcrescimo>0?(desconto/subtotalComAcrescimo)*100:0};
}
function renderCart(){
  const el=$("#cart");
  const linhasProdutos=cart.map(i=>{
    const p=produtos.find(x=>x.id===i.produtoId),a=Number(i.acrescimoUnitario)||0;
    return `<div class="ci cart-adjustable"><div><b>${esc(p.nome)}</b><br><small>Produto · Base ${money(p.precoVenda)}${a?` · + ${money(a)} por un.`:""}</small><div class="item-surcharge"><span>Acréscimo/un.</span><input type="number" min="0" step=".01" value="${a}" onchange="setItemSurcharge('produto',${p.id},this.value)"></div></div><div class="qty"><button onclick="change(${p.id},-1)">−</button> ${i.quantidade} <button onclick="change(${p.id},1)">+</button></div><b>${money((p.precoVenda+a)*i.quantidade)}</b></div>`;
  });
  const linhasServicos=cartServicos.map(i=>{
    const s=servicos.find(x=>x.id===i.servicoId),a=Number(i.acrescimoUnitario)||0;
    return `<div class="ci cart-adjustable"><div><b>${esc(s.nome)}</b><br><small>Serviço · Base ${money(s.preco)}${a?` · + ${money(a)} por un.`:""}</small><div class="item-surcharge"><span>Acréscimo/un.</span><input type="number" min="0" step=".01" value="${a}" onchange="setItemSurcharge('servico',${s.id},this.value)"></div></div><div class="qty"><button onclick="changeServico(${s.id},-1)">−</button> ${i.quantidade} <button onclick="changeServico(${s.id},1)">+</button></div><b>${money((s.preco+a)*i.quantidade)}</b></div>`;
  });
  el.innerHTML=(linhasProdutos.length||linhasServicos.length)?[...linhasProdutos,...linhasServicos].join(""):"<p class='muted'>O carrinho está vazio.</p>";
  const subProdutos=cart.reduce((sum,i)=>{const p=produtos.find(x=>x.id===i.produtoId);return sum+(p.precoVenda+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);
  const subServicos=cartServicos.reduce((sum,i)=>{const s=servicos.find(x=>x.id===i.servicoId);return sum+(s.preco+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);
  const sub=subProdutos+subServicos,globalAdd=Number($("#surcharge")?.value)||0,baseDesconto=sub+globalAdd;
  const desconto=calcularDesconto(baseDesconto);
  $("#sub").textContent=money(sub);
  $("#total").textContent=money(Math.max(0,baseDesconto-desconto.valor));
  const preview=$("#discountPreview");
  if(preview){
    preview.textContent=$("#discountType")?.value==="percent"?`= ${money(desconto.valor)}`:`≈ ${desconto.percentual.toFixed(1)}%`;
  }
;if($("#splitPayment")?.checked)renderSplitPayments()}
window.setItemSurcharge=setItemSurcharge;
function renderClienteSelect(){const sel=$("#clienteVenda");if(!sel)return;const current=sel.value;sel.innerHTML='<option value="">Consumidor final</option>'+clientes.filter(c=>c.ativo).map(c=>`<option value="${c.id}">${esc(c.nome)}${c.cpf?" · "+esc(c.cpf):""}</option>`).join("");if([...sel.options].some(o=>o.value===current))sel.value=current;updatePdvLockUi("cliente")}

let splitPaymentLines=[{forma:"PIX",valor:0},{forma:"Dinheiro",valor:0}];

function totalAtualVenda(){
  const subProdutos=cart.reduce((sum,i)=>{const p=produtos.find(x=>x.id===i.produtoId);return sum+(p.precoVenda+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);
  const subServicos=cartServicos.reduce((sum,i)=>{const s=servicos.find(x=>x.id===i.servicoId);return sum+(s.preco+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);
  const acrescimo=Number($("#surcharge")?.value)||0;
  return Math.max(0,subProdutos+subServicos+acrescimo-calcularDesconto(subProdutos+subServicos+acrescimo).valor);
}
function renderSplitPayments(){
  const box=$("#splitPaymentRows");if(!box)return;
  const total=totalAtualVenda();
  box.innerHTML=splitPaymentLines.map((p,i)=>`<div class="split-payment-row">
    <select class="split-pay-method" data-i="${i}"><option ${p.forma==="PIX"?"selected":""}>PIX</option><option ${p.forma==="Dinheiro"?"selected":""}>Dinheiro</option><option ${p.forma==="Débito"?"selected":""}>Débito</option><option ${p.forma==="Crédito"?"selected":""}>Crédito</option></select>
    <input class="split-pay-value" data-i="${i}" type="number" min="0" step=".01" value="${Number(p.valor||0).toFixed(2)}">
    ${splitPaymentLines.length>2?`<button class="icon-danger split-pay-remove" data-i="${i}" type="button">×</button>`:""}
  </div>`).join("");
  const dist=Math.round(splitPaymentLines.reduce((a,p)=>a+(Number(p.valor)||0),0)*100)/100;
  const rem=Math.round((total-dist)*100)/100;
  if($("#splitPaymentDistributed"))$("#splitPaymentDistributed").textContent=money(dist);
  if($("#splitPaymentRemaining")){$("#splitPaymentRemaining").textContent=money(rem);$("#splitPaymentRemaining").classList.toggle("payment-ok",Math.abs(rem)<0.01);$("#splitPaymentRemaining").classList.toggle("payment-bad",Math.abs(rem)>=0.01)}
}
function toggleSplitPayment(){
  const on=Boolean($("#splitPayment")?.checked);
  if($("#singlePaymentBox"))$("#singlePaymentBox").hidden=on;
  if($("#splitPaymentBox"))$("#splitPaymentBox").hidden=!on;
  if(on){
    const total=totalAtualVenda();
    if(!splitPaymentLines.some(p=>Number(p.valor)>0)){splitPaymentLines=[{forma:"PIX",valor:0},{forma:"Dinheiro",valor:total}]}
    renderSplitPayments();
  }
}
function pagamentosDaVenda(){
  if(!$("#splitPayment")?.checked)return null;
  return splitPaymentLines.map(p=>({forma:p.forma,valor:Math.round((Number(p.valor)||0)*100)/100})).filter(p=>p.valor>0);
}
function resetPagamentos(){
  if($("#splitPayment"))$("#splitPayment").checked=false;
  splitPaymentLines=[{forma:"PIX",valor:0},{forma:"Dinheiro",valor:0}];
  toggleSplitPayment();
}
async function finish(){if(!caixaAtual)return toast("Abra o caixa antes de vender.");if(!cart.length&&!cartServicos.length)return toast("Adicione produtos ou serviços ao carrinho.");const pagamentos=pagamentosDaVenda();if($("#splitPayment")?.checked){const soma=Math.round((pagamentos||[]).reduce((a,p)=>a+p.valor,0)*100)/100,totalEsperado=Math.round(totalAtualVenda()*100)/100;if((pagamentos||[]).length<2)return toast("Informe pelo menos duas formas de pagamento.");if(Math.abs(soma-totalEsperado)>0.009)return toast(`Falta distribuir ${money(totalEsperado-soma)} no pagamento.`);}const subProdutos=cart.reduce((sum,i)=>{const p=produtos.find(x=>x.id===i.produtoId);return sum+(p.precoVenda+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);const subServicos=cartServicos.reduce((sum,i)=>{const s=servicos.find(x=>x.id===i.servicoId);return sum+(s.preco+(Number(i.acrescimoUnitario)||0))*i.quantidade},0);const acrescimo=Number($("#surcharge")?.value)||0;const descontoCalc=calcularDesconto(subProdutos+subServicos+acrescimo);const r=await api("/api/vendas",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({itens:cart,servicos:cartServicos,desconto:descontoCalc.valor,descontoPercentual:$("#discountType")?.value==="percent"?descontoCalc.percentual:null,acrescimo,formaPagamento:$("#pay").value,pagamentos,clienteId:$("#clienteVenda").value||null,vendedorId:$("#vendedorVenda")?.value||null,compradorDocumento:$("#compradorDocumento").value,compradorTelefone:$("#compradorTelefone").value,compradorEmail:$("#compradorEmail").value})});const d=await r.json();if(!r.ok)return toast(d.erro);cart=[];cartServicos=[];$("#desc").value=0;if($("#discountType"))$("#discountType").value="value";if($("#surcharge"))$("#surcharge").value=0;resetPagamentos();$("#compradorDocumento").value="";$("#compradorTelefone").value="";$("#compradorEmail").value="";limparSelecoesPdvAposVenda();await Promise.all([loadProdutos(),loadDashboard()]);renderCart();showReceipt(d);if(printerSettings.autoPrint)setTimeout(()=>directPrintReceipt(),120);toast(`Venda #${d.id} finalizada!`)}
function showReceipt(v){openModal(`Comprovante da venda #${v.id}`,`<div class="receipt" id="receiptPrint">${aparencia.logoDataUrl?`<div class="receipt-logo"><img src="${aparencia.logoDataUrl}" alt="Logo"></div>`:""}<h2>${esc(config.nomeLoja||aparencia.nomeSistema||"Eletronic Store")}</h2>${config.cnpj?`<p>CNPJ: ${esc(config.cnpj)}</p>`:""}${config.endereco?`<p>${esc(config.endereco)}</p>`:""}<p>${new Date(v.criadoEm).toLocaleString("pt-BR")}</p><p>Cliente: ${esc(v.clienteNome)}</p>${v.compradorDocumento?`<p>CPF/CNPJ: ${esc(v.compradorDocumento)}</p>`:""}${v.compradorTelefone?`<p>Telefone: ${esc(v.compradorTelefone)}</p>`:""}${v.compradorEmail?`<p>E-mail: ${esc(v.compradorEmail)}</p>`:""}<p>Vendedor: ${esc(v.vendedorNome||v.usuarioNome)}</p><table><thead><tr><th>Item</th><th>Qtd</th><th>Total</th></tr></thead><tbody>${v.itens.map(i=>`<tr><td>${esc(i.nomeProduto)}<br><small>${money(i.precoUnitario)}${i.acrescimoUnitario?` + ${money(i.acrescimoUnitario)} acréscimo`:""}</small></td><td>${i.quantidade}</td><td>${money(i.subtotal)}</td></tr>`).join("")}</tbody></table><p>Subtotal: ${money(v.subtotal)}<br>Acréscimo geral: ${money(v.acrescimo||0)}<br>Desconto: ${money(v.desconto)}<br>Pagamento: ${esc(v.formaPagamento)}${Array.isArray(v.pagamentos)&&v.pagamentos.length>1?`<br>${v.pagamentos.map(p=>`${esc(p.forma)}: ${money(p.valor)}`).join("<br>")}`:""}</p><div class="receipt-total"><span>TOTAL</span><span>${money(v.total)}</span></div><p>${esc(config.rodapeComprovante||"")}</p></div><div class="modal-actions"><button class="secondary" onclick="closeModal()">Fechar</button><button class="primary" onclick="printReceipt()">Imprimir</button></div>`)}
async function printReceipt(){savePrinterSettings();await directPrintReceipt()}
function renderProdutos(){const q=$("#filtroProdutos").value.toLowerCase(),st=$("#filtroStatusProduto").value;const a=produtos.filter(p=>(p.nome.toLowerCase().includes(q)||p.codigo.toLowerCase().includes(q)||p.marca.toLowerCase().includes(q))&&(!st||(st==="ativo"?p.ativo:!p.ativo)));$("#tableProdutos").innerHTML=a.map(p=>`<tr><td>${esc(p.codigo)}</td><td>${esc(p.codigoBarras||"-")}</td><td>${esc(p.nome)}</td><td>${esc(p.marca)}</td><td>${money(p.precoVenda)}</td><td>${p.estoque<=p.estoqueMinimo?"⚠️ ":""}${p.estoque}</td><td class="${p.ativo?"status-ok":"status-off"}">${p.ativo?"Ativo":"Inativo"}</td><td><div class="row-actions">${`<button class="edit" onclick="editProduto(${p.id})">Editar</button><button class="edit" onclick="stockProduto(${p.id})">Estoque</button>`}</div></td></tr>`).join("")}
function produtoForm(p={}){return `<form id="modalProductForm" class="form-grid"><div><label>Código interno</label><input name="codigo" value="${esc(p.codigo||"")}" required></div><div><label>Código de barras</label><input name="codigoBarras" value="${esc(p.codigoBarras||"")}" placeholder="EAN/UPC ou código interno"></div><div><label>Nome</label><input name="nome" value="${esc(p.nome||"")}" required></div><div><label>Categoria</label><input name="categoria" value="${esc(p.categoria||"")}" required></div><div><label>Marca</label><input name="marca" value="${esc(p.marca||"")}" required></div><div><label>Preço de custo</label><input name="precoCusto" type="number" step=".01" value="${p.precoCusto??0}"></div><div><label>Preço de venda</label><input name="precoVenda" type="number" step=".01" value="${p.precoVenda??0}" required></div><div><label>Estoque mínimo</label><input name="estoqueMinimo" type="number" value="${p.estoqueMinimo??1}"></div>${p.id?`<div><label>Status</label><select name="ativo"><option value="true" ${p.ativo?"selected":""}>Ativo</option><option value="false" ${!p.ativo?"selected":""}>Inativo</option></select></div>`:`<div><label>Estoque inicial</label><input name="estoque" type="number" value="0"></div>`}<button class="primary full">${p.id?"Salvar alterações":"Cadastrar produto"}</button></form>`}
async function arquivoParaBase64(file){return await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(",")[1]||"");r.onerror=reject;r.readAsDataURL(file)})}
async function importarPlanilha(tipo,file){
  if(!file)return;if(file.size>15*1024*1024)return toast("A planilha é grande demais. Use um arquivo de até 15 MB.");
  if(!confirm(`Importar todos os ${tipo} desta planilha para a loja atual? Registros com a mesma identificação serão atualizados.`))return;
  try{toast("Lendo planilha...");const base64=await arquivoParaBase64(file);const r=await api(`/api/importar/${tipo}-excel`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({base64,nome:file.name})});const d=await r.json();if(!r.ok)return toast(d.erro||"Falha na importação.");
    if(tipo==="produtos")await loadProdutos();else await loadServicos();
    toast(`Importação concluída: ${d.criados} novos, ${d.atualizados} atualizados, ${d.ignorados} ignorados.`);
    openModal("Importação concluída",`<div class="import-result"><h3>${d.total} linhas processadas</h3><p><b>${d.criados}</b> novos · <b>${d.atualizados}</b> atualizados · <b>${d.ignorados}</b> ignorados</p><p class="muted">Os dados foram salvos na loja atual e entram na sincronização online automaticamente.</p><button class="primary full" onclick="closeModal()">Concluir</button></div>`);
  }catch(e){console.error(e);toast("Não foi possível importar a planilha.");}
}
function newProduto(){openModal("Novo produto",produtoForm());$("#modalProductForm").onsubmit=e=>saveProduto(e)}
function editProduto(id){const p=produtos.find(x=>x.id===id);openModal("Editar produto",produtoForm(p));$("#modalProductForm").onsubmit=e=>saveProduto(e,id)}
async function saveProduto(e,id=null){
  e.preventDefault();
  try{
    const raw=Object.fromEntries(new FormData(e.target));
    if(id)raw.ativo=raw.ativo==="true";
    const r=await api(id?`/api/produtos/${id}`:"/api/produtos",{
      method:id?"PUT":"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(raw)
    });
    const d=await r.json();
    if(!r.ok)return toast(d.erro||"Não foi possível salvar o produto.");
    closeModal();
    await loadProdutos();
    toast(id?"Produto atualizado.":"Produto cadastrado.");
  }catch(err){
    console.error("Erro ao salvar produto",err);
    toast("Erro ao salvar o produto. Verifique o servidor.");
  }
}
function stockProduto(id){const p=produtos.find(x=>x.id===id);openModal(`Estoque · ${p.nome}`,`<p>Saldo atual: <b>${p.estoque}</b></p><form id="stockForm"><label>Tipo</label><select name="tipo"><option value="entrada">Entrada</option><option value="saida">Saída</option><option value="ajuste">Ajuste (+ ou -)</option></select><label>Quantidade</label><input name="quantidade" type="number" required><label>Motivo</label><input name="motivo" placeholder="Ex.: Compra do fornecedor"><button class="primary">Registrar movimentação</button></form>`);$("#stockForm").onsubmit=async e=>{e.preventDefault();const r=await api(`/api/produtos/${id}/estoque`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadProdutos();toast("Estoque atualizado.")}}
function renderClientes(){const q=$("#filtroClientes").value.toLowerCase();const a=clientes.filter(c=>c.nome.toLowerCase().includes(q));$("#tableClientes").innerHTML=a.map(c=>`<tr><td>${esc(c.nome)}</td><td class="${c.ativo?"status-ok":"status-off"}">${c.ativo?"Ativo":"Inativo"}</td><td><div class="row-actions"><button class="edit" onclick="editCliente(${c.id})">Editar</button></div></td></tr>`).join("")}
function clienteForm(c={}){return `<form id="modalClientForm" class="form-grid"><div class="full"><label>Nome</label><input name="nome" value="${esc(c.nome||"")}" required></div>${c.id?`<div><label>Status</label><select name="ativo"><option value="true" ${c.ativo?"selected":""}>Ativo</option><option value="false" ${!c.ativo?"selected":""}>Inativo</option></select></div>`:""}<button class="primary full">${c.id?"Salvar alterações":"Cadastrar cliente"}</button></form>`}
function newCliente(){openModal("Novo cliente",clienteForm());$("#modalClientForm").onsubmit=e=>saveCliente(e)}
function editCliente(id){const c=clientes.find(x=>x.id===id);openModal("Editar cliente",clienteForm(c));$("#modalClientForm").onsubmit=e=>saveCliente(e,id)}
async function saveCliente(e,id=null){e.preventDefault();const raw=Object.fromEntries(new FormData(e.target));raw.cpf="";raw.telefone="";raw.email="";if(id)raw.ativo=raw.ativo==="true";const r=await api(id?`/api/clientes/${id}`:"/api/clientes",{method:id?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadClientes();toast(id?"Cliente atualizado.":"Cliente cadastrado.")}
function renderServicos(){
  const el=$("#tableServicos");if(!el)return;
  const q=$("#filtroServicos")?$("#filtroServicos").value.toLowerCase():"";
  const a=servicos.filter(s=>[s.nome,s.categoria,s.descricao].some(v=>String(v).toLowerCase().includes(q)));
  el.innerHTML=a.map(s=>`<tr><td>${esc(s.nome)}</td><td>${esc(s.categoria)}</td><td>${money(s.preco)}</td><td class="${s.ativo?"status-ok":"status-off"}">${s.ativo?"Ativo":"Inativo"}</td><td><div class="row-actions">${me.cargo==="admin"?`<button class="edit" onclick="editServico(${s.id})">Editar</button>`:""}</div></td></tr>`).join("");
}
function servicoForm(s={}){
  return `<form id="serviceForm" class="form-grid"><div><label>Nome</label><input name="nome" value="${esc(s.nome||"")}" required></div><div><label>Categoria</label><input name="categoria" value="${esc(s.categoria||"Reparo")}"></div><div class="full"><label>Descrição</label><input name="descricao" value="${esc(s.descricao||"")}"></div><div><label>Preço</label><input name="preco" type="number" step=".01" min="0" value="${s.preco??0}" required></div>${s.id?`<div><label>Status</label><select name="ativo"><option value="true" ${s.ativo?"selected":""}>Ativo</option><option value="false" ${!s.ativo?"selected":""}>Inativo</option></select></div>`:""}<button class="primary full">${s.id?"Salvar alterações":"Cadastrar serviço"}</button></form>`;
}
function newServico(){openModal("Novo serviço",servicoForm());$("#serviceForm").onsubmit=e=>saveServico(e)}
function editServico(id){const s=servicos.find(x=>x.id===id);openModal("Editar serviço",servicoForm(s));$("#serviceForm").onsubmit=e=>saveServico(e,id)}
async function saveServico(e,id=null){
  e.preventDefault();const fd=new FormData(e.target),raw=Object.fromEntries(fd);raw.enviarRelatorioDiario=Boolean(fd.get("enviarRelatorioDiario"));if(id)raw.ativo=raw.ativo==="true";
  const r=await api(id?`/api/servicos/${id}`:"/api/servicos",{method:id?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),d=await r.json();
  if(!r.ok)return toast(d.erro);closeModal();await loadServicos();toast(id?"Serviço atualizado.":"Serviço cadastrado.");
}
async function loadOS(){ordensServico=await(await api("/api/ordens-servico")).json();renderOS()}
function renderOS(){
  const q=$("#filtroOS")?$("#filtroOS").value.toLowerCase():"";
  const a=ordensServico.filter(o=>[o.clienteNome,o.aparelho,o.marca,o.modelo,o.servicoNome,o.status].some(v=>String(v).toLowerCase().includes(q)));
  $("#tableOS").innerHTML=a.map(o=>`<tr><td>#${o.id}</td><td>${esc(o.clienteNome)}</td><td>${esc(o.aparelho)}${o.modelo?` · ${esc(o.modelo)}`:""}</td><td>${esc(o.servicoNome)}</td><td>${money(o.valor)}</td><td>${esc(o.status)}</td><td>${new Date(o.atualizadoEm).toLocaleString("pt-BR")}</td><td><div class="row-actions"><button class="edit" onclick="editOS(${o.id})">Atualizar</button></div></td></tr>`).join("")||"<tr><td colspan='8'>Nenhuma ordem de serviço.</td></tr>";
}
function novaOS(){
  openModal("Nova ordem de serviço",`<form id="osForm" class="form-grid"><div><label>Cliente</label><input name="clienteNome" required></div><div><label>Telefone</label><input name="telefone"></div><div><label>Aparelho</label><input name="aparelho" placeholder="Ex.: Celular" required></div><div><label>Marca</label><input name="marca"></div><div><label>Modelo</label><input name="modelo"></div><div><label>Serviço</label><select name="servicoId"><option value="">Diagnóstico</option>${servicos.filter(s=>s.ativo).map(s=>`<option value="${s.id}">${esc(s.nome)} · ${money(s.preco)}</option>`).join("")}</select></div><div class="full"><label>Problema relatado</label><input name="problemaRelatado"></div><div class="full"><label>Observações</label><input name="observacoes"></div><button class="primary full">Criar ordem</button></form>`);
  $("#osForm").onsubmit=async e=>{e.preventDefault();const r=await api("/api/ordens-servico",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadOS();toast(`Ordem #${d.id} criada.`)}
}
function editOS(id){
  const o=ordensServico.find(x=>x.id===id);
  openModal(`Ordem #${id}`,`<p><b>${esc(o.clienteNome)}</b> · ${esc(o.aparelho)} ${esc(o.modelo||"")}</p><p class="muted">${esc(o.problemaRelatado||"Sem problema descrito.")}</p><form id="editOSForm"><label>Status</label><select name="status">${["Recebido","Em análise","Aguardando peça","Em reparo","Pronto","Entregue"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select><label>Valor</label><input name="valor" type="number" step=".01" value="${o.valor}"><label>Observações</label><input name="observacoes" value="${esc(o.observacoes||"")}"><button class="primary full">Salvar</button></form>`);
  $("#editOSForm").onsubmit=async e=>{e.preventDefault();const r=await api(`/api/ordens-servico/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadOS();toast("Ordem atualizada.")}
}
async function loadDiagnosticos(){diagnosticos=await(await api("/api/diagnosticos-seguranca")).json();renderDiagnosticos()}
function renderDiagnosticos(){
  const q=$("#filtroDiag")?$("#filtroDiag").value.toLowerCase():"";
  const a=diagnosticos.filter(d=>[d.clienteNome,d.aparelho,d.modelo,d.sistema,d.resultado].some(v=>String(v).toLowerCase().includes(q)));
  $("#tableDiag").innerHTML=a.map(d=>`<tr><td>#${d.id}</td><td>${esc(d.clienteNome)}</td><td>${esc(d.aparelho)}${d.modelo?` · ${esc(d.modelo)}`:""}</td><td>${esc(d.sistema)}</td><td>${esc(d.resultado)}</td><td>${new Date(d.atualizadoEm).toLocaleString("pt-BR")}</td><td><div class="row-actions"><button class="edit" onclick="editDiagnostico(${d.id})">Abrir</button></div></td></tr>`).join("")||"<tr><td colspan='7'>Nenhum diagnóstico.</td></tr>";
}
function novoDiagnostico(){
  openModal("Novo diagnóstico de segurança",`<form id="diagForm" class="form-grid"><div><label>Cliente</label><input name="clienteNome" required></div><div><label>Aparelho</label><input name="aparelho" placeholder="Ex.: Celular" required></div><div><label>Modelo</label><input name="modelo"></div><div><label>Sistema</label><select name="sistema"><option>Android</option><option>iOS</option><option>Outro</option></select></div><div class="full"><label>Sintomas relatados</label><div class="check-grid"><label><input type="checkbox" name="sintoma" value="Anúncios excessivos"> Anúncios excessivos</label><label><input type="checkbox" name="sintoma" value="Aplicativos desconhecidos"> Aplicativos desconhecidos</label><label><input type="checkbox" name="sintoma" value="Lentidão"> Lentidão</label><label><input type="checkbox" name="sintoma" value="Redirecionamentos no navegador"> Redirecionamentos</label><label><input type="checkbox" name="sintoma" value="Consumo anormal de bateria"> Consumo anormal de bateria</label><label><input type="checkbox" name="sintoma" value="Permissões suspeitas"> Permissões suspeitas</label></div></div><div class="full"><label>Observações</label><input name="observacoes"></div><button class="primary full">Criar diagnóstico</button></form>`);
  $("#diagForm").onsubmit=async e=>{e.preventDefault();const fd=new FormData(e.target),raw=Object.fromEntries(fd);raw.sintomas=fd.getAll("sintoma");const r=await api("/api/diagnosticos-seguranca",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadDiagnosticos();toast(`Diagnóstico #${d.id} criado.`)}
}
function editDiagnostico(id){
  const d=diagnosticos.find(x=>x.id===id),e=d.etapas||{};
  openModal(`Diagnóstico #${id}`,`<p><b>${esc(d.clienteNome)}</b> · ${esc(d.aparelho)} ${esc(d.modelo||"")}</p><p class="muted">Sintomas: ${(d.sintomas||[]).map(esc).join(", ")||"Nenhum informado"}</p><div class="warning-box">Use este checklist para orientar o atendimento. Remoções de apps e alterações no celular devem ser feitas com autorização do cliente.</div><form id="editDiagForm" style="margin-top:14px"><div class="check-list"><label><input type="checkbox" name="backupConfirmado" ${e.backupConfirmado?"checked":""}> Backup/consentimento confirmado</label><label><input type="checkbox" name="appsSuspeitosVerificados" ${e.appsSuspeitosVerificados?"checked":""}> Aplicativos suspeitos revisados</label><label><input type="checkbox" name="permissoesVerificadas" ${e.permissoesVerificadas?"checked":""}> Permissões de apps revisadas</label><label><input type="checkbox" name="navegadorVerificado" ${e.navegadorVerificado?"checked":""}> Navegador, notificações e redirecionamentos revisados</label><label><input type="checkbox" name="atualizacoesVerificadas" ${e.atualizacoesVerificadas?"checked":""}> Sistema e apps atualizados</label><label><input type="checkbox" name="playProtectVerificado" ${e.playProtectVerificado?"checked":""}> Proteção nativa do sistema verificada</label></div><label>Resultado</label><select name="resultado">${["Pendente","Nenhuma ameaça óbvia encontrada","Aplicativos suspeitos identificados","Necessita análise adicional"].map(x=>`<option ${d.resultado===x?"selected":""}>${x}</option>`).join("")}</select><label>Observações</label><input name="observacoes" value="${esc(d.observacoes||"")}"><button class="primary full">Salvar diagnóstico</button></form>`);
  $("#editDiagForm").onsubmit=async ev=>{ev.preventDefault();const f=ev.target;const raw={resultado:f.resultado.value,observacoes:f.observacoes.value,etapas:{backupConfirmado:f.backupConfirmado.checked,appsSuspeitosVerificados:f.appsSuspeitosVerificados.checked,permissoesVerificadas:f.permissoesVerificadas.checked,navegadorVerificado:f.navegadorVerificado.checked,atualizacoesVerificadas:f.atualizacoesVerificadas.checked,playProtectVerificado:f.playProtectVerificado.checked}};const r=await api(`/api/diagnosticos-seguranca/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),out=await r.json();if(!r.ok)return toast(out.erro);closeModal();await loadDiagnosticos();toast("Diagnóstico atualizado.")}
}
async function loadLojas(){
  lojas=await(await api("/api/lojas")).json();
  const ativos=lojas.filter(l=>l.ativo);
  if(!ativos.some(l=>l.id===lojaId))lojaId=ativos[0]?.id||1;
  localStorage.setItem("es_store_id",String(lojaId));
  const sel=$("#storeSelect");
  if(sel){
    sel.innerHTML=ativos.map(l=>`<option value="${l.id}">${esc(l.nome)}</option>`).join("");
    sel.value=String(lojaId);
    sel.onchange=async()=>{
      lojaId=Number(sel.value);localStorage.setItem("es_store_id",String(lojaId));
      cart=[];cartServicos=[];await boot();toast("Loja alterada.");
    };
  }
  renderLojas();
}
function renderLojas(){
  if(!$("#tableLojas"))return;
  $("#tableLojas").innerHTML=lojas.map(l=>`<tr><td><b>${esc(l.nome)}</b></td><td>${esc(l.cnpj||"-")}</td><td>${esc(l.telefone||"-")}</td><td>${esc(l.endereco||"-")}</td><td class="${l.ativo?"status-ok":"status-off"}">${l.ativo?"Ativa":"Inativa"}</td><td><div class="row-actions"><button class="edit" onclick="editLoja(${l.id})">Editar</button></div></td></tr>`).join("");
}
function lojaForm(l={}){
  return `<form id="lojaForm" class="form-grid"><div><label>Nome da loja</label><input name="nome" value="${esc(l.nome||"")}" required></div><div><label>CNPJ</label><input name="cnpj" value="${esc(l.cnpj||"")}"></div><div><label>Telefone</label><input name="telefone" value="${esc(l.telefone||"")}"></div><div><label>Endereço</label><input name="endereco" value="${esc(l.endereco||"")}"></div><div class="full"><label>Rodapé do comprovante</label><input name="rodapeComprovante" value="${esc(l.rodapeComprovante||"Obrigado pela preferência!")}"></div><div><label>E-mail do proprietário</label><input name="emailProprietario" type="email" value="${esc(l.emailProprietario||"")}"></div><div><label>Horário do relatório</label><input name="horarioRelatorio" type="time" value="${esc(l.horarioRelatorio||"20:00")}"></div><div class="full"><label class="check-line"><input type="checkbox" name="enviarRelatorioDiario" ${l.enviarRelatorioDiario?"checked":""}> Enviar relatório diário automaticamente</label></div>${l.id?`<div><label>Status</label><select name="ativo"><option value="true" ${l.ativo?"selected":""}>Ativa</option><option value="false" ${!l.ativo?"selected":""}>Inativa</option></select></div>`:""}<button class="primary full">${l.id?"Salvar alterações":"Cadastrar loja"}</button></form>`;
}
function novaLoja(){openModal("Nova loja",lojaForm());$("#lojaForm").onsubmit=e=>saveLoja(e)}
function editLoja(id){const l=lojas.find(x=>x.id===id);openModal("Editar loja",lojaForm(l));$("#lojaForm").onsubmit=e=>saveLoja(e,id)}
async function saveLoja(e,id=null){
  e.preventDefault();const raw=Object.fromEntries(new FormData(e.target));if(id)raw.ativo=raw.ativo==="true";
  const r=await api(id?`/api/lojas/${id}`:"/api/lojas",{method:id?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),d=await r.json();
  if(!r.ok)return toast(d.erro);closeModal();await loadLojas();toast(id?"Loja atualizada.":"Loja cadastrada.");
}
async function loadAllStores(){
  const a=await(await api("/api/lojas/resumo-geral")).json();
  $("#allStoresCards").innerHTML=a.map(l=>`<div class="card store-card"><h3>${esc(l.nome)}</h3><div class="summary-row"><span>Vendas hoje</span><b>${l.vendasHoje}</b></div><div class="summary-row"><span>Faturamento hoje</span><b>${money(l.faturamentoHoje)}</b></div><div class="summary-row"><span>Produtos</span><b>${l.produtos}</b></div><div class="summary-row"><span>Estoque baixo</span><b>${l.estoqueBaixo}</b></div><div class="summary-row"><span>Ordens abertas</span><b>${l.ordensAbertas}</b></div><button class="secondary full" onclick="selecionarLoja(${l.lojaId})">Abrir esta loja</button></div>`).join("");
}
async function selecionarLoja(id){lojaId=id;localStorage.setItem("es_store_id",String(id));await boot();document.querySelector('.nav[data-s="caixa"]').click()}
window.selecionarLoja=selecionarLoja;
async function instalarAdbOficial(){
  const ok=confirm("O Eletronic Store vai baixar o Android SDK Platform-Tools diretamente do Google. Ao continuar, você confirma que leu e aceita os termos do Android SDK. Deseja continuar?");
  if(!ok)return;

  const status=$("#adbInstallStatus");
  if(status)status.textContent="Baixando e configurando o ADB oficial...";

  try{
    const r=await api("/api/usb/instalar-adb",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({aceitouLicenca:true})
    });
    const d=await r.json();
    if(!r.ok){
      if(status)status.textContent=d.erro||"Falha ao instalar ADB.";
      return toast(d.erro||"Falha ao instalar ADB.");
    }
    if(status)status.textContent=`${d.mensagem} ${d.versao||""}`;
    toast("ADB instalado e pronto para uso.");
  }catch(e){
    console.error(e);
    if(status)status.textContent="Falha ao baixar/configurar o ADB.";
    toast("Não foi possível instalar o ADB.");
  }
}

let adbAuthTimer=null;

async function solicitarAutorizacaoAdb(){
  const status=$("#adbInstallStatus");
  if(status)status.textContent="Verificando se o celular foi autorizado...";

  try{
    const r=await api("/api/usb/status");
    const d=await r.json();

    if(!r.ok){
      if(status)status.textContent=d.erro||"Falha ao verificar ADB.";
      return toast(d.erro||"Falha ao verificar ADB.");
    }

    const autorizado=(d.devices||[]).find(x=>x.estado==="device");
    const naoAutorizado=(d.devices||[]).find(x=>x.estado==="unauthorized");

    if(autorizado){
      if(status)status.textContent="Celular autorizado. Já pode escanear.";
      toast("Celular autorizado.");
      return;
    }

    if(naoAutorizado){
      if(status)status.textContent="O celular foi detectado, mas ainda falta tocar em “Permitir depuração USB?” no próprio aparelho.";
      toast("Autorize na tela do celular.");
      iniciarEsperaAutorizacao();
      return;
    }

    if(status)status.textContent="Nenhum Android autorizado foi encontrado. Confira Depuração USB e o cabo.";
    toast("Confira a autorização no celular.");
  }catch(e){
    console.error(e);
    if(status)status.textContent="Não foi possível verificar o celular.";
    toast("Falha ao verificar a autorização.");
  }
}

function iniciarEsperaAutorizacao(){
  clearInterval(adbAuthTimer);
  let tentativas=0;
  const status=$("#adbInstallStatus");

  adbAuthTimer=setInterval(async()=>{
    tentativas++;
    try{
      const r=await api("/api/usb/status");
      const d=await r.json();
      const autorizado=(d.devices||[]).find(x=>x.estado==="device");
      const naoAutorizado=(d.devices||[]).find(x=>x.estado==="unauthorized");

      if(autorizado){
        clearInterval(adbAuthTimer);
        adbAuthTimer=null;
        if(status)status.textContent="Autorização concluída no celular. Já pode escanear.";
        toast("Autorização concluída.");
        return;
      }

      if(status){
        status.textContent=naoAutorizado
          ?"Aguardando você tocar em “Permitir” na tela do celular..."
          :"Aguardando o celular aparecer no ADB...";
      }

      if(tentativas>=20){
        clearInterval(adbAuthTimer);
        adbAuthTimer=null;
        if(status)status.textContent="Não foi autorizado. No celular, confirme Depuração USB e reconecte o cabo.";
      }
    }catch(e){
      console.error(e);
    }
  },3000);
}

let usbMonitorTimer=null;
let usbUltimoEstado="";
let usbScanAutomaticoEmAndamento=false;

function atualizarEstadoUsbAuto(titulo,texto,estado=""){
  const box=$("#usbAutoState");
  const title=$("#usbAutoTitle");
  const text=$("#usbAutoText");
  if(title)title.textContent=titulo;
  if(text)text.textContent=texto;
  if(box)box.dataset.state=estado;
}

async function verificarUsbAutomaticamente(){
  if(!$("#segurancaCelular")?.classList.contains("active"))return;

  try{
    const r=await api("/api/usb/status");
    const d=await r.json();

    const devices=d.devices||[];
    const fisicos=d.fisicos||[];
    const autorizado=devices.find(x=>x.estado==="device");
    const naoAutorizado=devices.find(x=>x.estado==="unauthorized");
    const offline=devices.find(x=>x.estado==="offline");
    const usbFisico=d.usbConectado||fisicos.length>0;

    let estado="nenhum";
    if(autorizado)estado=`device:${autorizado.serial}`;
    else if(naoAutorizado)estado=`unauthorized:${naoAutorizado.serial}`;
    else if(offline)estado=`offline:${offline.serial}`;
    else if(usbFisico)estado=`usb:${fisicos.map(x=>x.id||x.nome).join("|")}`;

    if(autorizado){
      atualizarEstadoUsbAuto(
        "Celular conectado e autorizado",
        "O Windows e o ADB reconheceram o aparelho. A análise será iniciada automaticamente.",
        "ok"
      );
      if(usbUltimoEstado!==estado && !usbScanAutomaticoEmAndamento){
        usbScanAutomaticoEmAndamento=true;
        toast("Celular pronto. Iniciando análise...");
        try{await scanUsb(true)}finally{usbScanAutomaticoEmAndamento=false}
      }
    }else if(naoAutorizado){
      atualizarEstadoUsbAuto(
        "Celular detectado — aguardando autorização",
        "O aparelho está conectado e o ADB o reconheceu, mas o Android ainda não autorizou este computador.",
        "waiting"
      );
    }else if(offline){
      atualizarEstadoUsbAuto(
        "Celular detectado — ADB offline",
        "O aparelho apareceu no ADB, mas a sessão ainda não está disponível.",
        "offline"
      );
    }else if(usbFisico){
      const nome=fisicos[0]?.nome||"Celular";
      atualizarEstadoUsbAuto(
        `${nome} conectado por USB`,
        d.adb
          ?"O Windows reconheceu o aparelho, mas ele ainda não está disponível para análise ADB."
          :"O Windows reconheceu o aparelho. Instale/ative o ADB para habilitar a análise.",
        "usb"
      );
    }else if(!d.adb){
      atualizarEstadoUsbAuto(
        "Nenhum celular conectado",
        "O ADB não está disponível e o Windows não detectou um aparelho móvel conectado.",
        "adb"
      );
    }else{
      atualizarEstadoUsbAuto(
        "Aguardando celular...",
        "Conecte um aparelho por USB. A detecção é automática.",
        "none"
      );
    }

    usbUltimoEstado=estado;
  }catch(e){
    console.error(e);
    atualizarEstadoUsbAuto(
      "Falha temporária na detecção",
      "O monitor continuará tentando automaticamente.",
      "error"
    );
  }
}

function iniciarMonitorUsb(){
  clearInterval(usbMonitorTimer);
  verificarUsbAutomaticamente();
  usbMonitorTimer=setInterval(verificarUsbAutomaticamente,1800);
}

async function reiniciarAdb(){
  const status=$("#adbInstallStatus");
  if(status)status.textContent="Reiniciando ADB e procurando o celular...";
  try{
    const r=await api("/api/usb/autorizar",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
    const d=await r.json();
    if(status)status.textContent=d.mensagem||d.erro||"Verificação concluída.";
    await verificarUsbAutomaticamente();
    if(!r.ok)toast(d.erro||"Falha ao reiniciar ADB.");
  }catch(e){console.error(e);if(status)status.textContent="Falha ao reiniciar ADB.";}
}
function mostrarTutorialAdb(){
  openModal("Ativar Depuração USB",`<div class="tutorial-adb">
    <p><b>Se o celular aparece no Windows, mas não no ADB:</b></p>
    <ol>
      <li>Desbloqueie o celular.</li>
      <li>Abra <b>Configurações → Sobre o telefone</b> e toque 7 vezes em <b>Número da versão / Número da compilação</b>.</li>
      <li>Volte e abra <b>Opções do desenvolvedor</b>.</li>
      <li>Ative <b>Depuração USB</b>.</li>
      <li>Reconecte o cabo. Quando aparecer <b>“Permitir depuração USB?”</b>, toque em <b>Permitir</b>.</li>
    </ol>
    <p class="muted">O computador consegue detectar o USB e reiniciar o ADB, mas o Android exige que essa primeira permissão seja confirmada no próprio aparelho.</p>
  </div>`);
}

async function scanUsb(automatico=false){
  $("#usbStatus").innerHTML="<p>Procurando aparelho...</p>";
  $("#usbSummary").textContent="Analisando...";
  const r=await api("/api/usb/scan",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});
  const d=await r.json();
  if(!r.ok){
    usbDeviceSerial="";
    $("#usbStatus").innerHTML=`<div class="warning-box">${esc(d.erro||"Falha na leitura.")}</div>`;
    $("#usbSummary").textContent="Não concluído.";
    return toast(d.erro||"Falha na leitura USB.");
  }

  usbDeviceSerial=d.device.serial||"";

  $("#usbStatus").innerHTML=`<p><b>${esc(d.device.fabricante)} ${esc(d.device.modelo)}</b></p><p>Android ${esc(d.device.android)} · SDK ${esc(d.device.sdk)}</p><p class="muted">Serial: ${esc(d.device.serial)}</p>`;
  $("#usbSummary").innerHTML=`<div class="summary-row"><span>Apps de terceiros</span><b>${d.resumo.totalAppsTerceiros}</b></div><div class="summary-row"><span>Apps para revisar</span><b>${d.resumo.appsParaRevisar}</b></div><p class="muted">${esc(d.observacao)}</p>`;

  $("#usbRisks").innerHTML=d.suspeitos.length
    ?d.suspeitos.map(a=>`<div class="risk-app">
        <div class="risk-app-head">
          <div><b>${esc(a.pacote)}</b>${a.installer?`<small>Origem: ${esc(a.installer)}</small>`:""}</div>
          <span class="fiscal-badge">${esc(a.classificacao||"Revisar")}</span>
        </div>
        <ul>${a.motivos.map(m=>`<li>${esc(m)}</li>`).join("")}</ul>
        ${a.nivel==="alto"?`<button class="danger uninstall-btn" onclick="desinstalarApp('${esc(a.pacote)}')">Desinstalar aplicativo</button>`:`<p class="muted">Sem remoção recomendada automaticamente. Revise os sinais antes de decidir.</p>`}
      </div>`).join("")
    :"<div class='success'>Nenhum aplicativo apresentou combinação de sinais que justifique revisão.</div>";

  $("#usbAllApps").innerHTML=d.apps.map(a=>`<div class="summary-row app-row">
      <span><b>${esc(a.pacote)}</b><small style="display:block">${esc(a.classificacao||"Sem classificação")}</small></span>
      <span class="app-actions">
        <span>${a.nivel==="alto"?"Atenção alta":a.nivel==="atencao"?"Revisar":a.nivel==="baixo"?"Baixo risco":a.nivel==="conhecido"?"Conhecido":"Normal"}</span>
        <button class="delete" onclick="desinstalarApp('${esc(a.pacote)}')">Desinstalar</button>
      </span>
    </div>`).join("");
}

async function desinstalarApp(pacote){
  if(!usbDeviceSerial)return toast("Escaneie o celular novamente antes de desinstalar.");
  const confirmar=confirm(`Desinstalar "${pacote}" do celular conectado?\n\nO aplicativo e os dados dele poderão ser removidos. Só continue se o cliente/aparelho estiver autorizado.`);
  if(!confirmar)return;

  const segundaConfirmacao=confirm(`Confirmar remoção de ${pacote}?`);
  if(!segundaConfirmacao)return;

  const r=await api("/api/usb/uninstall",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({serial:usbDeviceSerial,pacote})
  });
  const d=await r.json();
  if(!r.ok)return toast(d.erro||"Não foi possível desinstalar.");

  toast("Aplicativo desinstalado.");
  await scanUsb();
}
window.desinstalarApp=desinstalarApp;

async function loadVendas(){vendas=await(await api("/api/vendas")).json();renderVendas()}
function renderVendas(){const q=$("#filtroVendas").value.toLowerCase();const a=vendas.filter(v=>String(v.id).includes(q)||v.clienteNome.toLowerCase().includes(q)||v.usuarioNome.toLowerCase().includes(q));$("#tableVendas").innerHTML=a.map(v=>`<tr><td>#${v.id}</td><td>${new Date(v.criadoEm).toLocaleString("pt-BR")}</td><td>${esc(v.clienteNome)}</td><td>${esc(v.vendedorNome||v.usuarioNome)}</td><td>${esc(v.formaPagamento)}</td><td><b>${money(v.total)}</b></td><td class="${v.status==="concluida"?"status-ok":"status-off"}">${v.status}</td><td>${v.fiscal?`<span class="fiscal-badge">${v.fiscal.tipo==="rascunho-nfe"?"NF-e":"NFC-e"} rascunho</span>`:"-"}</td><td><div class="row-actions"><button class="edit" onclick="viewVenda(${v.id})">Ver</button>${me.cargo==="admin"&&v.status==="concluida"?`<button class="edit" onclick="fiscalVenda(${v.id})">Fiscal</button><button class="delete" onclick="cancelVenda(${v.id})">Cancelar</button>`:""}</div></td></tr>`).join("")||"<tr><td colspan='9'>Nenhuma venda.</td></tr>"}
async function viewVenda(id){const v=await(await api(`/api/vendas/${id}`)).json();showReceipt(v)}
async function fiscalVenda(id){const v=await(await api(`/api/vendas/${id}`)).json();openModal(`Documento fiscal · Venda #${id}`,`<div class="warning-box">Este módulo gera um rascunho interno. A autorização real precisa de certificado digital, credenciamento e integração com a SEFAZ.</div><form id="fiscalForm" class="form-grid" style="margin-top:14px"><div><label>Tipo</label><select name="tipo"><option value="nfce">NFC-e (consumidor)</option><option value="nfe">NF-e</option></select></div><div><label>Série</label><input name="serie" type="number" value="1" min="1"></div><div class="full"><label>Natureza da operação</label><input name="naturezaOperacao" value="Venda de mercadoria"></div><div class="full"><p class="muted">Comprador: ${esc(v.clienteNome)}${v.compradorDocumento?` · ${esc(v.compradorDocumento)}`:""}</p></div><button class="primary full">Gerar rascunho fiscal</button></form>`);$("#fiscalForm").onsubmit=async e=>{e.preventDefault();const r=await api(`/api/vendas/${id}/fiscal`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadVendas();toast("Rascunho fiscal gerado.")}}
async function cancelVenda(id){if(!confirm(`Cancelar a venda #${id}? O estoque será devolvido.`))return;const r=await api(`/api/vendas/${id}/cancelar`,{method:"POST"}),d=await r.json();if(!r.ok)return toast(d.erro);await Promise.all([loadVendas(),loadProdutos(),loadDashboard()]);toast("Venda cancelada.")}
async function loadDashboard(){const d=await(await api("/api/dashboard")).json();$("#dashVendas").textContent=d.vendasHoje;$("#dashFat").textContent=money(d.faturamento);$("#dashTicket").textContent=money(d.ticketMedio);$("#dashEstoque").textContent=d.estoqueBaixo;$("#pagamentosResumo").innerHTML=Object.entries(d.pagamentos).map(([k,v])=>`<div class="summary-row"><span>${esc(k)}</span><b>${money(v)}</b></div>`).join("")||"<p class='muted'>Sem vendas hoje.</p>";$("#maisVendidos").innerHTML=d.maisVendidos.map((x,i)=>`<div class="summary-row"><span>${i+1}. ${esc(x.nome)}</span><b>${x.qtd} un.</b></div>`).join("")||"<p class='muted'>Sem vendas registradas.</p>"}

function quickCashMenu(){
  if(caixaAtual?.aberto){
    openModal("Caixa aberto",`
      <div class="quick-cash-panel">
        <div class="quick-cash-state open">${esIcon("wallet-cards")}<div><b>Caixa aberto</b><span>Turno #${caixaAtual.id||""} em andamento.</span></div></div>
        <p class="muted">Você pode ir para a gestão completa ou fechar o caixa diretamente.</p>
        <div class="modal-actions">
          <button class="secondary" id="quickCashManage">Ver gestão do caixa</button>
          <button class="danger" id="quickCashClose">Fechar caixa</button>
        </div>
      </div>`);
    $("#quickCashManage").onclick=()=>{closeModal();document.querySelector('.nav[data-s="caixaGestao"]')?.click()};
    $("#quickCashClose").onclick=()=>{closeModal();quickCloseCash()};
  }else{
    openModal("Abrir caixa",`
      <div class="quick-cash-panel">
        <div class="quick-cash-state closed">${esIcon("wallet-cards")}<div><b>Caixa fechado</b><span>Abra o turno sem sair da tela atual.</span></div></div>
        <label>Saldo inicial (R$)</label>
        <input id="quickSaldoInicial" type="number" min="0" step=".01" value="0" autofocus>
        <button class="primary full" id="quickCashOpen">Abrir caixa agora</button>
      </div>`);
    $("#quickCashOpen").onclick=async()=>{
      const saldo=Number($("#quickSaldoInicial")?.value)||0;
      const r=await api("/api/caixa/abrir",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({saldoInicial:saldo})});
      const d=await r.json();if(!r.ok)return toast(d.erro);
      closeModal();await loadCaixa();toast("Caixa aberto com sucesso.");
    };
  }
}
async function quickCloseCash(){
  openModal("Fechar caixa",`
    <div class="quick-cash-panel">
      <div class="quick-cash-state open">${esIcon("wallet-cards")}<div><b>Encerrar turno</b><span>Informe o saldo final contado no caixa.</span></div></div>
      <label>Saldo final informado (R$)</label>
      <input id="quickSaldoFinal" type="number" min="0" step=".01" value="0" autofocus>
      <button class="danger full" id="quickCashConfirmClose">Confirmar fechamento</button>
    </div>`);
  $("#quickCashConfirmClose").onclick=async()=>{
    if(!confirm("Deseja realmente fechar o caixa?"))return;
    const saldo=Number($("#quickSaldoFinal")?.value)||0;
    const r=await api("/api/caixa/fechar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({saldoFinalInformado:saldo})});
    const d=await r.json();if(!r.ok)return toast(d.erro);
    closeModal();await loadCaixa();toast("Caixa fechado com sucesso.");
  };
}

async function openCash(){const r=await api("/api/caixa/abrir",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({saldoInicial:Number($("#saldoInicial").value)||0})}),d=await r.json();if(!r.ok)return toast(d.erro);await loadCaixa();toast("Caixa aberto.")}
async function closeCash(){if(!confirm("Deseja realmente fechar o caixa?"))return;const r=await api("/api/caixa/fechar",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({saldoFinalInformado:Number($("#saldoFinal").value)||0})}),d=await r.json();if(!r.ok)return toast(d.erro);await loadCaixa();openModal("Caixa fechado",`<p>Caixa #${d.id}</p><p>Total de vendas do turno: <b>${money(d.totalVendas)}</b></p><p>Saldo informado: <b>${money(d.saldoFinalInformado)}</b></p><button class="primary" onclick="closeModal()">OK</button>`)}
async function loadMovimentos(){const a=await(await api("/api/movimentos")).json();$("#tableMovimentos").innerHTML=a.map(m=>`<tr><td>${new Date(m.criadoEm).toLocaleString("pt-BR")}</td><td>${esc(m.produtoNome)}</td><td>${esc(m.tipo)}</td><td>${m.quantidade>0?"+":""}${m.quantidade}</td><td>${m.saldoAnterior}</td><td>${m.saldoAtual}</td><td>${esc(m.motivo)}</td><td>${esc(m.usuarioNome)}</td></tr>`).join("")||"<tr><td colspan='8'>Sem movimentações.</td></tr>"}
async function loadUsuarios(){const a=await(await api("/api/usuarios")).json();$("#tableUsuarios").innerHTML=a.map(u=>`<tr><td>${esc(u.nome)}</td><td>${esc(u.login)}</td><td>${esc(u.cargo)}</td><td class="${u.ativo?"status-ok":"status-off"}">${u.ativo?"Ativo":"Inativo"}</td><td><div class="row-actions"><button class="edit" onclick="editUsuario(${u.id})">Editar</button></div></td></tr>`).join("")}
function newUsuario(){openModal("Novo usuário",`<form id="userForm" class="form-grid"><div><label>Nome</label><input name="nome" required></div><div><label>Login</label><input name="login" required></div><div><label>Senha</label><input name="senha" type="password" required></div><div><label>Cargo</label><select name="cargo"><option value="vendedor">Vendedor</option><option value="admin">Administrador</option></select></div><button class="primary full">Criar usuário</button></form>`);$("#userForm").onsubmit=async e=>{e.preventDefault();const r=await api("/api/usuarios",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadUsuarios();toast("Usuário criado.")}}
async function editUsuario(id){const a=await(await api("/api/usuarios")).json(),u=a.find(x=>x.id===id);openModal("Editar usuário",`<form id="editUserForm" class="form-grid"><div><label>Nome</label><input name="nome" value="${esc(u.nome)}"></div><div><label>Cargo</label><select name="cargo"><option value="vendedor" ${u.cargo==="vendedor"?"selected":""}>Vendedor</option><option value="admin" ${u.cargo==="admin"?"selected":""}>Administrador</option></select></div><div><label>Status</label><select name="ativo"><option value="true" ${u.ativo?"selected":""}>Ativo</option><option value="false" ${!u.ativo?"selected":""}>Inativo</option></select></div><div><label>Nova senha (opcional)</label><input name="senha" type="password"></div><button class="primary full">Salvar</button></form>`);$("#editUserForm").onsubmit=async e=>{e.preventDefault();const raw=Object.fromEntries(new FormData(e.target));raw.ativo=raw.ativo==="true";const r=await api(`/api/usuarios/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(raw)}),d=await r.json();if(!r.ok)return toast(d.erro);closeModal();await loadUsuarios();toast("Usuário atualizado.")}}
async function loadEmailConfig(){
  const r=await api("/api/email-config");
  const d=await r.json();
  if(!r.ok)return toast(d.erro||"Não foi possível carregar a configuração de e-mail.");
  if($("#emailConsolidado"))$("#emailConsolidado").value=d.emailConsolidado||"";
  const lojaSelect=$("#emailLojaRelatorio");
  if(lojaSelect){
    const atual=lojaSelect.value||String(lojaId);
    lojaSelect.innerHTML=`<option value="todas">Todas as lojas</option>${lojas.filter(l=>l.ativo).map(l=>`<option value="${l.id}">${esc(l.nome)}</option>`).join("")}`;
    lojaSelect.value=[...lojaSelect.options].some(o=>o.value===atual)?atual:String(lojaId);
  }
  if($("#emailMesRelatorio")&&!$("#emailMesRelatorio").value){
    const agora=new Date();
    $("#emailMesRelatorio").value=`${agora.getFullYear()}-${String(agora.getMonth()+1).padStart(2,"0")}`;
  }
}

async function saveEmailConfig(){
  const body={emailConsolidado:$("#emailConsolidado")?.value||""};
  const r=await api("/api/email-config",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const d=await r.json();
  if(!r.ok)return toast(d.erro||"Não foi possível salvar.");
  toast("E-mail salvo.");
}

function traduzirErroEmail(msg){
  const m=String(msg||"");
  if(/serviço de e-mail não configurado/i.test(m))return m;
  if(/domain|verify|verified|from/i.test(m))return "O serviço de envio ainda precisa de um remetente autorizado.";
  if(/api.?key|unauthorized|authentication|invalid token/i.test(m))return "O serviço de envio ainda não está configurado corretamente.";
  if(/rate|limit/i.test(m))return "O serviço de e-mail atingiu o limite de envios. Tente novamente mais tarde.";
  return m;
}

async function abrirRelatorioEmail(tipo="dia"){
  const email=$("#emailConsolidado")?.value||"";
  if(!email)return toast("Informe o e-mail do destinatário.");

  const body={email,tipo,lojaId:$("#emailLojaRelatorio")?.value||String(lojaId)};
  if(tipo==="mes"){
    const mes=$("#emailMesRelatorio")?.value||"";
    if(!mes)return toast("Selecione o mês do relatório.");
    body.mes=mes;
  }

  await saveEmailConfig();
  const r=await api("/api/email/preparar-relatorio",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(body)
  });
  const d=await r.json();
  if(!r.ok)return toast(d.erro||"Não foi possível preparar o relatório.");

  const url=`mailto:${encodeURIComponent(d.to)}?subject=${encodeURIComponent(d.subject)}&body=${encodeURIComponent(d.body)}`;
  window.open(url,"_blank");
  toast(tipo==="mes"?"Relatório mensal preparado.":"Relatório de hoje preparado.");
}

async function testeEmail(){
  return abrirRelatorioEmail("dia");
}

async function prepararRelatorioMensal(){
  return abrirRelatorioEmail("mes");
}

async function loadConfigForm(){await loadConfig();loadPrinterSettings();await refreshPrinters();const f=$("#configForm");for(const [k,v] of Object.entries(config)){if(f.elements[k])f.elements[k].value=v}}
async function saveConfig(e){e.preventDefault();const r=await api("/api/config",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(Object.fromEntries(new FormData(e.target)))}),d=await r.json();if(!r.ok)return toast(d.erro);config=d;$("#storeName").textContent=d.nomeLoja;toast("Configurações salvas.")}
async function backup(){const r=await api("/api/backup");const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`eletronic-store-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url)}

function instalarEventos(){
  document.addEventListener("click",async function(e){
    const target=e.target;

    const nav=target.closest?.(".nav[data-s]");
    if(nav){
      e.preventDefault();
      document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));
      document.querySelectorAll(".section").forEach(x=>x.classList.remove("active"));
      nav.classList.add("active");
      const section=$("#"+nav.dataset.s);
      if(section)section.classList.add("active");
      try{
        if(nav.dataset.s==="servicos")await loadServicos();
        if(nav.dataset.s==="ordensServico")await loadOS();
        if(nav.dataset.s==="vendas")await loadVendas();
        if(nav.dataset.s==="dashboard")await loadDashboard();
        if(nav.dataset.s==="vendedores"){await loadVendedores();await loadDesempenhoVendedores();}
        if(nav.dataset.s==="caixaGestao")await loadCaixa();
        if(nav.dataset.s==="estoque")await loadMovimentos();
        if(nav.dataset.s==="visaoGeral")await loadAllStores();
        if(nav.dataset.s==="relatorios")await loadRelatorio();
        if(nav.dataset.s==="lojas")await loadLojas();
        if(nav.dataset.s==="personalizacao")await loadAppearanceForm();
        if(nav.dataset.s==="emailRelatorios")await loadEmailConfig();
        if(nav.dataset.s==="config")await loadConfigForm();
      }catch(err){console.error("Erro ao abrir aba",nav.dataset.s,err);toast("Erro ao carregar esta aba.");}
      return;
    }

    if(target.closest?.("#importProdutosBtn")){e.preventDefault();$("#importProdutosFile")?.click();return}
    if(target.closest?.("#novoProdutoBtn")){e.preventDefault();newProduto();return}
    if(target.closest?.("#novoClienteBtn")||target.closest?.("#newClientShortcut")){e.preventDefault();newCliente();return}
    if(target.closest?.("#lockVendedorBtn")){e.preventDefault();togglePdvLock("vendedor");return}
    if(target.closest?.("#lockClienteBtn")){e.preventDefault();togglePdvLock("cliente");return}
    if(target.closest?.("#importServicosBtn")){e.preventDefault();$("#importServicosFile")?.click();return}
    if(target.closest?.("#novoServicoBtn")){e.preventDefault();newServico();return}
    if(target.closest?.("#novaOSBtn")){e.preventDefault();novaOS();return}
    if(target.closest?.("#novaLojaBtn")){e.preventDefault();novaLoja();return}
    if(target.closest?.("#finish")){e.preventDefault();finish();return}
    if(target.closest?.("#cashBadge")){e.preventDefault();quickCashMenu();return}
    if(target.closest?.("#abrirCaixa")){e.preventDefault();openCash();return}
    if(target.closest?.("#fecharCaixa")){e.preventDefault();closeCash();return}
    if(target.closest?.("#installAdbBtn")){e.preventDefault();instalarAdbOficial();return}
    if(target.closest?.("#scanUsbBtn")){e.preventDefault();scanUsb();return}
    if(target.closest?.("#gerarRelatorioBtn")){e.preventDefault();loadRelatorio();return}
    if(target.closest?.("#backupBtn")){e.preventDefault();backup();return}
    if(target.closest?.("#usbRefreshBtn")){e.preventDefault();verificarUsbAutomaticamente();return}
    if(target.closest?.("#usbRestartAdbBtn")){e.preventDefault();reiniciarAdb();return}
    if(target.closest?.("#usbTutorialBtn")){e.preventDefault();mostrarTutorialAdb();return}
    if(target.closest?.("#refreshPrintersBtn")){e.preventDefault();refreshPrinters();return}
    if(target.closest?.("#testPrinterBtn")){e.preventDefault();testPrinter();return}
    if(target.closest?.("#salvarEmailBtn")){e.preventDefault();saveEmailConfig();return}
    if(target.closest?.("#testeEmailBtn")){e.preventDefault();testeEmail();return}
    if(target.closest?.("#emailMesBtn")){e.preventDefault();prepararRelatorioMensal();return}
    if(target.closest?.("#closeModal")){e.preventDefault();closeModal();return}
    if(target.id==="modal"){closeModal();return}

    const theme=target.closest?.(".theme-preset");
    if(theme){e.preventDefault();applyTheme(theme.dataset.theme);return}
  },true);

  const inputMap=[
    ["buscaTexto","input",debounce(renderBuscaProdutos,70)],
    ["desc","input",renderCart],
    ["discountType","change",renderCart],
    ["surcharge","input",renderCart],
    ["filtroProdutos","input",debounce(renderProdutos,100)],
    ["filtroStatusProduto","change",renderProdutos],
    ["filtroClientes","input",debounce(renderClientes,100)],
    ["filtroServicos","input",debounce(renderServicos,100)],
    ["filtroOS","input",debounce(renderOS,100)],
    ["filtroVendas","input",debounce(renderVendas,100)],
    ["vendedorVenda","change",()=>updatePdvLockUi("vendedor")],
    ["clienteVenda","change",()=>updatePdvLockUi("cliente")]
  ];
  for(const [id,event,fn] of inputMap){
    const el=$("#"+id);if(el)el.addEventListener(event,fn);
  }
  const buscaCodigo=$("#buscaCodigo");
  if(buscaCodigo)buscaCodigo.addEventListener("keydown",tratarBuscaCodigo);

  const forms=[
    ["configForm",saveConfig],
    ["appearanceForm",saveAppearance],
    ["__emailConfigFormRemoved",saveEmailConfig]
  ];
  for(const [id,fn] of forms){
    const el=$("#"+id);if(el)el.addEventListener("submit",fn);
  }

  for(const id of ["printerSelect","printerWidth","printerAuto"]){const el=$("#"+id);if(el)el.addEventListener("change",savePrinterSettings)}

  const logo=$("#appearanceLogoFile");
  if(logo)logo.addEventListener("change",e=>handleLogoFile(e.target.files?.[0]));

  const liveColorMap={appearanceColor:"corPrincipal",appearanceTop:"corTopo",appearanceMenu:"corMenu",appearanceBackground:"corFundo",appearanceCard:"corCartao",appearanceText:"corTexto",appearanceMuted:"corTextoSecundario",appearanceBorder:"corBorda",appearanceDanger:"corPerigo"};
  for(const [id,key] of Object.entries(liveColorMap)){
    const el=$("#"+id);if(el)el.addEventListener("input",e=>{aparencia[key]=e.target.value;applyAparencia()});
  }
  const icon=$("#appearanceIcon");
  if(icon)icon.addEventListener("input",e=>{aparencia.icone=e.target.value||"⚡";aparencia.logoDataUrl="";const h=$("#appearanceLogoData");if(h)h.value="";applyAparencia()});
  const name=$("#appearanceName");
  if(name)name.addEventListener("input",e=>{aparencia.nomeSistema=e.target.value||"Eletronic Store";applyAparencia()});
}
instalarEventos();
loadPrinterSettings();

start();

// Monitor USB leve: só consulta enquanto a aba Segurança está visível.
setTimeout(iniciarMonitorUsb,1200);

document.addEventListener("DOMContentLoaded",()=>{$("#novoVendedorBtn")?.addEventListener("click",novoVendedor);$("#vendAtualizar")?.addEventListener("click",loadDesempenhoVendedores)});

document.addEventListener("DOMContentLoaded",()=>renderEsIcons());

function atualizarModoCaixaCompacto(){
  document.body.classList.toggle("viewport-baixo", window.innerHeight < 760 && window.innerWidth >= 900);
}
window.addEventListener("resize", atualizarModoCaixaCompacto);
document.addEventListener("DOMContentLoaded", atualizarModoCaixaCompacto);

async function loadCloudStatus(){
  try{const r=await api("/api/cloud/status"),d=await r.json(),b=$("#cloudBadge"),t=$("#cloudText");if(!b||!t)return;t.textContent=d.state==="online"?"Online":d.state==="syncing"?"Sincronizando":d.state==="offline"?"Offline":"Local";b.className=`cloud-badge ${d.state||"local"}`;b.title=d.message||"Status da nuvem"}catch{}
}
async function syncCloudNow(){const b=$("#cloudBadge");if(b)b.className="cloud-badge syncing";try{const r=await api("/api/cloud/sync",{method:"POST"}),d=await r.json();toast(d.ok?"Dados sincronizados.":d.message||"Falha na sincronização");await loadCloudStatus();if(d.ok)await boot()}catch{toast("Não foi possível sincronizar agora.")}}
setInterval(loadCloudStatus,5000);
document.addEventListener("DOMContentLoaded",()=>{loadCloudStatus();$("#cloudBadge")?.addEventListener("click",syncCloudNow)});

document.addEventListener("DOMContentLoaded",()=>{
  $("#importProdutosFile")?.addEventListener("change",async e=>{const f=e.target.files?.[0];await importarPlanilha("produtos",f);e.target.value=""});
  $("#importServicosFile")?.addEventListener("change",async e=>{const f=e.target.files?.[0];await importarPlanilha("servicos",f);e.target.value=""});
});

function renderUpdateState(s){const b=$("#updateButton"),t=$("#updateText");if(!b||!t)return;b.dataset.state=s?.status||"idle";t.textContent=s?.status==="available"?`Atualização ${s.version}`:s?.status==="downloading"?`Baixando ${s.percent||0}%`:s?.status==="downloaded"?"Instalar atualização":s?.status==="checking"?"Verificando...":s?.status==="error"?"Atualização indisponível":"Atualizado";}
async function updateButtonClick(){if(!window.desktopUpdater)return toast("Atualização automática só funciona no aplicativo instalado.");const s=await window.desktopUpdater.get();if(s?.status==="available"){if(confirm(`Baixar a versão ${s.version}?`))await window.desktopUpdater.download();return}if(s?.status==="downloaded"){if(confirm("Instalar e reiniciar agora?"))await window.desktopUpdater.install();return}const r=await window.desktopUpdater.check();if(!r.ok)toast(r.error||"Não foi possível verificar atualizações.");}
document.addEventListener("DOMContentLoaded",async()=>{if(window.desktopUpdater){renderUpdateState(await window.desktopUpdater.get());window.desktopUpdater.onState(renderUpdateState);setTimeout(()=>window.desktopUpdater.check(),5000)}$("#updateButton")?.addEventListener("click",updateButtonClick);});

document.addEventListener("change",e=>{
  if(e.target?.id==="splitPayment"){toggleSplitPayment();return}
  if(e.target?.classList?.contains("split-pay-method")){const i=Number(e.target.dataset.i);if(splitPaymentLines[i]){splitPaymentLines[i].forma=e.target.value;renderSplitPayments()}return}
});
document.addEventListener("input",e=>{
  if(e.target?.classList?.contains("split-pay-value")){
    const i=Number(e.target.dataset.i);if(!splitPaymentLines[i])return;
    splitPaymentLines[i].valor=Math.max(0,Number(e.target.value)||0);
    // Em duas formas, preencher automaticamente o restante na outra linha.
    if(splitPaymentLines.length===2){
      const outro=i===0?1:0,total=totalAtualVenda();
      splitPaymentLines[outro].valor=Math.max(0,Math.round((total-splitPaymentLines[i].valor)*100)/100);
    }
    renderSplitPayments();
  }
});
document.addEventListener("click",e=>{
  if(e.target?.closest?.("#addPaymentMethod")){
    e.preventDefault();if(splitPaymentLines.length>=4)return toast("Máximo de 4 formas por venda.");
    splitPaymentLines.push({forma:"PIX",valor:0});renderSplitPayments();return;
  }
  const rem=e.target?.closest?.(".split-pay-remove");
  if(rem){e.preventDefault();const i=Number(rem.dataset.i);if(splitPaymentLines.length>2){splitPaymentLines.splice(i,1);renderSplitPayments()}return}
});
