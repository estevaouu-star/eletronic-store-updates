
const fs = require("fs");
const path = require("path");
const target = path.join(__dirname, "..", "dist", "server.js");
console.log("Backend esperado em:", target);
if (!fs.existsSync(target)) {
  console.error("ERRO: dist/server.js não existe. Rode npm run build.");
  process.exit(1);
}
console.log("OK: backend compilado encontrado.");
