
const { app } = require("electron");
app.whenReady().then(() => {
  console.log("Electron iniciou corretamente.");
  console.log("Versão Electron:", process.versions.electron);
  app.quit();
});
