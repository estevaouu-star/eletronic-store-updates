const {contextBridge,ipcRenderer}=require("electron");
contextBridge.exposeInMainWorld("desktopUpdater",{
 get:()=>ipcRenderer.invoke("update:get"),
 check:()=>ipcRenderer.invoke("update:check"),
 download:()=>ipcRenderer.invoke("update:download"),
 install:()=>ipcRenderer.invoke("update:install"),
 onState:(cb)=>ipcRenderer.on("update-state",(_e,s)=>cb(s))
});
