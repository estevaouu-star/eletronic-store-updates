
const { app, BrowserWindow, dialog, shell, Tray, Menu, ipcMain } = require("electron");
const path = require("path");
const http = require("http");
const net = require("net");
const { autoUpdater } = require("electron-updater");

// Otimização para PCs antigos/integrados: reduz uso de GPU e evita cache em pastas problemáticas.
app.disableHardwareAcceleration();
try {
  app.setPath("cache", path.join(app.getPath("userData"), "Cache"));
} catch {}

let mainWindow = null;
let tray = null;
let quitting = false;
let updateState={status:"idle",version:null,percent:0,message:""};
function emitUpdate(){try{mainWindow?.webContents.send("update-state",updateState)}catch{}}
function setupUpdater(){
  autoUpdater.setFeedURL({
    provider: "github",
    owner: "estevaouu-star",
    repo: "eletronic-store-updates"
  });
  autoUpdater.autoDownload=false;
  autoUpdater.on("checking-for-update",()=>{updateState={status:"checking",message:"Verificando..."};emitUpdate()});
  autoUpdater.on("update-available",i=>{updateState={status:"available",version:i.version,message:"Atualização disponível"};emitUpdate()});
  autoUpdater.on("update-not-available",()=>{updateState={status:"latest",version:app.getVersion(),message:"Atualizado"};emitUpdate()});
  autoUpdater.on("download-progress",p=>{updateState={status:"downloading",version:updateState.version,percent:Math.round(p.percent||0),message:"Baixando"};emitUpdate()});
  autoUpdater.on("update-downloaded",i=>{updateState={status:"downloaded",version:i.version,percent:100,message:"Pronta para instalar"};emitUpdate()});
  autoUpdater.on("error",e=>{updateState={status:"error",message:String(e?.message||e)};emitUpdate()});
  ipcMain.handle("update:get",()=>updateState);
  ipcMain.handle("update:check",async()=>{try{await autoUpdater.checkForUpdates();return {ok:true}}catch(e){return {ok:false,error:String(e?.message||e)}}});
  ipcMain.handle("update:download",async()=>{try{await autoUpdater.downloadUpdate();return {ok:true}}catch(e){return {ok:false,error:String(e?.message||e)}}});
  ipcMain.handle("update:install",()=>{setImmediate(()=>autoUpdater.quitAndInstall(false,true));return {ok:true}});
}

let internalPort = null;


function getFreePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = address && typeof address === "object" ? address.port : null;
      server.close(() => port ? resolve(port) : reject(new Error("Não foi possível reservar uma porta interna.")));
    });
  });
}

function waitForServer(url, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const started = Date.now();

    const test = () => {
      const req = http.get(url, res => {
        res.resume();
        resolve();
      });

      req.on("error", () => {
        if (Date.now() - started > timeoutMs) {
          reject(new Error("O servidor interno do aplicativo não iniciou."));
        } else {
          setTimeout(test, 350);
        }
      });
    };

    test();
  });
}

function startServerInsideElectron(port) {
  const appRoot = app.getAppPath();
  const serverEntry = path.join(appRoot, "dist", "server.js");

  // O banco de dados precisa ficar numa pasta gravável depois da instalação.
  process.env.ELECTRON_STORE_DATA_DIR = app.getPath("userData");
  process.env.ELECTRON_STORE_PORT = String(port);

  console.log("[desktop] appRoot:", appRoot);
  console.log("[desktop] backend:", serverEntry);
  console.log("[desktop] dados:", process.env.ELECTRON_STORE_DATA_DIR);

  // Carrega o Express no próprio processo principal do Electron.
  // Assim não dependemos de spawn, utilityProcess ou de executar outro .exe.
  require(serverEntry);
}

function createWindow() {
  const icon = path.join(__dirname, "assets", "icon.png");

  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1050,
    minHeight: 680,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: "#f4f6f8",
    icon,
    useContentSize: true,
    webPreferences: {
      contextIsolation: true,
      sandbox: true,
      preload: path.join(__dirname, "preload.cjs")
    }
  });

  mainWindow.loadURL(`http://127.0.0.1:${internalPort}`);
  mainWindow.once("ready-to-show", () => mainWindow.show());

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  mainWindow.on("close", event => {
    if (!quitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });
}

function createTray() {
  try {
    const icon = path.join(__dirname, "assets", "icon.png");

    tray = new Tray(icon);
    tray.setToolTip("Eletromix");

    tray.setContextMenu(Menu.buildFromTemplate([
      {
        label: "Abrir Eletromix",
        click: () => {
          mainWindow?.show();
          mainWindow?.focus();
        }
      },
      { type: "separator" },
      {
        label: "Sair",
        click: () => {
          quitting = true;
          app.quit();
        }
      }
    ]));

    tray.on("double-click", () => {
      mainWindow?.show();
      mainWindow?.focus();
    });
  } catch (err) {
    console.error("[desktop] Falha ao criar bandeja:", err);
  }
}


function receiptPrintHtml(bodyHtml, paperWidth) {
  const width = paperWidth === 58 ? 58 : 80;
  const inner = width === 58 ? 52 : 72;
  return `<!doctype html><html><head><meta charset="utf-8"><style>
    @page{margin:0;size:${width}mm auto}
    *{box-sizing:border-box}
    html,body{margin:0;padding:0;background:#fff;color:#000;width:${width}mm}
    body{font-family:Arial,Helvetica,sans-serif;font-size:${width===58?10:11}px;line-height:1.25}
    .receipt{width:${inner}mm;max-width:${inner}mm;margin:0 auto;padding:3mm 1mm}
    .receipt h2{font-size:${width===58?15:17}px;margin:0 0 3px;text-align:center}
    .receipt p{text-align:center;margin:2px 0}
    .receipt-logo{text-align:center;margin-bottom:5px}.receipt-logo img{max-width:${width===58?35:45}mm;max-height:22mm;object-fit:contain}
    table{width:100%;border-collapse:collapse;margin:4px 0}th,td{font-size:${width===58?9:10}px;padding:3px 1px;border-bottom:1px dashed #777;text-align:left;vertical-align:top}
    th:nth-child(2),td:nth-child(2){width:10mm;text-align:center}th:last-child,td:last-child{text-align:right}
    .receipt-total{display:flex;justify-content:space-between;font-size:${width===58?14:16}px;font-weight:700;border-top:1px dashed #000;margin-top:5px;padding-top:5px}
  </style></head><body>${bodyHtml}</body></html>`;
}

ipcMain.handle("printer:list", async () => {
  if (!mainWindow) return [];
  const printers = await mainWindow.webContents.getPrintersAsync();
  return printers.map(p => ({
    name: p.name,
    displayName: p.displayName || p.name,
    description: p.description || "",
    status: p.status,
    isDefault: Boolean(p.isDefault)
  }));
});

ipcMain.handle("printer:print", async (_event, payload = {}) => {
  let deviceName = String(payload.deviceName || "");
  if(!deviceName && mainWindow){
    const available=await mainWindow.webContents.getPrintersAsync();
    const preferred=available.find(p=>/epson|tm-|thermal|receipt|pos/i.test(`${p.name} ${p.displayName||""} ${p.description||""}`)) || available.find(p=>p.isDefault);
    if(preferred)deviceName=preferred.name;
  }
  const width = Number(payload.paperWidth) === 58 ? 58 : 80;
  const itemCount = Math.max(1, Number(payload.itemCount) || 1);
  const heightMm = Math.min(900, Math.max(140, 100 + itemCount * 13));
  const printWindow = new BrowserWindow({
    show: false,
    webPreferences: { contextIsolation: true, sandbox: true }
  });

  try {
    const html = receiptPrintHtml(String(payload.html || ""), width);
    await printWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
    await new Promise(resolve => setTimeout(resolve, 120));

    const result = await new Promise(resolve => {
      printWindow.webContents.print({
        silent: true,
        printBackground: true,
        deviceName: deviceName || undefined,
        margins: { marginType: "none" },
        pageSize: { width: width * 1000, height: heightMm * 1000 }
      }, (success, failureReason) => resolve({ success, failureReason: failureReason || "" }));
    });
    return result;
  } catch (err) {
    return { success: false, failureReason: String(err?.message || err) };
  } finally {
    if (!printWindow.isDestroyed()) printWindow.destroy();
  }
});

app.whenReady().then(async () => {
  setupUpdater();
  try {
    internalPort = await getFreePort();
    console.log("[desktop] porta interna exclusiva:", internalPort);
    startServerInsideElectron(internalPort);
    await waitForServer(`http://127.0.0.1:${internalPort}`);
    createWindow();
    createTray();
  } catch (err) {
    console.error("[desktop] Erro:", err);
    dialog.showErrorBox(
      "Eletromix",
      `Não foi possível iniciar o aplicativo.\n\n${String(err?.stack || err)}`
    );
    quitting = true;
    app.quit();
  }
});

app.on("activate", () => {
  if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
  }
});

app.on("before-quit", () => {
  quitting = true;
});

app.on("window-all-closed", () => {
  // Mantém o aplicativo na bandeja para relatórios automáticos.
});