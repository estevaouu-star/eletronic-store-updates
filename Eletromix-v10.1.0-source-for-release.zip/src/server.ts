
import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import * as XLSX from "xlsx";
import { execFileSync } from "child_process";

type Cargo = "admin" | "vendedor";
type StatusVenda = "concluida" | "cancelada";

type Vendedor = { lojaId:number; id:number; nome:string; codigo:string; ativo:boolean; criadoEm:string; atualizadoEm:string; };

type Produto = {
  lojaId:number;
  id:number; codigo:string; codigoBarras:string; nome:string; categoria:string; marca:string;
  precoCusto:number; precoVenda:number; estoque:number; estoqueMinimo:number;
  ativo:boolean; criadoEm:string; atualizadoEm:string;
};

type Cliente = {
  lojaId:number;
  id:number; nome:string; cpf:string; telefone:string; email:string;
  ativo:boolean; criadoEm:string; atualizadoEm:string;
};

type Servico = {
  lojaId:number;
  id:number; nome:string; descricao:string; categoria:string;
  preco:number; ativo:boolean;
  criadoEm:string; atualizadoEm:string;
};

type OrdemServico = {
  lojaId:number;
  id:number; clienteNome:string; telefone:string;
  aparelho:string; marca:string; modelo:string;
  problemaRelatado:string; servicoId:number|null; servicoNome:string;
  valor:number; observacoes:string;
  status:"Recebido"|"Em análise"|"Aguardando peça"|"Em reparo"|"Pronto"|"Entregue";
  criadoEm:string; atualizadoEm:string;
};

type DiagnosticoSeguranca = {
  lojaId:number;
  id:number;
  clienteNome:string;
  aparelho:string;
  modelo:string;
  sistema:string;
  sintomas:string[];
  observacoes:string;
  etapas:{
    backupConfirmado:boolean;
    appsSuspeitosVerificados:boolean;
    permissoesVerificadas:boolean;
    navegadorVerificado:boolean;
    atualizacoesVerificadas:boolean;
    playProtectVerificado:boolean;
  };
  resultado:"Pendente"|"Nenhuma ameaça óbvia encontrada"|"Aplicativos suspeitos identificados"|"Necessita análise adicional";
  criadoEm:string;
  atualizadoEm:string;
};

type Usuario = {
  id:number; nome:string; login:string; senhaHash:string;
  cargo:Cargo; ativo:boolean; criadoEm:string;
};

type ItemVenda = {
  tipo:"produto"|"servico";
  produtoId:number|null; servicoId:number|null;
  nomeProduto:string; codigoProduto:string;
  quantidade:number; precoUnitario:number; acrescimoUnitario:number; subtotal:number;
};

type Venda = {
  lojaId:number; vendedorId:number|null; vendedorNome:string;
  id:number; clienteId:number|null; clienteNome:string;
  compradorDocumento:string; compradorTelefone:string; compradorEmail:string;
  usuarioId:number; usuarioNome:string;
  subtotal:number; acrescimo:number; desconto:number; total:number; formaPagamento:string;
  pagamentos?:{forma:string;valor:number}[];
  itens:ItemVenda[]; status:StatusVenda; criadoEm:string; canceladoEm?:string;
  fiscal?: {
    tipo:"rascunho-nfce"|"rascunho-nfe";
    numero:number;
    serie:number;
    naturezaOperacao:string;
    status:"rascunho";
    criadoEm:string;
  };
};

type Movimento = {
  lojaId:number;
  id:number; produtoId:number; produtoNome:string; tipo:"entrada"|"saida"|"ajuste"|"venda"|"cancelamento";
  quantidade:number; saldoAnterior:number; saldoAtual:number; motivo:string;
  usuarioId:number; usuarioNome:string; criadoEm:string;
};

type Caixa = {
  lojaId:number;
  id:number; usuarioId:number; usuarioNome:string; abertoEm:string;
  saldoInicial:number; fechadoEm?:string; saldoFinalInformado?:number;
  totalVendas?:number; status:"aberto"|"fechado";
};

type Loja = {
  id:number; nome:string; cnpj:string; telefone:string; endereco:string;
  rodapeComprovante:string;
  emailProprietario:string; enviarRelatorioDiario:boolean; horarioRelatorio:string;
  ativo:boolean; criadoEm:string; atualizadoEm:string;
};


type Aparencia = {
  corPrincipal:string;
  corTopo:string;
  corMenu:string;
  corFundo:string;
  corCartao:string;
  corTexto:string;
  corTextoSecundario:string;
  corBorda:string;
  corPerigo:string;
  icone:string;
  logoDataUrl:string;
  nomeSistema:string;
};

type EmailConfig = {
  provedor:"resend";
  apiKey:string;
  remetente:string;
  emailConsolidado:string;
  horarioConsolidado:string;
  enviarConsolidado:boolean;
};

type Banco = {
  lojas:Loja[];
  vendedores:Vendedor[];
  produtos:Produto[];
  clientes:Cliente[];
  servicos:Servico[];
  ordensServico:OrdemServico[];
  diagnosticosSeguranca:DiagnosticoSeguranca[];
  usuarios:Usuario[];
  vendas:Venda[];
  movimentos:Movimento[];
  caixas:Caixa[];
  emailConfig:EmailConfig;
  aparencia:Aparencia;
  seq:{
    loja:number; vendedor:number; produto:number; cliente:number; servico:number;
    ordemServico:number; diagnostico:number; usuario:number;
    venda:number; movimento:number; caixa:number;
  };
};

const app = express();
const PORT = Number(process.env.ELECTRON_STORE_PORT || process.env.PORT || 3000);
const dataDir = process.env.ELECTRON_STORE_DATA_DIR || path.join(__dirname, "../data");
const dataFile = path.join(dataDir, "database.json");
fs.mkdirSync(dataDir, { recursive: true });

function senhaHash(senha:string) {
  const salt = "eletronic-store-local-v1";
  return crypto.scryptSync(senha, salt, 64).toString("hex");
}
const now = () => new Date().toISOString();

const inicial: Banco = {
  lojas:[{
    id:1,nome:"Loja Principal",cnpj:"",telefone:"",endereco:"",
    rodapeComprovante:"Obrigado pela preferência!",
    emailProprietario:"",enviarRelatorioDiario:false,horarioRelatorio:"20:00",
    ativo:true,criadoEm:now(),atualizadoEm:now()
  }],
  vendedores:[{lojaId:1,id:1,nome:"Vendedor 1",codigo:"V01",ativo:true,criadoEm:now(),atualizadoEm:now()}],
  produtos: [
    {lojaId:1,id:1,codigo:"MOU001",codigoBarras:"7890000000011",nome:"Mouse Gamer",categoria:"Periféricos",marca:"Logitech",precoCusto:45,precoVenda:89.90,estoque:15,estoqueMinimo:5,ativo:true,criadoEm:now(),atualizadoEm:now()},
    {lojaId:1,id:2,codigo:"TEC001",codigoBarras:"7890000000028",nome:"Teclado Mecânico",categoria:"Periféricos",marca:"Redragon",precoCusto:130,precoVenda:249.90,estoque:8,estoqueMinimo:3,ativo:true,criadoEm:now(),atualizadoEm:now()},
    {lojaId:1,id:3,codigo:"CAB001",codigoBarras:"7890000000035",nome:"Cabo HDMI 2.1",categoria:"Cabos",marca:"Ugreen",precoCusto:18,precoVenda:39.90,estoque:20,estoqueMinimo:5,ativo:true,criadoEm:now(),atualizadoEm:now()},
    {lojaId:1,id:4,codigo:"FON001",codigoBarras:"7890000000042",nome:"Fone Bluetooth",categoria:"Áudio",marca:"JBL",precoCusto:120,precoVenda:199.90,estoque:6,estoqueMinimo:2,ativo:true,criadoEm:now(),atualizadoEm:now()}
  ],
  clientes: [],
  servicos: [
    {lojaId:1,id:1,nome:"Troca de tela",descricao:"Substituição de tela/display.",categoria:"Reparo",preco:180,ativo:true,criadoEm:now(),atualizadoEm:now()},
    {lojaId:1,id:2,nome:"Troca de bateria",descricao:"Substituição de bateria do aparelho.",categoria:"Reparo",preco:120,ativo:true,criadoEm:now(),atualizadoEm:now()},
    {lojaId:1,id:3,nome:"Limpeza de software",descricao:"Diagnóstico e remoção de aplicativos indesejados/malware.",categoria:"Software",preco:80,ativo:true,criadoEm:now(),atualizadoEm:now()}
  ],
  ordensServico: [],
  diagnosticosSeguranca: [],
  usuarios: [{id:1,nome:"Administrador",login:"admin",senhaHash:senhaHash("admin123"),cargo:"admin",ativo:true,criadoEm:now()}],
  emailConfig:{
    provedor:"resend",
    apiKey:"",
    remetente:"",
    emailConsolidado:"",
    horarioConsolidado:"20:05",
    enviarConsolidado:false
  },
  aparencia:{
    corPrincipal:"#1769e0",
    corTopo:"#101820",
    corMenu:"#ffffff",
    corFundo:"#f4f6f8",
    corCartao:"#ffffff",
    corTexto:"#17202a",
    corTextoSecundario:"#6b7680",
    corBorda:"#e1e6ea",
    corPerigo:"#c62828",
    icone:"⚡",
    logoDataUrl:"",
    nomeSistema:"Eletronic Store"
  },
  vendas: [], movimentos: [], caixas: [],
  seq:{loja:2,vendedor:2,produto:5,cliente:1,servico:4,ordemServico:1,diagnostico:1,usuario:2,venda:1,movimento:1,caixa:1}
};

function carregar(): Banco {
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(inicial, null, 2));
    return structuredClone(inicial);
  }
  try {
    const db = JSON.parse(fs.readFileSync(dataFile, "utf8")) as Banco;
    // Migração simples caso venha de uma versão anterior.
    db.lojas ??= [{
      id:1,nome:(db as any).config?.nomeLoja||"Loja Principal",
      cnpj:(db as any).config?.cnpj||"",telefone:(db as any).config?.telefone||"",
      endereco:(db as any).config?.endereco||"",
      rodapeComprovante:(db as any).config?.rodapeComprovante||"Obrigado pela preferência!",
      emailProprietario:"",enviarRelatorioDiario:false,horarioRelatorio:"20:00",
      ativo:true,criadoEm:now(),atualizadoEm:now()
    }];
    db.produtos ??= [];
    db.clientes ??= [];
    db.servicos ??= structuredClone(inicial.servicos);
    db.ordensServico ??= [];
    db.diagnosticosSeguranca ??= [];
    db.usuarios ??= structuredClone(inicial.usuarios);
    db.vendas ??= [];
    db.vendedores ??= [];
    db.movimentos ??= [];
    db.caixas ??= [];
    db.emailConfig ??= {
    provedor:"resend",
    apiKey:"",
    remetente:"",
    emailConsolidado:"",
    horarioConsolidado:"20:05",
    enviarConsolidado:false
  };
    (db.emailConfig as any).provedor ??= "resend";
    (db.emailConfig as any).apiKey ??= "";
    (db.emailConfig as any).remetente ??= "";
    (db.emailConfig as any).emailConsolidado ??= "";
    (db.emailConfig as any).horarioConsolidado ??= "20:05";
    (db.emailConfig as any).enviarConsolidado ??= false;
    delete (db.emailConfig as any).host;
    delete (db.emailConfig as any).port;
    delete (db.emailConfig as any).secure;
    delete (db.emailConfig as any).usuario;
    delete (db.emailConfig as any).senha;
    db.aparencia ??= {
    corPrincipal:"#1769e0",
    corTopo:"#101820",
    corMenu:"#ffffff",
    corFundo:"#f4f6f8",
    corCartao:"#ffffff",
    corTexto:"#17202a",
    corTextoSecundario:"#6b7680",
    corBorda:"#e1e6ea",
    corPerigo:"#c62828",
    icone:"⚡",
    logoDataUrl:"",
    nomeSistema:"Eletronic Store"
  };

    db.aparencia.corTopo ??= "#101820";
    db.aparencia.corMenu ??= "#ffffff";
    db.aparencia.corFundo ??= "#f4f6f8";
    db.aparencia.corCartao ??= "#ffffff";
    db.aparencia.corTexto ??= "#17202a";
    db.aparencia.corTextoSecundario ??= "#6b7680";
    db.aparencia.corBorda ??= "#e1e6ea";
    db.aparencia.corPerigo ??= "#c62828";
    db.aparencia.logoDataUrl ??= "";

    db.seq ??= structuredClone(inicial.seq);
    (db.seq as any).loja ??= Math.max(2,...db.lojas.map(l=>l.id+1));
    (db.seq as any).vendedor ??= Math.max(1,...db.vendedores.map(v=>v.id+1));
    (db.seq as any).servico ??= Math.max(1,...db.servicos.map(s=>s.id+1));
    (db.seq as any).ordemServico ??= Math.max(1,...db.ordensServico.map(o=>o.id+1));
    (db.seq as any).diagnostico ??= Math.max(1,...db.diagnosticosSeguranca.map(d=>d.id+1));

    for(const l of db.lojas){
      l.emailProprietario ??= "";
      l.enviarRelatorioDiario ??= false;
      l.horarioRelatorio ??= "20:00";
    }
    for (const list of [db.vendedores,db.produtos,db.clientes,db.servicos,db.ordensServico,db.diagnosticosSeguranca,db.vendas,db.movimentos,db.caixas] as any[]) {
      for (const item of list) item.lojaId ??= 1;
    }
    for(const v of db.vendas){
      (v as any).vendedorId ??= null; (v as any).vendedorNome ??= v.usuarioNome || "Não informado";
      (v as any).acrescimo ??= 0;
      for(const i of v.itens)(i as any).acrescimoUnitario ??= 0;
    }
    for (const p of db.produtos) (p as any).codigoBarras ??= "";
    for (const p of db.produtos) {
      (p as any).ativo ??= true;
      (p as any).atualizadoEm ??= p.criadoEm || now();
    }
    fs.writeFileSync(dataFile, JSON.stringify(db, null, 2));
    return db;
  } catch {
    fs.writeFileSync(dataFile, JSON.stringify(inicial, null, 2));
    return structuredClone(inicial);
  }
}

let db = carregar();
const cloudFile=path.join(dataDir,"cloud.json");
type CloudCfg={enabled:boolean;url:string;publishableKey:string;syncId:string;secret:string;pollSeconds:number};
function cloudCfg():CloudCfg|null{
  try{return JSON.parse(fs.readFileSync(cloudFile,"utf8"))}
  catch{return {"enabled":true,"url":"https://lxmefogvaahlwacpckbn.supabase.co","publishableKey":"sb_publishable_pYv5waFWIuo-PIlwZZ1vHA_txVUeSXf","syncId":"main","secret":"scB3p_vwBedGnZ8-RNHZC6j3wcUyDFkM3H90IsBjMrI","pollSeconds":8} as CloudCfg}
}
let cloudVersion=0,cloudState:"online"|"offline"|"syncing"|"local"="local",cloudMessage="Modo local",cloudUpdatedAt="";
let cloudPushTimer:NodeJS.Timeout|null=null,cloudBusy=false;
async function cloudRpc(name:string,body:any){
  const c=cloudCfg(); if(!c?.enabled)throw new Error("Nuvem desativada");
  const r=await fetch(`${c.url}/rest/v1/rpc/${name}`,{method:"POST",headers:{"Content-Type":"application/json","apikey":c.publishableKey,"Authorization":`Bearer ${c.publishableKey}`},body:JSON.stringify(body)});
  const text=await r.text(); if(!r.ok)throw new Error(text||`HTTP ${r.status}`); return text?JSON.parse(text):null;
}
async function cloudPull(apply=true){
  const c=cloudCfg();if(!c?.enabled){cloudState="local";cloudMessage="Modo local";return false}
  cloudState="syncing";cloudMessage="Buscando alterações...";
  try{
    const rows=await cloudRpc("electronic_store_pull",{p_sync_id:c.syncId,p_secret:c.secret});
    const row=Array.isArray(rows)?rows[0]:rows;
    if(row?.payload && Object.keys(row.payload).length){
      if(apply && Number(row.version)>cloudVersion){db=row.payload as Banco;fs.writeFileSync(dataFile,JSON.stringify(db,null,2));}
      cloudVersion=Number(row.version)||cloudVersion;cloudUpdatedAt=row.updated_at||"";
    }
    cloudState="online";cloudMessage="Dados sincronizados";return true;
  }catch(e:any){cloudState="offline";cloudMessage="Sem conexão com a nuvem";console.error("Cloud pull:",e?.message||e);return false}
}
async function cloudPush(){
  const c=cloudCfg();if(!c?.enabled||cloudBusy)return;cloudBusy=true;cloudState="syncing";cloudMessage="Enviando alterações...";
  try{
    if(!cloudVersion)await cloudPull(false);
    let rows=await cloudRpc("electronic_store_push",{p_sync_id:c.syncId,p_secret:c.secret,p_payload:db,p_expected_version:cloudVersion});
    let row=Array.isArray(rows)?rows[0]:rows;
    if(!row?.ok){
      const remoteVersion=Number(row?.version)||0;
      if(remoteVersion>0){
        cloudVersion=remoteVersion;
        rows=await cloudRpc("electronic_store_push",{p_sync_id:c.syncId,p_secret:c.secret,p_payload:db,p_expected_version:cloudVersion});
        row=Array.isArray(rows)?rows[0]:rows;
      }
      if(!row?.ok){
        await cloudPull(true);
        cloudState="online";
        cloudMessage="Dados remotos atualizados; tente novamente";
        return;
      }
    }
    cloudVersion=Number(row.version)||cloudVersion;cloudUpdatedAt=row.updated_at||"";cloudState="online";cloudMessage="Sincronizado";
  }catch(e:any){cloudState="offline";cloudMessage=String(e?.message||"Falha na sincronização").slice(0,100);console.error("Cloud push:",e?.message||e)}finally{cloudBusy=false}
}
function agendarCloudPush(){if(cloudPushTimer)clearTimeout(cloudPushTimer);cloudPushTimer=setTimeout(()=>cloudPush(),350)}
const salvar = () => {fs.writeFileSync(dataFile, JSON.stringify(db, null, 2));agendarCloudPush()};
async function iniciarCloud(){
  const c=cloudCfg();if(!c?.enabled)return;
  const ok=await cloudPull(true);
  if(ok && cloudVersion===0)await cloudPush();
  setInterval(async()=>{if(!cloudBusy)await cloudPull(true)},Math.max(5,c.pollSeconds||8)*1000);
}

function lojaIdReq(req:express.Request):number {
  const requested=Number(req.headers["x-store-id"]||1);
  const loja=db.lojas.find(l=>l.id===requested&&l.ativo) || db.lojas.find(l=>l.ativo);
  return loja?.id || 1;
}
function lojaReq(req:express.Request):Loja {
  const id=lojaIdReq(req);
  return db.lojas.find(l=>l.id===id)!;
}




const sessoes = new Map<string,{usuarioId:number;expira:number}>();

function auth(req:express.Request,res:express.Response,next:express.NextFunction) {
  const u=db.usuarios.find(x=>x.cargo==="admin"&&x.ativo) || db.usuarios.find(x=>x.ativo);
  if(!u)return res.status(500).json({erro:"Nenhum usuário ativo configurado."});
  (req as any).usuario=u;
  next();
}

function admin(req:express.Request,res:express.Response,next:express.NextFunction) {
  if ((req as any).usuario?.cargo !== "admin") {
    return res.status(403).json({erro:"Acesso permitido apenas ao administrador."});
  }
  next();
}

function caixaAbertoDoUsuario(usuarioId:number,lojaId:number) {
  return db.caixas.find(c => c.lojaId===lojaId && c.usuarioId === usuarioId && c.status === "aberto");
}

function produtoAtivo(id:number,lojaId:number) {
  return db.produtos.find(p => p.lojaId===lojaId && p.id === id && p.ativo);
}

function movimentarEstoque(produto:Produto, quantidade:number, tipo:Movimento["tipo"], motivo:string, usuario:Usuario) {
  const anterior = produto.estoque;
  produto.estoque += quantidade;
  produto.atualizadoEm = now();
  db.movimentos.push({
    lojaId:produto.lojaId,
    id:db.seq.movimento++,
    produtoId:produto.id,
    produtoNome:produto.nome,
    tipo,
    quantidade,
    saldoAnterior:anterior,
    saldoAtual:produto.estoque,
    motivo,
    usuarioId:usuario.id,
    usuarioNome:usuario.nome,
    criadoEm:now()
  });
}


function parsePeriodo(req:express.Request){
  const de=String(req.query.de||"").trim();
  const ate=String(req.query.ate||"").trim();
  const inicio=de?new Date(`${de}T00:00:00`):new Date("2000-01-01T00:00:00");
  const fim=ate?new Date(`${ate}T23:59:59.999`):new Date("2999-12-31T23:59:59.999");
  return {inicio,fim,de,ate};
}

function relatorioDaLoja(lojaId:number,inicio:Date,fim:Date){
  const vendas=db.vendas.filter(v=>v.lojaId===lojaId&&v.status==="concluida"&&new Date(v.criadoEm)>=inicio&&new Date(v.criadoEm)<=fim);
  let receitaBruta=0, descontos=0, receitaLiquida=0, custoProdutos=0, qtdProdutos=0, qtdServicos=0;
  const porPagamento:Record<string,number>={};
  const produtosMap=new Map<number,{nome:string,qtd:number,receita:number,custo:number}>();
  const servicosMap=new Map<number,{nome:string,qtd:number,receita:number}>();

  for(const v of vendas){
    receitaBruta+=v.subtotal+(v.acrescimo||0);
    descontos+=v.desconto;
    receitaLiquida+=v.total;
    porPagamento[v.formaPagamento]=(porPagamento[v.formaPagamento]||0)+v.total;
    for(const i of v.itens){
      if(i.tipo==="servico"){
        qtdServicos+=i.quantidade;
        const id=Number(i.servicoId||0);
        const r=servicosMap.get(id)||{nome:i.nomeProduto,qtd:0,receita:0};
        r.qtd+=i.quantidade;r.receita+=i.subtotal;servicosMap.set(id,r);
      }else{
        qtdProdutos+=i.quantidade;
        const p=db.produtos.find(x=>x.lojaId===lojaId&&x.id===i.produtoId);
        const custo=(p?.precoCusto||0)*i.quantidade;
        custoProdutos+=custo;
        const id=Number(i.produtoId||0);
        const r=produtosMap.get(id)||{nome:i.nomeProduto,qtd:0,receita:0,custo:0};
        r.qtd+=i.quantidade;r.receita+=i.subtotal;r.custo+=custo;produtosMap.set(id,r);
      }
    }
  }

  const valorEstoqueCusto=db.produtos.filter(p=>p.lojaId===lojaId&&p.ativo).reduce((a,p)=>a+p.precoCusto*p.estoque,0);
  const valorEstoqueVenda=db.produtos.filter(p=>p.lojaId===lojaId&&p.ativo).reduce((a,p)=>a+p.precoVenda*p.estoque,0);
  const lucroBrutoEstimado=receitaLiquida-custoProdutos;

  return {
    lojaId,
    vendas:vendas.length,
    receitaBruta,
    descontos,
    receitaLiquida,
    custoProdutos,
    lucroBrutoEstimado,
    margemBrutaPercentual:receitaLiquida?lucroBrutoEstimado/receitaLiquida*100:0,
    ticketMedio:vendas.length?receitaLiquida/vendas.length:0,
    qtdProdutos,
    qtdServicos,
    valorEstoqueCusto,
    valorEstoqueVenda,
    porPagamento,
    produtos:[...produtosMap.values()].sort((a,b)=>b.receita-a.receita),
    servicos:[...servicosMap.values()].sort((a,b)=>b.receita-a.receita)
  };
}

app.use(express.json({limit:"20mb"}));
app.use(express.static(path.join(__dirname, "../public")));

app.post("/api/login",(req,res)=>{
  const login=String(req.body.login||"").trim();
  const senha=String(req.body.senha||"");
  const u=db.usuarios.find(x=>x.login===login&&x.ativo);
  if(!u||u.senhaHash!==senhaHash(senha))return res.status(401).json({erro:"Login ou senha incorretos."});
  const token=crypto.randomBytes(24).toString("hex");
  sessoes.set(token,{usuarioId:u.id,expira:Date.now()+8*60*60*1000});
  res.json({token,usuario:{id:u.id,nome:u.nome,login:u.login,cargo:u.cargo}});
});

app.get("/api/me",auth,(req,res)=>{
  const u=(req as any).usuario as Usuario;
  res.json({id:u.id,nome:u.nome,login:u.login,cargo:u.cargo,caixa:caixaAbertoDoUsuario(u.id,lojaIdReq(req))||null});
});

app.post("/api/logout",auth,(req,res)=>{
  sessoes.delete((req as any).token);
  res.json({ok:true});
});



// Lojas / Unidades
app.get("/api/lojas",auth,(_req,res)=>res.json(db.lojas));
app.post("/api/lojas",auth,admin,(req,res)=>{
  const nome=String(req.body.nome||"").trim();
  if(!nome)return res.status(400).json({erro:"Nome da loja é obrigatório."});
  const l:Loja={
    id:db.seq.loja++,nome,cnpj:String(req.body.cnpj||""),telefone:String(req.body.telefone||""),
    endereco:String(req.body.endereco||""),rodapeComprovante:String(req.body.rodapeComprovante||"Obrigado pela preferência!"),
    emailProprietario:String(req.body.emailProprietario||""),
    enviarRelatorioDiario:Boolean(req.body.enviarRelatorioDiario),
    horarioRelatorio:String(req.body.horarioRelatorio||"20:00"),
    ativo:true,criadoEm:now(),atualizadoEm:now()
  };
  db.lojas.push(l);salvar();res.status(201).json(l);
});
app.put("/api/lojas/:id",auth,admin,(req,res)=>{
  const l=db.lojas.find(x=>x.id===Number(req.params.id));
  if(!l)return res.status(404).json({erro:"Loja não encontrada."});
  if(req.body.nome!==undefined)l.nome=String(req.body.nome);
  if(req.body.cnpj!==undefined)l.cnpj=String(req.body.cnpj);
  if(req.body.telefone!==undefined)l.telefone=String(req.body.telefone);
  if(req.body.endereco!==undefined)l.endereco=String(req.body.endereco);
  if(req.body.rodapeComprovante!==undefined)l.rodapeComprovante=String(req.body.rodapeComprovante);
  if(req.body.emailProprietario!==undefined)l.emailProprietario=String(req.body.emailProprietario);
  if(req.body.enviarRelatorioDiario!==undefined)l.enviarRelatorioDiario=Boolean(req.body.enviarRelatorioDiario);
  if(req.body.horarioRelatorio!==undefined)l.horarioRelatorio=String(req.body.horarioRelatorio);
  if(req.body.ativo!==undefined)l.ativo=Boolean(req.body.ativo);
  l.atualizadoEm=now();salvar();res.json(l);
});
app.get("/api/lojas/resumo-geral",auth,(_req,res)=>{
  const hoje=new Date().toLocaleDateString("sv-SE");
  const resumo=db.lojas.filter(l=>l.ativo).map(l=>{
    const vendas=db.vendas.filter(v=>v.lojaId===l.id&&v.status==="concluida"&&new Date(v.criadoEm).toLocaleDateString("sv-SE")===hoje);
    return {
      lojaId:l.id,nome:l.nome,
      vendasHoje:vendas.length,
      faturamentoHoje:vendas.reduce((a,v)=>a+v.total,0),
      produtos:db.produtos.filter(p=>p.lojaId===l.id&&p.ativo).length,
      estoqueBaixo:db.produtos.filter(p=>p.lojaId===l.id&&p.ativo&&p.estoque<=p.estoqueMinimo).length,
      ordensAbertas:db.ordensServico.filter(o=>o.lojaId===l.id&&o.status!=="Entregue").length
    };
  });
  res.json(resumo);
});

const adbRootDir=path.join(dataDir,"android-platform-tools");
const adbDownloadedExe=path.join(adbRootDir,"platform-tools","adb.exe");

function caminhoAdb():string {
  if(process.platform==="win32" && fs.existsSync(adbDownloadedExe))return adbDownloadedExe;
  return "adb";
}

function adb(args:string[],timeout=15000):string {
  return execFileSync(caminhoAdb(),args,{encoding:"utf8",timeout,windowsHide:true}).trim();
}

function adbDisponivel():boolean {
  try{ adb(["version"],5000); return true; }
  catch{return false;}
}

function celularesUsbWindows():any[] {
  if(process.platform!=="win32")return [];
  try{
    // Não depende do ADB: pergunta diretamente ao Windows pelos dispositivos USB/PnP presentes.
    // A busca é propositalmente ampla para pegar aparelhos que aparecem só como MTP/WPD/USB Composite.
    const ps = [
      "$ErrorActionPreference='SilentlyContinue'",
      "$pnp=Get-CimInstance Win32_PnPEntity | Where-Object { $_.PNPDeviceID -like 'USB*' -or $_.PNPClass -in @('WPD','AndroidUsbDeviceClass','Ports') }",
      "$items=$pnp | Where-Object {",
      "  ($_.Name -match 'Android|MTP|Phone|Mobile|Portable|Samsung|Motorola|Moto|Xiaomi|Redmi|POCO|OPPO|realme|vivo|HUAWEI|OnePlus|Pixel|LG|Nokia|ASUS|Sony|ADB Interface') -or",
      "  ($_.Service -match 'WUDFRd|WinUSB|usbccgp|androidusb') -or",
      "  ($_.PNPClass -in @('WPD','AndroidUsbDeviceClass'))",
      "}",
      "$items | Select-Object @{N='Status';E={if($_.ConfigManagerErrorCode -eq 0){'OK'}else{'Erro '+$_.ConfigManagerErrorCode}}},@{N='Class';E={$_.PNPClass}},@{N='FriendlyName';E={$_.Name}},@{N='InstanceId';E={$_.PNPDeviceID}} | ConvertTo-Json -Compress"
    ].join("; ");
    const out=execFileSync("powershell.exe",["-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",ps],{
      encoding:"utf8",timeout:10000,windowsHide:true
    }).trim();
    if(!out)return [];
    const parsed=JSON.parse(out);
    const arr=(Array.isArray(parsed)?parsed:[parsed]).map((x:any)=>(
      {nome:String(x.FriendlyName||"Dispositivo móvel"),classe:String(x.Class||""),status:String(x.Status||""),id:String(x.InstanceId||"")}
    ));
    // Remove interfaces duplicadas do mesmo aparelho quando possível.
    const vistos=new Set<string>();
    return arr.filter((x:any)=>{const k=x.id||x.nome;if(vistos.has(k))return false;vistos.add(k);return true;});
  }catch{return [];}
}

async function baixarArquivo(url:string,destino:string){
  const r=await fetch(url,{redirect:"follow"});
  if(!r.ok)throw new Error(`Falha no download: HTTP ${r.status}`);
  const array=await r.arrayBuffer();
  fs.writeFileSync(destino,Buffer.from(array));
}

app.post("/api/usb/instalar-adb",auth,admin,async(req,res)=>{
  if(process.platform!=="win32")return res.status(400).json({erro:"A instalação automática do ADB nesta versão é para Windows."});
  if(!req.body?.aceitouLicenca)return res.status(400).json({erro:"É necessário aceitar os termos do Android SDK Platform-Tools antes do download."});

  const zipPath=path.join(dataDir,"platform-tools-latest-windows.zip");
  const url="https://dl.google.com/android/repository/platform-tools-latest-windows.zip";

  try{
    fs.mkdirSync(dataDir,{recursive:true});
    fs.rmSync(adbRootDir,{recursive:true,force:true});
    fs.mkdirSync(adbRootDir,{recursive:true});

    await baixarArquivo(url,zipPath);

    const psCommand=`Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${adbRootDir.replace(/'/g,"''")}' -Force`;
    execFileSync("powershell.exe",["-NoProfile","-NonInteractive","-Command",psCommand],{
      encoding:"utf8",timeout:120000,windowsHide:true
    });

    try{fs.unlinkSync(zipPath)}catch{}

    if(!fs.existsSync(adbDownloadedExe))throw new Error("O arquivo adb.exe não foi encontrado após a extração.");
    const versao=adb(["version"],10000);

    res.json({
      ok:true,
      mensagem:"ADB oficial instalado para uso do Eletronic Store.",
      caminho:adbDownloadedExe,
      versao:versao.split(/\r?\n/)[0]||versao
    });
  }catch(e:any){
    try{if(fs.existsSync(zipPath))fs.unlinkSync(zipPath)}catch{}
    res.status(500).json({erro:"Não foi possível baixar/configurar o ADB oficial.",detalhe:String(e?.message||e).slice(0,400)});
  }
});


app.post("/api/usb/autorizar",auth,admin,(req,res)=>{
  if(!adbDisponivel())return res.status(400).json({erro:"ADB não está disponível. Use “Baixar ADB oficial” primeiro."});

  try{
    // Reinicia o servidor ADB para forçar uma nova negociação com o aparelho.
    try{adb(["kill-server"],8000)}catch{}
    try{adb(["start-server"],12000)}catch{}

    const out=adb(["devices","-l"],10000);
    const linhas=out.split(/\r?\n/).slice(1).filter(Boolean);
    const devices=linhas.map(line=>{
      const parts=line.trim().split(/\s+/);
      return {serial:parts[0],estado:parts[1]||"",detalhes:parts.slice(2).join(" ")};
    });

    const autorizado=devices.find(d=>d.estado==="device");
    const aguardando=devices.find(d=>d.estado==="unauthorized");

    if(autorizado){
      return res.json({
        ok:true,
        autorizado:true,
        serial:autorizado.serial,
        mensagem:"Celular já autorizado para depuração USB."
      });
    }

    if(aguardando){
      return res.json({
        ok:true,
        autorizado:false,
        aguardando:true,
        serial:aguardando.serial,
        mensagem:"Pedido de autorização enviado. Desbloqueie o celular e aceite “Permitir depuração USB?” na tela do aparelho."
      });
    }

    res.json({
      ok:true,
      autorizado:false,
      aguardando:false,
      mensagem:"Nenhum Android com Depuração USB ativa foi encontrado. Conecte o cabo de dados, desbloqueie o aparelho e ative a Depuração USB."
    });
  }catch(e:any){
    res.status(500).json({erro:"Não foi possível solicitar a autorização ADB.",detalhe:String(e?.message||e).slice(0,300)});
  }
});

app.get("/api/usb/status",auth,admin,(req,res)=>{
  const fisicos=celularesUsbWindows();

  if(!adbDisponivel()){
    return res.json({
      adb:false,
      devices:[],
      fisicos,
      usbConectado:fisicos.length>0,
      mensagem:fisicos.length
        ?"Celular detectado pelo Windows, mas o ADB ainda não está disponível."
        :"Nenhum celular detectado pelo Windows e ADB indisponível."
    });
  }

  try{
    const out=adb(["devices","-l"],10000);
    const devices=out.split(/\r?\n/).slice(1).filter(Boolean).map(line=>{
      const parts=line.trim().split(/\s+/);
      return {serial:parts[0],estado:parts[1]||"",detalhes:parts.slice(2).join(" ")};
    });

    res.json({
      adb:true,
      devices,
      fisicos,
      usbConectado:fisicos.length>0||devices.length>0,
      caminho:caminhoAdb()
    });
  }catch(e:any){
    res.json({
      adb:true,
      devices:[],
      fisicos,
      usbConectado:fisicos.length>0,
      erro:"ADB não respondeu.",
      detalhe:String(e?.message||e).slice(0,250)
    });
  }
});

app.post("/api/usb/scan",auth,(req,res)=>{
  if(!adbDisponivel())return res.status(400).json({erro:"ADB não está disponível. Use o botão “Baixar ADB oficial” na tela de Segurança do Celular."});
  try{
    const devicesOut=adb(["devices"]);
    const linhas=devicesOut.split(/\r?\n/).slice(1).filter(Boolean);
    const deviceLine=linhas.find(x=>/\tdevice$/.test(x));
    if(!deviceLine){
      const unauthorized=linhas.find(x=>/\tunauthorized$/.test(x));
      if(unauthorized)return res.status(400).json({erro:"Celular conectado, mas ainda não autorizado. Confirme a depuração USB na tela do aparelho."});
      return res.status(400).json({erro:"Nenhum celular Android autorizado foi encontrado via USB."});
    }
    const serial=deviceLine.split(/\s+/)[0];
    const run=(cmd:string[],timeout=15000)=>adb(["-s",serial,...cmd],timeout);
    const fabricante=run(["shell","getprop","ro.product.manufacturer"]);
    const modelo=run(["shell","getprop","ro.product.model"]);
    const android=run(["shell","getprop","ro.build.version.release"]);
    const sdk=run(["shell","getprop","ro.build.version.sdk"]);
    const pkgOut=run(["shell","pm","list","packages","-3","-i"],30000);
    const accessibility=(()=>{try{return run(["shell","settings","get","secure","enabled_accessibility_services"])}catch{return ""}})();
    const notif=(()=>{try{return run(["shell","settings","get","secure","enabled_notification_listeners"])}catch{return ""}})();
    const vpn=(()=>{try{return run(["shell","settings","get","secure","always_on_vpn_app"])}catch{return ""}})();
    const admins=(()=>{try{return run(["shell","dpm","list","active-admins"])}catch{return ""}})();

    const riskyWords=["rat","spy","stalker","keylog","remote","monitor","track","control","hidden","stealth","hack"];
    const trustedInstallers=["com.android.vending","com.google.android.packageinstaller","com.android.packageinstaller","com.sec.android.app.samsungapps","com.xiaomi.mipicks","com.amazon.venezia"];
    const knownVendorPrefixes=["com.miui.","com.xiaomi.","com.google.android.","com.android.","com.samsung.","com.sec.android.","com.motorola.","com.oneplus.","com.oppo.","com.coloros.","com.huawei."];
    const knownPackages=new Set(["com.miui.notes","com.miui.screenrecorder","com.miui.compass","com.amazon.appmanager"]);
    const apps=pkgOut.split(/\r?\n/).filter(Boolean).map(line=>{
      const m=line.match(/^package:([^\s]+)(?:\s+installer=([^\s]+))?/);
      const pacote=m?.[1]||line.replace(/^package:/,"").trim();
      const installer=m?.[2]||"";
      const lower=pacote.toLowerCase();
      const motivos:string[]=[];
      const sinaisFortes:string[]=[];
      const sinaisAtencao:string[]=[];
      const fabricanteConhecido=knownVendorPrefixes.some(prefix=>lower.startsWith(prefix))||knownPackages.has(lower);

      if(riskyWords.some(w=>lower.includes(w)))sinaisAtencao.push("O nome técnico do pacote contém termo associado a controle, monitoramento ou acesso remoto; isso sozinho não indica malware.");
      if(accessibility&&accessibility.toLowerCase().includes(lower))sinaisFortes.push("Possui serviço de Acessibilidade atualmente habilitado.");
      if(notif&&notif.toLowerCase().includes(lower))sinaisAtencao.push("Possui acesso às notificações atualmente habilitado.");
      if(admins&&admins.toLowerCase().includes(lower))sinaisFortes.push("Aparece entre os administradores ativos do dispositivo.");
      if(vpn&&vpn.toLowerCase().includes(lower))sinaisAtencao.push("Está configurado como VPN permanente.");

      // A origem da instalação é apenas contexto. Não marque um app como suspeito só por não vir da Play Store.
      if(installer && !trustedInstallers.includes(installer) && !fabricanteConhecido){
        motivos.push(`Origem de instalação: ${installer}. Origem diferente da loja padrão, isoladamente, não significa vírus.`);
      }
      motivos.push(...sinaisFortes,...sinaisAtencao);

      let nivel="normal";
      let classificacao="Sem sinais relevantes";
      if(fabricanteConhecido && !sinaisFortes.length && !sinaisAtencao.length){
        nivel="conhecido";
        classificacao="Sistema / fabricante conhecido";
      }else if(sinaisFortes.length>=2 || (sinaisFortes.length>=1 && sinaisAtencao.length>=1)){
        nivel="alto";
        classificacao="Atenção alta";
      }else if(sinaisFortes.length || sinaisAtencao.length>=2){
        nivel="atencao";
        classificacao="Merece revisão";
      }else if(sinaisAtencao.length || (installer && !trustedInstallers.includes(installer))){
        nivel="baixo";
        classificacao="Baixo risco / verificar origem";
      }
      return {pacote,installer,nivel,classificacao,motivos,sinaisFortes:sinaisFortes.length,sinaisAtencao:sinaisAtencao.length};
    });
    const suspeitos=apps.filter(a=>a.nivel==="atencao"||a.nivel==="alto");
    res.json({
      device:{serial,fabricante,modelo,android,sdk},
      resumo:{totalAppsTerceiros:apps.length,appsParaRevisar:suspeitos.length},
      suspeitos,
      apps,
      observacao:"Triagem local por sinais do Android. Origem da instalação, sozinha, não classifica um app como vírus. Apps só entram em revisão quando há sinais adicionais; a análise não substitui um antivírus dedicado."
    });
  }catch(e:any){
    res.status(500).json({erro:"Falha ao analisar o aparelho via ADB.",detalhe:String(e?.message||e).slice(0,300)});
  }
});



app.post("/api/usb/uninstall",auth,(req,res)=>{
  if(!adbDisponivel())return res.status(400).json({erro:"ADB não está disponível. Use o botão “Baixar ADB oficial” na tela de Segurança do Celular."});

  const serial=String(req.body.serial||"").trim();
  const pacote=String(req.body.pacote||"").trim();

  if(!serial)return res.status(400).json({erro:"Aparelho não informado."});
  if(!/^[A-Za-z0-9._]+$/.test(pacote))return res.status(400).json({erro:"Nome de pacote inválido."});

  try{
    const devicesOut=adb(["devices"]);
    const autorizado=devicesOut.split(/\r?\n/).some(l=>l.startsWith(serial+"\tdevice"));
    if(!autorizado)return res.status(400).json({erro:"O aparelho não está conectado ou autorizado para depuração USB."});

    // Confirma que o pacote realmente existe antes da remoção.
    const pkgOut=adb(["-s",serial,"shell","pm","path",pacote],10000);
    if(!pkgOut || !pkgOut.includes("package:"))return res.status(404).json({erro:"Aplicativo não encontrado no aparelho."});

    // Usa a desinstalação padrão do ADB. Apps de sistema protegidos normalmente não serão removidos por este comando.
    const out=adb(["-s",serial,"uninstall",pacote],30000);

    if(!/Success/i.test(out))return res.status(400).json({erro:"O Android não permitiu desinstalar esse aplicativo.",detalhe:out.slice(0,300)});
    res.json({ok:true,pacote,mensagem:"Aplicativo desinstalado com sucesso."});
  }catch(e:any){
    res.status(500).json({erro:"Não foi possível desinstalar o aplicativo.",detalhe:String(e?.message||e).slice(0,300)});
  }
});

// Configurações
app.get("/api/config",auth,(req,res)=>{const l=lojaReq(req);res.json({nomeLoja:l.nome,cnpj:l.cnpj,telefone:l.telefone,endereco:l.endereco,rodapeComprovante:l.rodapeComprovante});});
app.put("/api/config",auth,admin,(req,res)=>{
  const l=lojaReq(req);
  l.nome=String(req.body.nomeLoja||req.body.nome||l.nome);
  l.cnpj=String(req.body.cnpj||"");
  l.telefone=String(req.body.telefone||"");
  l.endereco=String(req.body.endereco||"");
  l.rodapeComprovante=String(req.body.rodapeComprovante||"Obrigado pela preferência!");
  l.atualizadoEm=now();salvar();
  res.json({nomeLoja:l.nome,cnpj:l.cnpj,telefone:l.telefone,endereco:l.endereco,rodapeComprovante:l.rodapeComprovante});
});

// Importação em lote (Excel/CSV)
function chaveColuna(v:any){return String(v??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]/g,"");}
function valorColuna(row:any,aliases:string[]){
  const entries=Object.entries(row||{});const wanted=aliases.map(chaveColuna);
  for(const [k,v] of entries)if(wanted.includes(chaveColuna(k)))return v;
  return "";
}
function numeroPlanilha(v:any){if(typeof v==="number")return Number.isFinite(v)?v:0;const x=String(v??"").trim().replace(/\s/g,"").replace(/R\$/gi,"");if(!x)return 0;const normalized=x.includes(",")?x.replace(/\./g,"").replace(",","."):x;const n=Number(normalized);return Number.isFinite(n)?n:0;}
function linhasPlanilha(base64:string){
  const buf=Buffer.from(String(base64||""),"base64");if(!buf.length)throw new Error("Arquivo vazio.");
  const wb=XLSX.read(buf,{type:"buffer",cellDates:false});const ws=wb.Sheets[wb.SheetNames[0]];if(!ws)throw new Error("A planilha não possui uma aba válida.");
  return XLSX.utils.sheet_to_json<any>(ws,{defval:"",raw:false});
}
app.post("/api/importar/produtos-excel",auth,admin,(req,res)=>{
  try{
    const lojaId=lojaIdReq(req),rows=linhasPlanilha(req.body.base64);let criados=0,atualizados=0,ignorados=0;
    for(const row of rows){
      const nome=String(valorColuna(row,["descricao","descrição","produto","nome","nome produto"])).trim();
      if(!nome){ignorados++;continue;}
      const codigo=String(valorColuna(row,["codigo","código","cod","codigo interno","referencia","referência"])).trim()||`IMP-${db.seq.produto}`;
      const codigoBarras=String(valorColuna(row,["codigo barras","código barras","codigo de barras","código de barras","ean","gtin","barcode"])).trim();
      const categoria=String(valorColuna(row,["categoria","grupo","departamento"])).trim()||"Importados";
      const marca=String(valorColuna(row,["marca","fabricante"])).trim()||"Não informada";
      const precoCusto=Math.max(0,numeroPlanilha(valorColuna(row,["preco custo","preço custo","custo","valor custo","preco de custo","preço de custo"])));
      const precoVenda=Math.max(0,numeroPlanilha(valorColuna(row,["preco venda","preço venda","venda","preco","preço","valor venda","preco de venda","preço de venda"])));
      const estoque=Math.max(0,numeroPlanilha(valorColuna(row,["estoque","quantidade","qtd","saldo","estoque atual"])));
      const estoqueMinimo=Math.max(0,numeroPlanilha(valorColuna(row,["estoque minimo","estoque mínimo","minimo","mínimo"])))||1;
      let p=db.produtos.find(x=>x.lojaId===lojaId&&((codigoBarras&&x.codigoBarras===codigoBarras)||x.codigo.toLowerCase()===codigo.toLowerCase()));
      if(p){p.nome=nome;p.codigo=codigo;p.codigoBarras=codigoBarras||p.codigoBarras;p.categoria=categoria;p.marca=marca;p.precoCusto=precoCusto;p.precoVenda=precoVenda;p.estoque=estoque;p.estoqueMinimo=estoqueMinimo;p.ativo=true;p.atualizadoEm=now();atualizados++;}
      else{db.produtos.push({lojaId,id:db.seq.produto++,codigo,codigoBarras,nome,categoria,marca,precoCusto,precoVenda,estoque,estoqueMinimo,ativo:true,criadoEm:now(),atualizadoEm:now()});criados++;}
    }
    salvar();res.json({ok:true,total:rows.length,criados,atualizados,ignorados});
  }catch(e:any){res.status(400).json({erro:String(e?.message||e)});}
});
app.post("/api/importar/servicos-excel",auth,admin,(req,res)=>{
  try{
    const lojaId=lojaIdReq(req),rows=linhasPlanilha(req.body.base64);let criados=0,atualizados=0,ignorados=0;
    for(const row of rows){
      const nome=String(valorColuna(row,["servico","serviço","nome","descricao","descrição"])).trim();if(!nome){ignorados++;continue;}
      const categoria=String(valorColuna(row,["categoria","grupo","tipo"])).trim()||"Serviços";
      const descricao=String(valorColuna(row,["detalhes","observacao","observação","descricao","descrição"])).trim();
      const preco=Math.max(0,numeroPlanilha(valorColuna(row,["preco","preço","valor","preco venda","preço venda"])));
      let sv=db.servicos.find(x=>x.lojaId===lojaId&&x.nome.toLowerCase()===nome.toLowerCase());
      if(sv){sv.categoria=categoria;sv.descricao=descricao;sv.preco=preco;sv.ativo=true;sv.atualizadoEm=now();atualizados++;}
      else{db.servicos.push({lojaId,id:db.seq.servico++,nome,descricao,categoria,preco,ativo:true,criadoEm:now(),atualizadoEm:now()});criados++;}
    }
    salvar();res.json({ok:true,total:rows.length,criados,atualizados,ignorados});
  }catch(e:any){res.status(400).json({erro:String(e?.message||e)});}
});

// Produtos
app.get("/api/produtos",auth,(_req,res)=>{
  const lojaId=lojaIdReq(_req);res.json(db.produtos.filter(p=>p.lojaId===lojaId).sort((a,b)=>a.nome.localeCompare(b.nome)));
});

app.post("/api/produtos",auth,admin,(req,res)=>{
  const {codigo,codigoBarras="",nome,categoria,marca,precoCusto,precoVenda,estoque=0,estoqueMinimo=1}=req.body;
  if(!codigo||!nome||!categoria||!marca||precoVenda===undefined)return res.status(400).json({erro:"Preencha os campos obrigatórios."});
  if(db.produtos.some(p=>p.lojaId===lojaIdReq(req)&&p.codigo.toLowerCase()===String(codigo).toLowerCase()))return res.status(409).json({erro:"O código já existe."});
  if(String(codigoBarras).trim()&&db.produtos.some(p=>p.lojaId===lojaIdReq(req)&&String(p.codigoBarras||"")===String(codigoBarras).trim()))return res.status(409).json({erro:"O código de barras já está cadastrado."});
  const lojaId=lojaIdReq(req);const p:Produto={lojaId,id:db.seq.produto++,codigo:String(codigo),codigoBarras:String(codigoBarras||"").trim(),nome:String(nome),categoria:String(categoria),marca:String(marca),precoCusto:Number(precoCusto)||0,precoVenda:Number(precoVenda)||0,estoque:Math.max(0,Number(estoque)||0),estoqueMinimo:Math.max(0,Number(estoqueMinimo)||0),ativo:true,criadoEm:now(),atualizadoEm:now()};
  db.produtos.push(p);salvar();res.status(201).json(p);
});

app.put("/api/produtos/:id",auth,admin,(req,res)=>{
  const p=db.produtos.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!p)return res.status(404).json({erro:"Produto não encontrado."});
  const novoCodigo=String(req.body.codigo??p.codigo);
  const novoCodigoBarras=String(req.body.codigoBarras??p.codigoBarras??"").trim();
  if(db.produtos.some(x=>x.lojaId===p.lojaId&&x.id!==p.id&&x.codigo.toLowerCase()===novoCodigo.toLowerCase()))return res.status(409).json({erro:"O código já existe."});
  if(novoCodigoBarras&&db.produtos.some(x=>x.lojaId===p.lojaId&&x.id!==p.id&&String(x.codigoBarras||"")===novoCodigoBarras))return res.status(409).json({erro:"O código de barras já está cadastrado."});
  p.codigo=novoCodigo;p.codigoBarras=novoCodigoBarras;p.nome=String(req.body.nome??p.nome);p.categoria=String(req.body.categoria??p.categoria);p.marca=String(req.body.marca??p.marca);
  p.precoCusto=Number(req.body.precoCusto??p.precoCusto);p.precoVenda=Number(req.body.precoVenda??p.precoVenda);p.estoqueMinimo=Math.max(0,Number(req.body.estoqueMinimo??p.estoqueMinimo));
  p.ativo=req.body.ativo===undefined?p.ativo:Boolean(req.body.ativo);p.atualizadoEm=now();salvar();res.json(p);
});

app.post("/api/produtos/:id/estoque",auth,admin,(req,res)=>{
  const p=db.produtos.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!p)return res.status(404).json({erro:"Produto não encontrado."});
  const tipo=String(req.body.tipo||"ajuste");
  const q=Number(req.body.quantidade);
  if(!Number.isFinite(q)||q===0)return res.status(400).json({erro:"Informe uma quantidade válida."});
  const delta=tipo==="saida"?-Math.abs(q):tipo==="entrada"?Math.abs(q):q;
  if(p.estoque+delta<0)return res.status(400).json({erro:"Estoque não pode ficar negativo."});
  movimentarEstoque(p,delta,tipo==="entrada"?"entrada":tipo==="saida"?"saida":"ajuste",String(req.body.motivo||"Ajuste manual"),(req as any).usuario);
  salvar();res.json(p);
});

app.get("/api/movimentos",auth,admin,(_req,res)=>{const lojaId=lojaIdReq(_req);res.json(db.movimentos.filter(m=>m.lojaId===lojaId).reverse().slice(0,500));});

// Clientes
app.get("/api/clientes",auth,(_req,res)=>{const lojaId=lojaIdReq(_req);res.json(db.clientes.filter(c=>c.lojaId===lojaId).sort((a,b)=>a.nome.localeCompare(b.nome)));});
app.post("/api/clientes",auth,(req,res)=>{
  const nome=String(req.body.nome||"").trim(); if(!nome)return res.status(400).json({erro:"Nome é obrigatório."});
  const cpf=String(req.body.cpf||"").trim();
  if(cpf&&db.clientes.some(c=>c.lojaId===lojaIdReq(req)&&c.cpf===cpf))return res.status(409).json({erro:"CPF já cadastrado."});
  const lojaId=lojaIdReq(req);const c:Cliente={lojaId,id:db.seq.cliente++,nome,cpf,telefone:String(req.body.telefone||""),email:String(req.body.email||""),ativo:true,criadoEm:now(),atualizadoEm:now()};
  db.clientes.push(c);salvar();res.status(201).json(c);
});
app.put("/api/clientes/:id",auth,(req,res)=>{
  const c=db.clientes.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));if(!c)return res.status(404).json({erro:"Cliente não encontrado."});
  const cpf=String(req.body.cpf??c.cpf);
  if(cpf&&db.clientes.some(x=>x.lojaId===c.lojaId&&x.id!==c.id&&x.cpf===cpf))return res.status(409).json({erro:"CPF já cadastrado."});
  c.nome=String(req.body.nome??c.nome);c.cpf=cpf;c.telefone=String(req.body.telefone??c.telefone);c.email=String(req.body.email??c.email);c.ativo=req.body.ativo===undefined?c.ativo:Boolean(req.body.ativo);c.atualizadoEm=now();
  salvar();res.json(c);
});


// Serviços
app.get("/api/servicos",auth,(_req,res)=>{
  const lojaId=lojaIdReq(_req);res.json(db.servicos.filter(s=>s.lojaId===lojaId).sort((a,b)=>a.nome.localeCompare(b.nome)));
});

app.post("/api/servicos",auth,admin,(req,res)=>{
  const nome=String(req.body.nome||"").trim();
  if(!nome)return res.status(400).json({erro:"Nome do serviço é obrigatório."});
  const lojaId=lojaIdReq(req);const s:Servico={
    lojaId,id:db.seq.servico++,
    nome,
    descricao:String(req.body.descricao||""),
    categoria:String(req.body.categoria||"Serviços"),
    preco:Math.max(0,Number(req.body.preco)||0),
    ativo:true,
    criadoEm:now(),atualizadoEm:now()
  };
  db.servicos.push(s);salvar();res.status(201).json(s);
});

app.put("/api/servicos/:id",auth,admin,(req,res)=>{
  const s=db.servicos.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!s)return res.status(404).json({erro:"Serviço não encontrado."});
  if(req.body.nome!==undefined)s.nome=String(req.body.nome);
  if(req.body.descricao!==undefined)s.descricao=String(req.body.descricao);
  if(req.body.categoria!==undefined)s.categoria=String(req.body.categoria);
  if(req.body.preco!==undefined)s.preco=Math.max(0,Number(req.body.preco)||0);
  if(req.body.ativo!==undefined)s.ativo=Boolean(req.body.ativo);
  s.atualizadoEm=now();salvar();res.json(s);
});

// Ordens de Serviço
app.get("/api/ordens-servico",auth,(_req,res)=>{
  const lojaId=lojaIdReq(_req);res.json(db.ordensServico.filter(o=>o.lojaId===lojaId).reverse());
});

app.post("/api/ordens-servico",auth,(req,res)=>{
  const clienteNome=String(req.body.clienteNome||"").trim();
  const aparelho=String(req.body.aparelho||"").trim();
  if(!clienteNome||!aparelho)return res.status(400).json({erro:"Cliente e aparelho são obrigatórios."});
  const lojaId=lojaIdReq(req);const servico=db.servicos.find(s=>s.lojaId===lojaId&&s.id===Number(req.body.servicoId));
  const o:OrdemServico={
    lojaId,id:db.seq.ordemServico++,
    clienteNome,
    telefone:String(req.body.telefone||""),
    aparelho,
    marca:String(req.body.marca||""),
    modelo:String(req.body.modelo||""),
    problemaRelatado:String(req.body.problemaRelatado||""),
    servicoId:servico?.id||null,
    servicoNome:servico?.nome||String(req.body.servicoNome||"Diagnóstico"),
    valor:req.body.valor!==undefined?Math.max(0,Number(req.body.valor)||0):(servico?.preco||0),
    observacoes:String(req.body.observacoes||""),
    status:"Recebido",
    criadoEm:now(),atualizadoEm:now()
  };
  db.ordensServico.push(o);salvar();res.status(201).json(o);
});

app.put("/api/ordens-servico/:id",auth,(req,res)=>{
  const o=db.ordensServico.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!o)return res.status(404).json({erro:"Ordem de serviço não encontrada."});
  const allowed=["Recebido","Em análise","Aguardando peça","Em reparo","Pronto","Entregue"];
  if(req.body.status!==undefined&&allowed.includes(String(req.body.status)))o.status=req.body.status;
  if(req.body.valor!==undefined)o.valor=Math.max(0,Number(req.body.valor)||0);
  if(req.body.observacoes!==undefined)o.observacoes=String(req.body.observacoes);
  o.atualizadoEm=now();salvar();res.json(o);
});



// Diagnóstico de segurança para celulares
app.get("/api/diagnosticos-seguranca",auth,(_req,res)=>{
  const lojaId=lojaIdReq(_req);res.json(db.diagnosticosSeguranca.filter(d=>d.lojaId===lojaId).reverse());
});

app.post("/api/diagnosticos-seguranca",auth,(req,res)=>{
  const clienteNome=String(req.body.clienteNome||"").trim();
  const aparelho=String(req.body.aparelho||"").trim();
  if(!clienteNome||!aparelho)return res.status(400).json({erro:"Cliente e aparelho são obrigatórios."});
  const lojaId=lojaIdReq(req);const d:DiagnosticoSeguranca={
    lojaId,id:db.seq.diagnostico++,
    clienteNome,
    aparelho,
    modelo:String(req.body.modelo||""),
    sistema:String(req.body.sistema||"Android"),
    sintomas:Array.isArray(req.body.sintomas)?req.body.sintomas.map(String):[],
    observacoes:String(req.body.observacoes||""),
    etapas:{
      backupConfirmado:false,
      appsSuspeitosVerificados:false,
      permissoesVerificadas:false,
      navegadorVerificado:false,
      atualizacoesVerificadas:false,
      playProtectVerificado:false
    },
    resultado:"Pendente",
    criadoEm:now(),
    atualizadoEm:now()
  };
  db.diagnosticosSeguranca.push(d);salvar();res.status(201).json(d);
});

app.put("/api/diagnosticos-seguranca/:id",auth,(req,res)=>{
  const d=db.diagnosticosSeguranca.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!d)return res.status(404).json({erro:"Diagnóstico não encontrado."});
  const etapas=req.body.etapas||{};
  d.etapas={
    backupConfirmado:Boolean(etapas.backupConfirmado),
    appsSuspeitosVerificados:Boolean(etapas.appsSuspeitosVerificados),
    permissoesVerificadas:Boolean(etapas.permissoesVerificadas),
    navegadorVerificado:Boolean(etapas.navegadorVerificado),
    atualizacoesVerificadas:Boolean(etapas.atualizacoesVerificadas),
    playProtectVerificado:Boolean(etapas.playProtectVerificado)
  };
  const allowed=["Pendente","Nenhuma ameaça óbvia encontrada","Aplicativos suspeitos identificados","Necessita análise adicional"];
  if(allowed.includes(String(req.body.resultado)))d.resultado=req.body.resultado;
  if(req.body.observacoes!==undefined)d.observacoes=String(req.body.observacoes);
  d.atualizadoEm=now();salvar();res.json(d);
});

// Vendedores
app.get("/api/vendedores",auth,(req,res)=>{const id=lojaIdReq(req);res.json(db.vendedores.filter(v=>v.lojaId===id).sort((a,b)=>a.nome.localeCompare(b.nome)))});
app.post("/api/vendedores",auth,admin,(req,res)=>{const lojaId=lojaIdReq(req),nome=String(req.body.nome||"").trim(),codigo=String(req.body.codigo||"").trim();if(!nome)return res.status(400).json({erro:"Nome do vendedor é obrigatório."});const v:Vendedor={lojaId,id:db.seq.vendedor++,nome,codigo,ativo:true,criadoEm:now(),atualizadoEm:now()};db.vendedores.push(v);salvar();res.status(201).json(v)});
app.put("/api/vendedores/:id",auth,admin,(req,res)=>{const v=db.vendedores.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));if(!v)return res.status(404).json({erro:"Vendedor não encontrado."});if(req.body.nome!==undefined)v.nome=String(req.body.nome).trim()||v.nome;if(req.body.codigo!==undefined)v.codigo=String(req.body.codigo).trim();if(req.body.ativo!==undefined)v.ativo=Boolean(req.body.ativo);v.atualizadoEm=now();salvar();res.json(v)});

// Caixa
app.get("/api/caixa/status",auth,(req,res)=>res.json(caixaAbertoDoUsuario((req as any).usuario.id,lojaIdReq(req))||null));
app.post("/api/caixa/abrir",auth,(req,res)=>{
  const u=(req as any).usuario as Usuario;
  const lojaId=lojaIdReq(req);if(caixaAbertoDoUsuario(u.id,lojaId))return res.status(409).json({erro:"Você já possui um caixa aberto."});
  const c:Caixa={lojaId,id:db.seq.caixa++,usuarioId:u.id,usuarioNome:u.nome,abertoEm:now(),saldoInicial:Math.max(0,Number(req.body.saldoInicial)||0),status:"aberto"};
  db.caixas.push(c);salvar();res.status(201).json(c);
});
app.post("/api/caixa/fechar",auth,(req,res)=>{
  const u=(req as any).usuario as Usuario;
  const lojaId=lojaIdReq(req);const c=caixaAbertoDoUsuario(u.id,lojaId);if(!c)return res.status(404).json({erro:"Nenhum caixa aberto."});
  const vendas=db.vendas.filter(v=>v.lojaId===lojaId&&v.usuarioId===u.id&&v.status==="concluida"&&new Date(v.criadoEm)>=new Date(c.abertoEm));
  c.fechadoEm=now();c.saldoFinalInformado=Number(req.body.saldoFinalInformado)||0;c.totalVendas=vendas.reduce((s,v)=>s+v.total,0);c.status="fechado";salvar();res.json(c);
});
app.get("/api/caixas",auth,admin,(_req,res)=>{const lojaId=lojaIdReq(_req);res.json(db.caixas.filter(c=>c.lojaId===lojaId).reverse());});

// Vendas
app.post("/api/vendas",auth,(req,res)=>{
  const u=(req as any).usuario as Usuario;
  const lojaId=lojaIdReq(req);if(!caixaAbertoDoUsuario(u.id,lojaId))return res.status(400).json({erro:"Abra o caixa antes de registrar vendas."});
  const {itens,servicos:servicosVenda=[],desconto=0,acrescimo=0,formaPagamento,pagamentos=[],clienteId=null,vendedorId=null,compradorDocumento="",compradorTelefone="",compradorEmail=""}=req.body;
  const vendedor=db.vendedores.find(v=>v.lojaId===lojaId&&v.id===Number(vendedorId)&&v.ativo);if(!vendedor)return res.status(400).json({erro:"Selecione um vendedor ativo para finalizar a venda."});
  if((!Array.isArray(itens)||!itens.length)&&(!Array.isArray(servicosVenda)||!servicosVenda.length))return res.status(400).json({erro:"Venda inválida."});
  const backup=structuredClone(db);
  try{
    let subtotal=0;const itensVenda:ItemVenda[]=[];
    for(const item of itens){
      const p=produtoAtivo(Number(item.produtoId),lojaId),q=Number(item.quantidade);
      if(!p)throw new Error("Produto não encontrado ou inativo.");
      if(!Number.isInteger(q)||q<=0)throw new Error("Quantidade inválida.");
      if(p.estoque<q)throw new Error(`Estoque insuficiente: ${p.nome}.`);
      const acrescimoUnitario=Math.max(0,Number(item.acrescimoUnitario)||0);
      subtotal+=(p.precoVenda+acrescimoUnitario)*q;
      itensVenda.push({tipo:"produto",produtoId:p.id,servicoId:null,nomeProduto:p.nome,codigoProduto:p.codigo,quantidade:q,precoUnitario:p.precoVenda,acrescimoUnitario,subtotal:(p.precoVenda+acrescimoUnitario)*q});
      movimentarEstoque(p,-q,"venda",`Venda #${db.seq.venda}`,u);
    }

    for(const item of (Array.isArray(servicosVenda)?servicosVenda:[])){
      const s=db.servicos.find(x=>x.lojaId===lojaId&&x.id===Number(item.servicoId)&&x.ativo);
      const q=Math.max(1,Number(item.quantidade)||1);
      if(!s)throw new Error("Serviço não encontrado ou inativo.");
      const acrescimoUnitario=Math.max(0,Number(item.acrescimoUnitario)||0);
      subtotal+=(s.preco+acrescimoUnitario)*q;
      itensVenda.push({tipo:"servico",produtoId:null,servicoId:s.id,nomeProduto:s.nome,codigoProduto:"SERV",quantidade:q,precoUnitario:s.preco,acrescimoUnitario,subtotal:(s.preco+acrescimoUnitario)*q});
    }

    const adicional=Math.max(0,Number(acrescimo)||0);
    const d=Math.max(0,Math.min(Number(desconto)||0,subtotal+adicional));
    const cliente=db.clientes.find(c=>c.lojaId===lojaId&&c.id===Number(clienteId));
    const totalVenda=subtotal+adicional-d;
    const formasPermitidas=new Set(["PIX","Dinheiro","Débito","Crédito"]);
    let pagamentosVenda:{forma:string;valor:number}[]=[];
    if(Array.isArray(pagamentos)&&pagamentos.length){
      pagamentosVenda=pagamentos.map((p:any)=>({forma:String(p.forma||""),valor:Math.round((Number(p.valor)||0)*100)/100})).filter((p:any)=>p.forma&&p.valor>0);
      if(!pagamentosVenda.length||pagamentosVenda.some(p=>!formasPermitidas.has(p.forma)))throw new Error("Forma de pagamento inválida.");
      const soma=Math.round(pagamentosVenda.reduce((a,p)=>a+p.valor,0)*100)/100;
      if(Math.abs(soma-Math.round(totalVenda*100)/100)>0.009)throw new Error(`Os pagamentos precisam somar exatamente ${totalVenda.toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}.`);
    }else{
      const forma=String(formaPagamento||"");
      if(!formasPermitidas.has(forma))throw new Error("Selecione uma forma de pagamento.");
      pagamentosVenda=[{forma,valor:Math.round(totalVenda*100)/100}];
    }
    const formaResumo=pagamentosVenda.length>1?"Misto":pagamentosVenda[0].forma;
    const v:Venda={lojaId,vendedorId:vendedor.id,vendedorNome:vendedor.nome,id:db.seq.venda++,clienteId:cliente?.id||null,clienteNome:cliente?.nome||"Consumidor final",compradorDocumento:String(compradorDocumento||""),compradorTelefone:String(compradorTelefone||""),compradorEmail:String(compradorEmail||""),usuarioId:u.id,usuarioNome:u.nome,subtotal,acrescimo:adicional,desconto:d,total:totalVenda,formaPagamento:formaResumo,pagamentos:pagamentosVenda,itens:itensVenda,status:"concluida",criadoEm:now()};
    db.vendas.push(v);salvar();res.status(201).json(v);
  }catch(e){db=backup;res.status(400).json({erro:e instanceof Error?e.message:"Não foi possível finalizar a venda."});}
});

app.get("/api/vendas",auth,(_req,res)=>{const lojaId=lojaIdReq(_req);res.json(db.vendas.filter(v=>v.lojaId===lojaId).reverse());});
app.get("/api/vendas/:id",auth,(req,res)=>{
  const v=db.vendas.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));if(!v)return res.status(404).json({erro:"Venda não encontrada."});res.json(v);
});
app.post("/api/vendas/:id/cancelar",auth,admin,(req,res)=>{
  const v=db.vendas.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));if(!v)return res.status(404).json({erro:"Venda não encontrada."});
  if(v.status==="cancelada")return res.status(409).json({erro:"Venda já cancelada."});
  const u=(req as any).usuario as Usuario;
  for(const item of v.itens){
    if(item.tipo==="produto"&&item.produtoId!==null){
      const p=db.produtos.find(x=>x.lojaId===v.lojaId&&x.id===item.produtoId);
      if(p)movimentarEstoque(p,item.quantidade,"cancelamento",`Cancelamento da venda #${v.id}`,u);
    }
  }
  v.status="cancelada";v.canceladoEm=now();salvar();res.json(v);
});


// Fiscal: gera rascunho interno para preparação dos dados.
// A autorização real de NF-e/NFC-e depende de credenciamento, certificado digital e integração SEFAZ.
app.post("/api/vendas/:id/fiscal",auth,admin,(req,res)=>{
  const v=db.vendas.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!v)return res.status(404).json({erro:"Venda não encontrada."});
  if(v.status!=="concluida")return res.status(400).json({erro:"Venda cancelada não pode gerar documento fiscal."});
  const tipo=req.body.tipo==="nfe"?"rascunho-nfe":"rascunho-nfce";
  v.fiscal={
    tipo,
    numero:v.id,
    serie:Number(req.body.serie)||1,
    naturezaOperacao:String(req.body.naturezaOperacao||"Venda de mercadoria"),
    status:"rascunho",
    criadoEm:now()
  };
  salvar();res.json(v.fiscal);
});

app.get("/api/vendas/:id/fiscal",auth,(req,res)=>{
  const v=db.vendas.find(x=>x.lojaId===lojaIdReq(req)&&x.id===Number(req.params.id));
  if(!v)return res.status(404).json({erro:"Venda não encontrada."});
  res.json(v.fiscal||null);
});

app.get("/api/vendedores/desempenho",auth,(req,res)=>{const lojaId=lojaIdReq(req),todas=String(req.query.todas||"")==="1",de=new Date(String(req.query.de||new Date().toISOString().slice(0,7)+"-01")+"T00:00:00"),ate=new Date(String(req.query.ate||new Date().toISOString().slice(0,10))+"T23:59:59.999");const vendas=db.vendas.filter(v=>v.status==="concluida"&&(todas||v.lojaId===lojaId)&&new Date(v.criadoEm)>=de&&new Date(v.criadoEm)<=ate);const m=new Map<any,any>();for(const v of vendas){const k=v.vendedorId??v.vendedorNome??v.usuarioNome,r=m.get(k)||{vendedorId:v.vendedorId??null,nome:v.vendedorNome||v.usuarioNome||"Não informado",vendas:0,faturamento:0,itens:0,produtos:new Map()};r.vendas++;r.faturamento+=v.total;for(const i of v.itens){r.itens+=i.quantidade;const p=r.produtos.get(i.nomeProduto)||{nome:i.nomeProduto,quantidade:0,faturamento:0};p.quantidade+=i.quantidade;p.faturamento+=i.subtotal;r.produtos.set(i.nomeProduto,p)}m.set(k,r)}const ranking=[...m.values()].map(r=>({vendedorId:r.vendedorId,nome:r.nome,vendas:r.vendas,faturamento:r.faturamento,itens:r.itens,ticketMedio:r.vendas?r.faturamento/r.vendas:0,produtoDestaque:[...r.produtos.values()].sort((a:any,b:any)=>b.quantidade-a.quantidade)[0]||null,produtos:[...r.produtos.values()]})).sort((a,b)=>b.faturamento-a.faturamento);const pm=new Map<string,any>();for(const r of ranking)for(const p of r.produtos){const x=pm.get(p.nome)||{nome:p.nome,quantidade:0,vendedores:[]};x.quantidade+=p.quantidade;x.vendedores.push({nome:r.nome,quantidade:p.quantidade});pm.set(p.nome,x)}const porProduto=[...pm.values()].map(x=>({...x,vendedores:x.vendedores.sort((a:any,b:any)=>b.quantidade-a.quantidade)})).sort((a,b)=>b.quantidade-a.quantidade);res.json({vendas:vendas.length,faturamento:vendas.reduce((a,v)=>a+v.total,0),ranking,porProduto})});

// Dashboard / relatórios
app.get("/api/dashboard",auth,(_req,res)=>{
  const hoje=new Date().toLocaleDateString("sv-SE");
  const lojaId=lojaIdReq(_req);const vendasHoje=db.vendas.filter(v=>v.lojaId===lojaId&&v.status==="concluida"&&new Date(v.criadoEm).toLocaleDateString("sv-SE")===hoje);
  const faturamento=vendasHoje.reduce((s,v)=>s+v.total,0);
  const lucroEstimado=vendasHoje.reduce((acc,v)=>acc+v.itens.reduce((s,i)=>{
    if(i.tipo==="servico")return s+(i.precoUnitario+(i.acrescimoUnitario||0))*i.quantidade;
    const p=db.produtos.find(x=>x.lojaId===lojaId&&x.id===i.produtoId);
    return s+(i.precoUnitario+(i.acrescimoUnitario||0)-(p?.precoCusto||0))*i.quantidade;
  },0)-v.desconto,0);
  const pagamentos:Record<string,number>={};
  for(const v of vendasHoje)pagamentos[v.formaPagamento]=(pagamentos[v.formaPagamento]||0)+v.total;
  const ranking=new Map<string,{nome:string,qtd:number,valor:number}>();
  for(const v of db.vendas.filter(v=>v.lojaId===lojaId&&v.status==="concluida")){
    for(const i of v.itens){
      const key=`${i.tipo}:${i.produtoId ?? i.servicoId}`;
      const r=ranking.get(key)||{nome:i.nomeProduto,qtd:0,valor:0};
      r.qtd+=i.quantidade;r.valor+=i.subtotal;ranking.set(key,r);
    }
  }
  res.json({
    vendasHoje:vendasHoje.length,
    faturamento,
    ticketMedio:vendasHoje.length?faturamento/vendasHoje.length:0,
    lucroEstimado,
    estoqueBaixo:db.produtos.filter(p=>p.lojaId===lojaId&&p.ativo&&p.estoque<=p.estoqueMinimo).length,
    pagamentos,
    maisVendidos:[...ranking.values()].sort((a,b)=>b.qtd-a.qtd).slice(0,5)
  });
});




function moedaEmail(v:number){
  return v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
}

function corpoRelatorioLoja(loja:Loja,rel:any,titulo:string){
  return `<div style="font-family:Arial,sans-serif;max-width:700px;margin:auto;color:#17202a">
    <h2>${titulo}</h2><h3>${loja.nome}</h3>
    <table style="width:100%;border-collapse:collapse">
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Vendas</td><td style="padding:8px;border-bottom:1px solid #ddd"><b>${rel.vendas}</b></td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Receita bruta</td><td style="padding:8px;border-bottom:1px solid #ddd"><b>${moedaEmail(rel.receitaBruta)}</b></td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Descontos</td><td style="padding:8px;border-bottom:1px solid #ddd">${moedaEmail(rel.descontos)}</td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Valor arrecadado</td><td style="padding:8px;border-bottom:1px solid #ddd"><b>${moedaEmail(rel.receitaLiquida)}</b></td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Custo dos produtos vendidos</td><td style="padding:8px;border-bottom:1px solid #ddd">${moedaEmail(rel.custoProdutos)}</td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Lucro bruto estimado</td><td style="padding:8px;border-bottom:1px solid #ddd"><b>${moedaEmail(rel.lucroBrutoEstimado)}</b></td></tr>
      <tr><td style="padding:8px;border-bottom:1px solid #ddd">Ticket médio</td><td style="padding:8px;border-bottom:1px solid #ddd">${moedaEmail(rel.ticketMedio)}</td></tr>
    </table>
    <p style="color:#6b7680;font-size:12px">Relatório gerado automaticamente pelo Eletronic Store.</p>
  </div>`;
}

async function enviarEmailApi(args:{to:string;subject:string;html?:string;text?:string}){
  const c=db.emailConfig;
  const apiKey=String(process.env.ELETRONIC_EMAIL_API_KEY||c.apiKey||"");
  const remetente=String(process.env.ELETRONIC_EMAIL_FROM||c.remetente||"");
  if(!apiKey||!remetente)throw new Error("Serviço de e-mail não configurado. Configure ELETRONIC_EMAIL_API_KEY e ELETRONIC_EMAIL_FROM no computador do aplicativo.");

  const response=await fetch("https://api.resend.com/emails",{
    method:"POST",
    headers:{
      "Authorization":`Bearer ${apiKey}`,
      "Content-Type":"application/json"
    },
    body:JSON.stringify({
      from:remetente,
      to:[args.to],
      subject:args.subject,
      ...(args.html?{html:args.html}:{}),
      ...(args.text?{text:args.text}:{})
    })
  });

  const payload:any=await response.json().catch(()=>({}));
  if(!response.ok){
    const msg=String(payload?.message||payload?.error||`Erro HTTP ${response.status}`);
    throw new Error(msg);
  }
  return payload;
}

app.get("/api/email-config",auth,admin,(_req,res)=>{
  res.json({emailConsolidado:db.emailConfig.emailConsolidado});
});

app.put("/api/email-config",auth,admin,(req,res)=>{
  db.emailConfig.emailConsolidado=String(req.body.emailConsolidado||"");
  db.emailConfig.enviarConsolidado=false;
  salvar();
  res.json({ok:true,emailConsolidado:db.emailConfig.emailConsolidado});
});

function nomeMesPt(mes:number){
  return ["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"][mes]||"";
}

function periodoRelatorio(tipo:string,mesInformado?:string){
  if(tipo==="mes"){
    const valor=String(mesInformado||"").trim();
    if(!/^\d{4}-\d{2}$/.test(valor))throw new Error("Selecione um mês válido.");
    const [ano,mes]=valor.split("-").map(Number);
    if(mes<1||mes>12)throw new Error("Selecione um mês válido.");
    const inicio=new Date(ano,mes-1,1,0,0,0,0);
    const fim=new Date(ano,mes,0,23,59,59,999);
    const titulo=`${nomeMesPt(mes-1)} de ${ano}`;
    return {inicio,fim,titulo,assunto:`Relatório consolidado mensal — ${titulo}`};
  }

  const agora=new Date();
  const inicio=new Date(agora.getFullYear(),agora.getMonth(),agora.getDate(),0,0,0,0);
  const fim=new Date(agora.getFullYear(),agora.getMonth(),agora.getDate(),23,59,59,999);
  const titulo=agora.toLocaleDateString("pt-BR");
  return {inicio,fim,titulo,assunto:`Relatório consolidado diário — ${titulo}`};
}

function lojasDoRelatorio(lojaIdRaw:any){
  const valor=String(lojaIdRaw??"todas").trim();
  if(valor==="todas"||valor==="")return db.lojas.filter(l=>l.ativo);

  const id=Number(valor);
  const loja=db.lojas.find(l=>l.id===id&&l.ativo);
  if(!loja)throw new Error("Loja selecionada não foi encontrada.");
  return [loja];
}

function relatorioConsolidadoTexto(inicio:Date,fim:Date,periodoTitulo:string,lojaIdRaw:any){
  const lojasSelecionadas=lojasDoRelatorio(lojaIdRaw);
  const relatorios=lojasSelecionadas.map(loja=>({
    loja,
    rel:relatorioDaLoja(loja.id,inicio,fim)
  }));

  const linhas=relatorios.map(({loja,rel:r})=>{
    return [
      `Loja: ${loja.nome}`,
      `Vendas: ${r.vendas}`,
      `Receita bruta: ${moedaEmail(r.receitaBruta)}`,
      `Descontos: ${moedaEmail(r.descontos)}`,
      `Valor arrecadado: ${moedaEmail(r.receitaLiquida)}`,
      `Custo dos produtos vendidos: ${moedaEmail(r.custoProdutos)}`,
      `Lucro bruto estimado: ${moedaEmail(r.lucroBrutoEstimado)}`,
      `Ticket médio: ${moedaEmail(r.ticketMedio)}`
    ].join("\n");
  });

  const totalVendas=relatorios.reduce((a,x)=>a+x.rel.vendas,0);
  const totalBruto=relatorios.reduce((a,x)=>a+x.rel.receitaBruta,0);
  const totalDescontos=relatorios.reduce((a,x)=>a+x.rel.descontos,0);
  const totalLiquido=relatorios.reduce((a,x)=>a+x.rel.receitaLiquida,0);
  const totalCusto=relatorios.reduce((a,x)=>a+x.rel.custoProdutos,0);
  const totalLucro=relatorios.reduce((a,x)=>a+x.rel.lucroBrutoEstimado,0);

  const resumo=[
    "RESUMO",
    `Vendas: ${totalVendas}`,
    `Receita bruta: ${moedaEmail(totalBruto)}`,
    `Descontos: ${moedaEmail(totalDescontos)}`,
    `Valor arrecadado: ${moedaEmail(totalLiquido)}`,
    `Custo dos produtos vendidos: ${moedaEmail(totalCusto)}`,
    `Lucro bruto estimado: ${moedaEmail(totalLucro)}`
  ].join("\n");

  const tituloLoja=lojasSelecionadas.length===1
    ?`LOJA: ${lojasSelecionadas[0].nome}`
    :"TODAS AS LOJAS";

  return `ELETRONIC STORE - RELATÓRIO\n${tituloLoja}\nPeríodo: ${periodoTitulo}\n\n${resumo}\n\n==============================\n\n${linhas.join("\n\n------------------------------\n\n")}\n\nRelatório gerado pelo Eletronic Store.`;
}

app.post("/api/email/preparar-relatorio",auth,admin,(req,res)=>{
  try{
    const destino=String(req.body.email||db.emailConfig.emailConsolidado||"").trim();
    if(!destino)return res.status(400).json({erro:"Informe um e-mail de destino."});

    const tipo=String(req.body.tipo||"dia");
    const periodo=periodoRelatorio(tipo,req.body.mes);
    const lojasSelecionadas=lojasDoRelatorio(req.body.lojaId);
    const nomeEscopo=lojasSelecionadas.length===1?lojasSelecionadas[0].nome:"Todas as lojas";

    db.emailConfig.emailConsolidado=destino;
    salvar();

    res.json({
      ok:true,
      to:destino,
      subject:`${periodo.assunto.replace("consolidado ","")} — ${nomeEscopo}`,
      body:relatorioConsolidadoTexto(periodo.inicio,periodo.fim,periodo.titulo,req.body.lojaId)
    });
  }catch(e:any){
    res.status(400).json({erro:String(e?.message||e)});
  }
});

app.post("/api/email/enviar-relatorio",auth,admin,async(req,res)=>{
  try{
    const loja=lojaReq(req);
    if(!loja.emailProprietario)return res.status(400).json({erro:"Cadastre o e-mail do proprietário nesta loja."});
    const data=new Date().toLocaleDateString("sv-SE");
    const rel=relatorioDaLoja(loja.id,new Date(`${data}T00:00:00`),new Date(`${data}T23:59:59.999`));
    await enviarEmailApi({
      to:loja.emailProprietario,
      subject:`Faturamento do dia — ${loja.nome}`,
      html:corpoRelatorioLoja(loja,rel,"Relatório diário")
    });
    res.json({ok:true});
  }catch(e:any){
    res.status(500).json({erro:String(e?.message||e)});
  }
});

const relatoriosEmailEnviados=new Set<string>();

async function verificarRelatoriosEmail(){
  const agora=new Date();
  const data=agora.toLocaleDateString("sv-SE");
  const hora=agora.toTimeString().slice(0,5);
  const c=db.emailConfig;
  if(!c.apiKey||!c.remetente)return;

  const inicio=new Date(`${data}T00:00:00`);
  const fim=new Date(`${data}T23:59:59.999`);

  for(const loja of db.lojas.filter(l=>l.ativo&&l.enviarRelatorioDiario&&l.emailProprietario)){
    const chave=`loja:${loja.id}:${data}`;
    if(hora===loja.horarioRelatorio&&!relatoriosEmailEnviados.has(chave)){
      const rel=relatorioDaLoja(loja.id,inicio,fim);
      await enviarEmailApi({
        to:loja.emailProprietario,
        subject:`Faturamento do dia — ${loja.nome}`,
        html:corpoRelatorioLoja(loja,rel,"Relatório diário")
      });
      relatoriosEmailEnviados.add(chave);
    }
  }

  if(c.enviarConsolidado&&c.emailConsolidado&&hora===c.horarioConsolidado){
    const chave=`consolidado:${data}`;
    if(!relatoriosEmailEnviados.has(chave)){
      const linhas=db.lojas.filter(l=>l.ativo).map(loja=>{
        const r=relatorioDaLoja(loja.id,inicio,fim);
        return `<tr>
          <td style="padding:8px;border-bottom:1px solid #ddd">${loja.nome}</td>
          <td style="padding:8px;border-bottom:1px solid #ddd">${r.vendas}</td>
          <td style="padding:8px;border-bottom:1px solid #ddd">${moedaEmail(r.receitaLiquida)}</td>
          <td style="padding:8px;border-bottom:1px solid #ddd">${moedaEmail(r.lucroBrutoEstimado)}</td>
        </tr>`;
      }).join("");

      await enviarEmailApi({
        to:c.emailConsolidado,
        subject:"Relatório consolidado diário — Todas as lojas",
        html:`<div style="font-family:Arial,sans-serif;max-width:760px;margin:auto">
          <h2>Relatório consolidado diário</h2>
          <table style="width:100%;border-collapse:collapse">
            <tr><th style="text-align:left;padding:8px">Loja</th><th style="text-align:left;padding:8px">Vendas</th><th style="text-align:left;padding:8px">Arrecadado</th><th style="text-align:left;padding:8px">Lucro bruto estimado</th></tr>
            ${linhas}
          </table>
        </div>`
      });
      relatoriosEmailEnviados.add(chave);
    }
  }

  for(const chave of [...relatoriosEmailEnviados]){
    if(!chave.endsWith(data))relatoriosEmailEnviados.delete(chave);
  }
}

// Envio automático desativado nesta edição: relatórios são preparados no cliente de e-mail do Windows.

// Aparência global do sistema
app.get("/api/aparencia",auth,(_req,res)=>res.json(db.aparencia));
app.put("/api/aparencia",auth,admin,(req,res)=>{
  const colorKeys=["corPrincipal","corTopo","corMenu","corFundo","corCartao","corTexto","corTextoSecundario","corBorda","corPerigo"] as const;
  for(const key of colorKeys){
    const value=String(req.body[key]||db.aparencia[key]);
    if(!/^#[0-9a-fA-F]{6}$/.test(value))return res.status(400).json({erro:`Cor inválida em ${key}.`});
    db.aparencia[key]=value;
  }
  db.aparencia.icone=String(req.body.icone||"⚡").slice(0,8);
  db.aparencia.nomeSistema=String(req.body.nomeSistema||"Eletronic Store").slice(0,60);
  const logo=String(req.body.logoDataUrl||"");
  if(logo && !/^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(logo))return res.status(400).json({erro:"Formato de imagem inválido."});
  if(logo.length>900000)return res.status(400).json({erro:"A imagem é muito grande. Use uma imagem menor."});
  db.aparencia.logoDataUrl=logo;
  salvar();res.json(db.aparencia);
});

// Relatórios da loja atual
app.get("/api/relatorios",auth,(req,res)=>{
  const {inicio,fim,de,ate}=parsePeriodo(req);
  const loja=lojaReq(req);
  res.json({loja,periodo:{de,ate},...relatorioDaLoja(loja.id,inicio,fim)});
});

// Relatório consolidado de todas as lojas
app.get("/api/relatorios/consolidado",auth,(req,res)=>{
  const {inicio,fim,de,ate}=parsePeriodo(req);
  const lojas=db.lojas.filter(l=>l.ativo).map(loja=>({loja,...relatorioDaLoja(loja.id,inicio,fim)}));
  const total={
    vendas:lojas.reduce((a,x)=>a+x.vendas,0),
    receitaBruta:lojas.reduce((a,x)=>a+x.receitaBruta,0),
    descontos:lojas.reduce((a,x)=>a+x.descontos,0),
    receitaLiquida:lojas.reduce((a,x)=>a+x.receitaLiquida,0),
    custoProdutos:lojas.reduce((a,x)=>a+x.custoProdutos,0),
    lucroBrutoEstimado:lojas.reduce((a,x)=>a+x.lucroBrutoEstimado,0),
    valorEstoqueCusto:lojas.reduce((a,x)=>a+x.valorEstoqueCusto,0),
    valorEstoqueVenda:lojas.reduce((a,x)=>a+x.valorEstoqueVenda,0)
  };
  res.json({periodo:{de,ate},total,lojas});
});

// Usuários
app.get("/api/usuarios",auth,admin,(_req,res)=>res.json(db.usuarios.map(({senhaHash,...u})=>u)));
app.post("/api/usuarios",auth,admin,(req,res)=>{
  const {nome,login,senha,cargo="vendedor"}=req.body;
  if(!nome||!login||!senha)return res.status(400).json({erro:"Nome, login e senha são obrigatórios."});
  if(db.usuarios.some(u=>u.login===String(login).trim()))return res.status(409).json({erro:"Esse login já existe."});
  const u:Usuario={id:db.seq.usuario++,nome:String(nome),login:String(login).trim(),senhaHash:senhaHash(String(senha)),cargo:cargo==="admin"?"admin":"vendedor",ativo:true,criadoEm:now()};
  db.usuarios.push(u);salvar();const {senhaHash:_,...safe}=u;res.status(201).json(safe);
});
app.put("/api/usuarios/:id",auth,admin,(req,res)=>{
  const u=db.usuarios.find(x=>x.id===Number(req.params.id));if(!u)return res.status(404).json({erro:"Usuário não encontrado."});
  if(req.body.nome!==undefined)u.nome=String(req.body.nome);
  if(req.body.cargo!==undefined)u.cargo=req.body.cargo==="admin"?"admin":"vendedor";
  if(req.body.ativo!==undefined)u.ativo=Boolean(req.body.ativo);
  if(req.body.senha)u.senhaHash=senhaHash(String(req.body.senha));
  salvar();const {senhaHash:_,...safe}=u;res.json(safe);
});

// Sincronização online
app.get("/api/cloud/status",auth,(_req,res)=>{const c=cloudCfg();res.json({enabled:Boolean(c?.enabled),state:cloudState,message:cloudMessage,version:cloudVersion,updatedAt:cloudUpdatedAt,syncId:c?.syncId||""})});
app.post("/api/cloud/sync",auth,async(_req,res)=>{const ok=await cloudPull(true);if(ok)await cloudPush();res.json({ok:cloudState==="online",state:cloudState,message:cloudMessage,version:cloudVersion})});

// Backup
app.get("/api/backup",auth,admin,(_req,res)=>{
  res.setHeader("Content-Disposition",`attachment; filename="eletronic-store-backup-${new Date().toISOString().slice(0,10)}.json"`);
  res.setHeader("Content-Type","application/json; charset=utf-8");
  res.send(JSON.stringify(db,null,2));
});

app.listen(PORT,()=>{console.log(`Eletronic Store Definitivo rodando em http://localhost:${PORT}`);iniciarCloud()});
